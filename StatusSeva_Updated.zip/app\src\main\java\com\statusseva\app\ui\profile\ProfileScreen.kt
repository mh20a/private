package com.statusseva.app.ui.profile

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import com.statusseva.app.R
import com.statusseva.app.data.AppDownloadManager
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.GallerySaver
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.data.WatermarkHelper
import com.statusseva.app.model.DownloadedPost
import com.statusseva.app.ui.upload.UserContentItem
import com.statusseva.app.ui.home.VideoPlayer
import java.io.File
import java.io.FileOutputStream

object ProfileStateCache {
    var myContentItems: List<UserContentItem>? = null
}

private val thumbnailCache = mutableMapOf<String, Bitmap>()

// 🌟 EXACTLY HOMESCREEN WALA FAST IMAGE SHARE LOGIC 🌟
private suspend fun shareImageToWhatsApp(context: Context, imageUrl: String) {
    try {
        val watermarked = GallerySaver.getWatermarkedBitmap(context, imageUrl)
            ?: run {
                withContext(Dispatchers.Main) { Toast.makeText(context, "Image Load Failed", Toast.LENGTH_SHORT).show() }
                return
            }
        val file = withContext(Dispatchers.IO) {
            val f = File(context.cacheDir, "wa_share.png")
            FileOutputStream(f).use { fos -> watermarked.compress(Bitmap.CompressFormat.PNG, 100, fos) }
            watermarked.recycle()
            f
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val whatsappIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, WatermarkHelper.getRandomCaption())
            `package` = "com.whatsapp"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(whatsappIntent)
        }
    } catch (_: Exception) {
        withContext(Dispatchers.Main) { Toast.makeText(context, "WhatsApp not installed or Share Failed", Toast.LENGTH_SHORT).show() }
    }
}

// 🌟 EXACTLY HOMESCREEN WALA FAST VIDEO SHARE LOGIC 🌟
private suspend fun shareVideoToWhatsApp(context: Context, videoUrl: String) {
    try {
        val videoFile = GallerySaver.downloadVideoToCache(context, videoUrl)
            ?: run {
                withContext(Dispatchers.Main) { Toast.makeText(context, "Video Load Failed", Toast.LENGTH_SHORT).show() }
                return
            }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", videoFile)
        val whatsappIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, WatermarkHelper.getRandomCaption())
            `package` = "com.whatsapp"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(whatsappIntent)
        }
    } catch (_: Exception) {
        withContext(Dispatchers.Main) { Toast.makeText(context, "WhatsApp not installed or Share Failed", Toast.LENGTH_SHORT).show() }
    }
}

// ── Backend Call (Cancel Subscription) ─────────────────────────
private suspend fun cancelSubscriptionBackend(): Boolean = withContext(Dispatchers.IO) {
    try {
        val user = GoogleAuthHelper.currentUser ?: return@withContext false
        val token = user.getIdToken(true).await().token ?: return@withContext false
        val url = java.net.URL("https://us-central1-statusseva-37a7e.cloudfunctions.net/cancelSubscription")
        val conn = url.openConnection() as java.net.HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.outputStream.use { it.write("{}".toByteArray()) }
        return@withContext conn.responseCode == 200
    } catch (e: Exception) {
        e.printStackTrace()
        return@withContext false
    }
}

// ─────────────────────────────────────────────────────────────
//  PROFILE SCREEN
// ─────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ProfileScreen(
    onNavigate      : (String) -> Unit,
    onLogout        : () -> Unit,
    appLang         : String  = "hi",
    onAppLangChange : (String) -> Unit = {},
    paywallEnabled  : Boolean = false,
    userPlan        : String  = "free"
) {
    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    fun str(key: String) = AppStrings.get(key, appLang)

    fun strCustom(hi: String, mr: String, en: String) = when (appLang) {
        "hi" -> hi; "mr" -> mr; else -> en
    }

    val googleUser     = GoogleAuthHelper.currentUser
    val googleName     = googleUser?.displayName ?: ""
    val googleEmail    = googleUser?.email       ?: ""
    val googlePhotoUrl = googleUser?.photoUrl

    var manageMode by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(pageCount = { 2 })
    val downloads  = AppDownloadManager.downloadedPosts
    val selectedItems = remember { mutableStateListOf<String>() }
    var viewerPost by remember { mutableStateOf<DownloadedPost?>(null) }

    val userId = googleUser?.uid ?: ""
    var myContentItems   by remember { mutableStateOf<List<UserContentItem>>(ProfileStateCache.myContentItems ?: emptyList()) }
    var myContentLoading by remember { mutableStateOf(ProfileStateCache.myContentItems == null) }

    var userPhone by remember { mutableStateOf("") }
    // 🌟 NEW: Subscription Start Time State
    var planStartedTime by remember { mutableLongStateOf(0L) }

    var showPhoneDialog by remember { mutableStateOf(false) }

    var showCancelDialog by remember { mutableStateOf(false) }
    var isCancelling     by remember { mutableStateOf(false) }

    DisposableEffect(userId) {
        if (userId.isBlank()) { myContentLoading = false; return@DisposableEffect onDispose {} }

        val contentListener = FirebaseFirestore.getInstance()
            .collection("user_content")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    myContentItems = snap.documents.mapNotNull { doc ->
                        val ts = doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                        UserContentItem(
                            id           = doc.id,
                            mediaUrl     = doc.getString("mediaUrl")     ?: "",
                            storagePath  = doc.getString("storagePath")  ?: "",
                            mediaType    = doc.getString("mediaType")    ?: "image",
                            caption      = doc.getString("caption")      ?: "",
                            category     = doc.getString("category")     ?: "",
                            status       = doc.getString("status")       ?: "pending",
                            rejectReason = doc.getString("rejectReason") ?: "",
                            createdAt    = ts
                        )
                    }.sortedByDescending { it.createdAt }
                    ProfileStateCache.myContentItems = myContentItems
                }
                myContentLoading = false
            }

        val userListener = FirebaseFirestore.getInstance()
            .collection("users").document(userId)
            .addSnapshotListener { snap, _ ->
                userPhone = snap?.getString("phone") ?: ""
                // 🌟 NEW: Fetch plan start time
                planStartedTime = snap?.getTimestamp("planStarted")?.toDate()?.time ?: 0L
            }

        onDispose {
            contentListener.remove()
            userListener.remove()
        }
    }

    // 🌟 NEW: Check if 24 hours have passed
    val showCancelButton = remember(userPlan, planStartedTime) {
        if (userPlan != "pro") false
        else if (planStartedTime == 0L) false // Fail-safe (Hide if unknown)
        else {
            val diffMs = System.currentTimeMillis() - planStartedTime
            val maxAllowedMs = 24 * 60 * 60 * 1000L // 24 Hours in MS
            diffMs <= maxAllowedMs
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        AnimatedContent(
                            targetState    = manageMode,
                            transitionSpec = { fadeIn(tween(200)).togetherWith(fadeOut(tween(200))) },
                            label          = "topbar"
                        ) { managing ->
                            if (managing) {
                                Text("${selectedItems.size} selected", fontWeight = FontWeight.Bold)
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter            = painterResource(R.drawable.logo),
                                        contentDescription = null,
                                        modifier           = Modifier.height(30.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text       = stringResource(R.string.app_name),
                                        fontWeight = FontWeight.Bold,
                                        style      = MaterialTheme.typography.titleLarge
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        if (manageMode) {
                            IconButton(onClick = {
                                selectedItems.forEach { AppDownloadManager.deletePost(it) }
                                selectedItems.clear()
                                manageMode = false
                            }) {
                                Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                            }
                            IconButton(onClick = {
                                selectedItems.clear()
                                manageMode = false
                            }) { Icon(Icons.Default.Close, null) }
                        } else {
                            if (paywallEnabled || userPlan == "pro") {
                                IconButton(onClick = {
                                    onNavigate("subscription")
                                }) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = "Subscription",
                                        tint = if (userPlan == "pro")
                                            Color(0xFFFFD700)
                                        else
                                            MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            IconButton(onClick = {
                                onNavigate("settings")
                            }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            ProfileHeader(
                name             = googleName.ifBlank { "User" },
                email            = googleEmail,
                photoUrl         = googlePhotoUrl,
                userPhone        = userPhone,
                downloadsCount   = downloads.size,
                myContentCount   = myContentItems.size,
                downloadsLabel   = str("downloads_title"),
                myContentLabel   = "My Content",
                userPlan         = userPlan,
                showCancelButton = showCancelButton, // 🌟 PASSED NEW PARAMETER
                onCancelSubClick = { showCancelDialog = true },
                onEditPhoneClick = { showPhoneDialog = true },
                strCustom        = ::strCustom
            )

            TabRow(selectedTabIndex = pagerState.currentPage) {
                Tab(
                    selected = pagerState.currentPage == 0,
                    onClick  = {
                        coroutineScope.launch {
                            manageMode = false
                            selectedItems.clear()
                            pagerState.animateScrollToPage(0)
                        }
                    },
                    text = { Text(str("downloads")) }
                )
                Tab(
                    selected = pagerState.currentPage == 1,
                    onClick  = { coroutineScope.launch { pagerState.animateScrollToPage(1) } },
                    text = {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text("My Content")
                            if (myContentItems.any { it.status == "pending" }) {
                                Badge {
                                    Text(myContentItems.count { it.status == "pending" }.toString())
                                }
                            }
                        }
                    }
                )
            }

            HorizontalPager(
                state             = pagerState,
                modifier          = Modifier.fillMaxSize(),
                userScrollEnabled = true
            ) { page ->
                when (page) {
                    0 -> DownloadsTab(
                        downloads      = downloads,
                        selectedItems  = selectedItems,
                        manageMode     = manageMode,
                        onManageToggle = {
                            manageMode = !manageMode
                            if (!manageMode) selectedItems.clear()
                        },
                        onCellClick = { post ->
                            if (manageMode) {
                                if (selectedItems.contains(post.id)) selectedItems.remove(post.id)
                                else selectedItems.add(post.id)
                            } else {
                                viewerPost = post
                            }
                        },
                        str = { key -> AppStrings.get(key, appLang) }
                    )
                    1 -> MyContentTabProfile(items = myContentItems, isLoading = myContentLoading)
                }
            }
        }
    }

    if (showPhoneDialog) {
        var phoneInput by remember { mutableStateOf(userPhone) }
        var isSaving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!isSaving) showPhoneDialog = false },
            title = { Text(strCustom("फ़ोन नंबर", "फोन नंबर", "Phone Number")) },
            text = {
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = {
                        if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                            if (it.isNotEmpty() && it[0] !in listOf('6', '7', '8', '9')) {
                                Toast.makeText(context, "Invalid number", Toast.LENGTH_SHORT).show()
                            } else {
                                phoneInput = it
                            }
                        }
                    },
                    label = { Text("10-digit mobile number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (phoneInput.length == 10) {
                            isSaving = true
                            FirebaseFirestore.getInstance().collection("users").document(userId)
                                .update("phone", phoneInput)
                                .addOnSuccessListener {
                                    isSaving = false
                                    showPhoneDialog = false
                                    Toast.makeText(context, strCustom("नंबर सेव हो गया", "नंबर सेव्ह झाला", "Number Saved"), Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener {
                                    isSaving = false
                                    Toast.makeText(context, "Error updating phone", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            Toast.makeText(context, strCustom("कृपया 10 अंकों का नंबर दर्ज करें", "कृपया 10 अंकी नंबर टाका", "Enter 10 digits"), Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isSaving
                ) {
                    if (isSaving) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Text(strCustom("सेव करें", "सेव्ह करा", "Save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { if (!isSaving) showPhoneDialog = false }) {
                    Text(strCustom("रद्द करें", "रद्द करा", "Cancel"))
                }
            }
        )
    }

    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { if (!isCancelling) showCancelDialog = false },
            title = { Text(strCustom("सदस्यता रद्द करें?", "सदस्यत्व रद्द करा?", "Cancel Subscription?")) },
            text = { Text(strCustom("क्या आप वाकई अपनी Pro सदस्यता रद्द करना चाहते हैं? आपकी सदस्यता तुरंत समाप्त हो जाएगी।", "तुम्हाला नक्की Pro सदस्यत्व रद्द करायचे आहे का? तुमचे सदस्यत्व त्वरित समाप्त होईल.", "Are you sure you want to cancel your Pro subscription? You will lose premium access immediately.")) },
            confirmButton = {
                TextButton(onClick = {
                    isCancelling = true
                    coroutineScope.launch {
                        val success = cancelSubscriptionBackend()
                        isCancelling = false
                        showCancelDialog = false
                        if (success) {
                            Toast.makeText(context, strCustom("सदस्यता रद्द कर दी गई", "सदस्यत्व रद्द केले", "Subscription Cancelled"), Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, strCustom("कुछ गलत हुआ। फिर से प्रयास करें।", "काहीतरी चुकले. पुन्हा प्रयत्न करा.", "Failed to cancel. Try again."), Toast.LENGTH_LONG).show()
                        }
                    }
                }) {
                    if (isCancelling) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.error)
                    } else {
                        Text(strCustom("हाँ, रद्द करें", "होय, रद्द करा", "Yes, Cancel"), color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { if (!isCancelling) showCancelDialog = false }) {
                    Text(strCustom("रखें", "ठेवा", "Keep Pro"))
                }
            }
        )
    }

    viewerPost?.let { post ->
        DownloadedPostViewer(
            post           = post,
            onDismiss      = { viewerPost = null },
            onNavigate     = onNavigate,
            paywallEnabled = paywallEnabled,
            userPlan       = userPlan
        )
    }
}

// ─────────────────────────────────────────────────────────────
//  DOWNLOADED POST VIEWER
// ─────────────────────────────────────────────────────────────

@Composable
fun DownloadedPostViewer(
    post           : DownloadedPost,
    onDismiss      : () -> Unit,
    onNavigate     : (String) -> Unit = {},
    paywallEnabled : Boolean = false,
    userPlan       : String  = "free"
) {
    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSharing      by remember { mutableStateOf(false) }

    val isVideo = remember(post.imageUrl) {
        post.imageUrl.contains(".mp4", ignoreCase = true) ||
                post.imageUrl.contains("video", ignoreCase = true)
    }

    var scale  by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val transformableState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
        if (scale > 1f) offset += panChange else offset = Offset.Zero
    }

    var lastTapTime by remember { mutableLongStateOf(0L) }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    // 🌟 LOCAL VIDEO EXOPLAYER SETUP FOR FIXING CRASH
    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    val localExoPlayer = remember {
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(1000, 30_000, 500, 1_000)
            .setPrioritizeTimeOverSizeThresholds(true).build()

        androidx.media3.exoplayer.ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .build()
            .apply { repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE }
    }

    DisposableEffect(Unit) {
        onDispose { localExoPlayer.release() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress      = true,
            dismissOnClickOutside   = false
        )
    ) {
        AnimatedVisibility(
            visible = visible,
            enter   = fadeIn(tween(250)) + scaleIn(
                initialScale  = 0.93f,
                animationSpec = tween(250)
            ),
            exit    = fadeOut(tween(200)) + scaleOut(
                targetScale   = 0.93f,
                animationSpec = tween(200)
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable {
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 300L) {
                            scale  = 1f
                            offset = Offset.Zero
                        }
                        lastTapTime = now
                    }
            ) {
                // ── Image / Video ─────────────────────────────
                if (!isVideo) {
                    AsyncImage(
                        model              = post.imageUrl,
                        contentDescription = post.title,
                        modifier           = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX       = scale
                                scaleY       = scale
                                translationX = offset.x
                                translationY = offset.y
                            }
                            .transformable(state = transformableState),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Box(
                        modifier         = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        VideoPlayer(
                            videoUrl = post.imageUrl,
                            isVisible = visible,
                            sharedPlayer = localExoPlayer, // 🌟 PASSED LOCAL PLAYER TO PREVENT CRASH
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // ── Top Bar ───────────────────────────────────
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)
                            )
                        )
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text(
                        text     = post.title,
                        color    = Color.White,
                        style    = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 12.dp)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector        = Icons.Default.Close,
                            contentDescription = "Close",
                            tint               = Color.White,
                            modifier           = Modifier.size(28.dp)
                        )
                    }
                }

                // ── Bottom Bar — Share button (theme-wise) ────
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.80f))
                            )
                        )
                        .navigationBarsPadding()
                        .padding(start = 32.dp, end = 32.dp, top = 24.dp, bottom = 110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    FilledTonalButton(
                        onClick = {
                            if (paywallEnabled && userPlan == "free") {
                                onNavigate("subscription")
                                onDismiss()
                                return@FilledTonalButton
                            }
                            if (!isSharing) {
                                isSharing = true
                                coroutineScope.launch {
                                    if (isVideo) {
                                        Toast.makeText(context, "Preparing video...", Toast.LENGTH_SHORT).show()
                                        shareVideoToWhatsApp(context, post.imageUrl)
                                    } else {
                                        shareImageToWhatsApp(context, post.imageUrl)
                                    }
                                    isSharing = false
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape   = RoundedCornerShape(16.dp),
                        enabled = !isSharing,
                        colors  = ButtonDefaults.filledTonalButtonColors(
                            containerColor         = Color(0xFF25D366),
                            contentColor           = Color.White,
                            disabledContainerColor = Color(0xFF25D366).copy(alpha = 0.5f),
                            disabledContentColor   = Color.White.copy(alpha = 0.5f)
                        ),
                        elevation = ButtonDefaults.filledTonalButtonElevation(defaultElevation = 2.dp)
                    ) {
                        if (isSharing) {
                            CircularProgressIndicator(
                                modifier    = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color       = Color.White
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Sharing...",
                                fontWeight = FontWeight.SemiBold,
                                fontSize   = 14.sp,
                                color      = Color.White
                            )
                        } else {
                            Image(
                                painter            = painterResource(R.drawable.ic_whatsapp),
                                contentDescription = "WhatsApp",
                                modifier           = Modifier.size(22.dp),
                                colorFilter        = androidx.compose.ui.graphics.ColorFilter.tint(Color.White)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Share",
                                fontWeight    = FontWeight.Bold,
                                fontSize      = 15.sp,
                                letterSpacing = 0.3.sp,
                                color         = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  DOWNLOADS TAB
// ─────────────────────────────────────────────────────────────

@Composable
fun DownloadsTab(
    downloads      : List<DownloadedPost>,
    selectedItems  : MutableList<String>,
    manageMode     : Boolean,
    onManageToggle : () -> Unit,
    onCellClick    : (DownloadedPost) -> Unit,
    str            : (String) -> String
) {
    LazyColumn(
        modifier       = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier              = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    str("downloads"),
                    style      = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (downloads.isNotEmpty()) {
                    TextButton(onClick = onManageToggle) {
                        Text(if (manageMode) str("save") else "Manage")
                    }
                }
            }
        }

        if (downloads.isEmpty()) {
            item {
                Box(
                    modifier         = Modifier.fillMaxWidth().height(260.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Download, null,
                            modifier = Modifier.size(56.dp),
                            tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            str("no_downloads"),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            str("no_downloads_sub"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                        )
                    }
                }
            }
        }

        val rows = downloads.chunked(3)
        itemsIndexed(rows) { _, rowItems ->
            Row(
                modifier              = Modifier.fillMaxWidth().padding(horizontal = 1.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                rowItems.forEach { post ->
                    GridCell(
                        post        = post,
                        isSelected  = selectedItems.contains(post.id),
                        manageMode  = manageMode,
                        modifier    = Modifier.weight(1f),
                        onCellClick = { onCellClick(post) }
                    )
                }
                repeat(3 - rowItems.size) { Spacer(modifier = Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(2.dp))
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  MY CONTENT TAB
// ─────────────────────────────────────────────────────────────

@Composable
fun MyContentTabProfile(
    items     : List<UserContentItem>,
    isLoading : Boolean
) {
    val firestore    = remember { FirebaseFirestore.getInstance() }
    val coroutine    = rememberCoroutineScope()
    var deleteDialog by remember { mutableStateOf<UserContentItem?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            items.isEmpty() -> {
                Column(
                    modifier            = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.CloudUpload, null,
                        modifier = Modifier.size(56.dp),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Abhi tak koi content nahi",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
            else -> {
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(items, key = { _, it -> it.id }) { _, item ->
                        ProfileContentCard(
                            item     = item,
                            onDelete = { deleteDialog = item },
                            onCancel = { deleteDialog = item }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }

    deleteDialog?.let { item ->
        val isPending = item.status == "pending"
        AlertDialog(
            onDismissRequest = { deleteDialog = null },
            title = {
                Text(if (isPending) "Request Cancel karein?" else "Delete Request Bhejo?")
            },
            text = {
                Text(
                    if (isPending) "Ye upload request cancel ho jayegi aur file delete ho jayegi."
                    else "Admin ko delete request bheja jayega. Approve hone par post hata di jayegi."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val capturedItem = item
                    deleteDialog = null
                    coroutine.launch {
                        try {
                            if (isPending) {
                                // Cancel pending upload — direct delete allowed
                                firestore.collection("user_content").document(capturedItem.id).delete().await()
                                if (capturedItem.storagePath.isNotBlank()) {
                                    try {
                                        withContext(kotlinx.coroutines.Dispatchers.IO) {
                                            com.google.firebase.functions.FirebaseFunctions.getInstance()
                                                .getHttpsCallable("deleteR2File")
                                                .call(mapOf("objectKey" to capturedItem.storagePath))
                                                .await()
                                        }
                                    } catch (_: Exception) {}
                                }
                            } else {
                                // Approved/rejected posts → send delete request to admin
                                val uid   = GoogleAuthHelper.currentUser?.uid   ?: ""
                                val name  = GoogleAuthHelper.currentUser?.displayName ?: "User"
                                val email = GoogleAuthHelper.currentUser?.email ?: ""
                                val req   = hashMapOf(
                                    "userContentId" to capturedItem.id,
                                    "mediaUrl"      to capturedItem.mediaUrl,
                                    "caption"       to capturedItem.caption,
                                    "category"      to capturedItem.category,
                                    "status"        to capturedItem.status,
                                    "storagePath"   to capturedItem.storagePath,
                                    "requestedByUid"   to uid,
                                    "requestedByName"  to name,
                                    "requestedByEmail" to email,
                                    "requestStatus" to "pending",
                                    "createdAt"     to com.google.firebase.firestore.FieldValue.serverTimestamp()
                                )
                                firestore.collection("delete_requests").add(req).await()
                                Toast.makeText(
                                    firestore.app.applicationContext,
                                    "Delete request bheja gaya. Admin review karega.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (_: Exception) {}
                    }
                }) {
                    Text(
                        if (isPending) "Cancel Request" else "Request to Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteDialog = null }) { Text("Rakho") }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────
//  PROFILE CONTENT CARD
// ─────────────────────────────────────────────────────────────

@Composable
fun ProfileContentCard(
    item     : UserContentItem,
    onDelete : () -> Unit,
    onCancel : () -> Unit
) {
    val statusConfig = when (item.status) {
        "pending"  -> Triple("⏳ Review Pending", MaterialTheme.colorScheme.tertiary,  MaterialTheme.colorScheme.tertiaryContainer)
        "approved" -> Triple("✅ Live",           Color(0xFF16a34a),                   Color(0xFFdcfce7))
        "rejected" -> Triple("❌ Rejected",        MaterialTheme.colorScheme.error,     MaterialTheme.colorScheme.errorContainer)
        else       -> Triple("⏳ Pending",         MaterialTheme.colorScheme.tertiary,  MaterialTheme.colorScheme.tertiaryContainer)
    }

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
            ) {
                if (item.mediaType == "video") {
                    Box(
                        modifier         = Modifier.fillMaxSize()
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PlayCircle, null,
                            modifier = Modifier.size(48.dp),
                            tint     = MaterialTheme.colorScheme.primary
                        )
                    }
                } else {
                    AsyncImage(
                        model              = item.mediaUrl,
                        contentDescription = null,
                        modifier           = Modifier.fillMaxSize(),
                        contentScale       = ContentScale.Crop
                    )
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    shape    = RoundedCornerShape(20.dp),
                    color    = statusConfig.third.copy(alpha = 0.92f)
                ) {
                    Text(
                        text       = statusConfig.first,
                        color      = statusConfig.second,
                        fontSize   = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier   = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                if (item.caption.isNotBlank()) {
                    Text(
                        item.caption,
                        style    = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    "📂 ${item.category}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (item.status == "rejected" && item.rejectReason.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(8.dp),
                        color    = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "Reject ka karan:",
                                style      = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color      = MaterialTheme.colorScheme.error
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                item.rejectReason,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                when (item.status) {
                    "pending"  -> Text(
                        "Admin review kar raha hai. Approve hone par Live ho jayega.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    "approved" -> Text(
                        "🎉 Tera content ab app mein live hai!",
                        style      = MaterialTheme.typography.labelSmall,
                        color      = Color(0xFF16a34a),
                        fontWeight = FontWeight.SemiBold
                    )
                    "rejected" -> Text(
                        "Upar diye gaye karan se reject hua.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    when (item.status) {
                        "pending" -> OutlinedButton(
                            onClick = onCancel,
                            shape   = RoundedCornerShape(8.dp),
                            colors  = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Cancel Request", fontSize = 12.sp)
                        }
                        else -> OutlinedButton(
                            onClick = onDelete,
                            shape   = RoundedCornerShape(8.dp),
                            colors  = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Request to Delete", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  PROFILE HEADER
// ─────────────────────────────────────────────────────────────

@Composable
fun ProfileHeader(
    name             : String,
    email            : String,
    photoUrl         : Uri?,
    userPhone        : String,
    downloadsCount   : Int,
    myContentCount   : Int,
    downloadsLabel   : String = "Downloads",
    myContentLabel   : String = "My Content",
    userPlan         : String = "free",
    showCancelButton : Boolean = false, // 🌟 NEW STATE
    onCancelSubClick : () -> Unit = {},
    onEditPhoneClick : () -> Unit = {},
    strCustom        : (String, String, String) -> String
) {
    Column(
        modifier            = Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .border(
                    width  = 2.5.dp,
                    brush  = Brush.linearGradient(
                        listOf(Color(0xFFE040FB), Color(0xFFFF6D00), Color(0xFFFFD600))
                    ),
                    shape  = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model              = photoUrl,
                contentDescription = null,
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop,
                error              = painterResource(R.drawable.logo),
                placeholder        = painterResource(R.drawable.logo)
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Text(
            email,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // ── Phone Number Section ──
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (userPhone.isNotBlank()) "+91 $userPhone" else strCustom("फ़ोन नंबर जोड़ें", "फोन नंबर जोडा", "Add Phone Number"),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = if (userPhone.isNotBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = onEditPhoneClick, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Edit Phone", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }

        // ── Subscription Section ──
        if (userPlan == "pro") {
            Spacer(Modifier.height(12.dp))
            Surface(
                color = Color(0xFF16a34a).copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text       = "👑 Pro Member",
                    color      = Color(0xFF16a34a),
                    modifier   = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize   = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // 🌟 NEW: Button will only show if within 24 hours
            if (showCancelButton) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onCancelSubClick,
                    colors  = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    border  = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
                ) {
                    Text(strCustom("सदस्यता रद्द करें", "सदस्यत्व रद्द करा", "Cancel Subscription"), fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(
            modifier              = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    downloadsCount.toString(),
                    style      = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    downloadsLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Divider(
                modifier = Modifier.height(36.dp).width(1.dp),
                color    = MaterialTheme.colorScheme.outlineVariant
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    myContentCount.toString(),
                    style      = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    myContentLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
    }
}

// ─────────────────────────────────────────────────────────────
//  HELP & SUPPORT DIALOG
// ─────────────────────────────────────────────────────────────

@Composable
fun HelpSupportDialog(
    appLang   : String,
    userEmail : String,
    userName  : String,
    onDismiss : () -> Unit
) {
    val context    = LocalContext.current
    val appVersion = remember {
        try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown" }
        catch (_: Exception) { "unknown" }
    }

    LaunchedEffect(Unit) {
        var uPhone = "Not Set"
        var uPlan = "free"
        val uid = GoogleAuthHelper.currentUser?.uid
        if (uid != null) {
            try {
                val doc = FirebaseFirestore.getInstance().collection("users").document(uid)
                    .get(com.google.firebase.firestore.Source.CACHE).await()
                uPhone = doc.getString("phone")?.takeIf { it.isNotBlank() } ?: "Not Set"
                uPlan = doc.getString("plan") ?: "free"
            } catch (e: Exception) {}
        }

        val subject = "StatusSeva Help & Support"
        val body    = """Hello,

Query: [Please describe your issue here]

---
Device Info
OS Version: Android ${android.os.Build.VERSION.RELEASE}
App Version: $appVersion

User Info:
Name: $userName
Email: $userEmail
Phone: $uPhone
Plan: $uPlan Active"""

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL,   arrayOf("statusseva@gmail.com"))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT,    body)
        }

        try {
            context.startActivity(Intent.createChooser(intent, "Send Email"))
        } catch (_: Exception) {}
        onDismiss()
    }
}


// ─────────────────────────────────────────────────────────────
//  GRID CELL
// ─────────────────────────────────────────────────────────────

@Composable
fun GridCell(
    post        : DownloadedPost,
    isSelected  : Boolean,
    manageMode  : Boolean,
    modifier    : Modifier = Modifier,
    onCellClick : () -> Unit
) {
    val isVideo = remember(post.imageUrl) {
        post.imageUrl.contains(".mp4", ignoreCase = true) ||
                post.imageUrl.contains("video", ignoreCase = true)
    }
    var videoThumb by remember(post.imageUrl) { mutableStateOf(thumbnailCache[post.imageUrl]) }

    LaunchedEffect(post.imageUrl) {
        if (!isVideo || videoThumb != null) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(post.imageUrl, HashMap())
                val frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                retriever.release()
                if (frame != null) { thumbnailCache[post.imageUrl] = frame; videoThumb = frame }
            } catch (_: Exception) {}
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(2.dp))
            .clickable { onCellClick() }
    ) {
        when {
            isVideo && videoThumb != null -> Image(
                bitmap             = videoThumb!!.asImageBitmap(),
                contentDescription = post.title,
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop
            )
            isVideo -> {
                val infiniteTransition = rememberInfiniteTransition(label = "thumb_shimmer")
                val shimmerX by infiniteTransition.animateFloat(
                    initialValue  = -300f, targetValue = 300f,
                    animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
                    label         = "sX"
                )
                Box(
                    modifier         = Modifier.fillMaxSize().background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                            ),
                            start = Offset(shimmerX - 150f, 0f),
                            end   = Offset(shimmerX + 150f, 0f)
                        )
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.VideoFile, null,
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            else -> AsyncImage(
                model              = post.imageUrl,
                contentDescription = post.title,
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop
            )
        }

        if (isVideo) {
            Box(
                modifier         = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier         = Modifier.size(30.dp).clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, "Video", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))))
                .padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
            Text(
                post.title,
                color    = Color.White,
                fontSize = 9.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        AnimatedVisibility(
            visible = manageMode,
            enter   = fadeIn(tween(180)),
            exit    = fadeOut(tween(180))
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(
                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                    else Color.Black.copy(alpha = 0.12f)
                ),
                contentAlignment = Alignment.TopEnd
            ) {
                if (isSelected)
                    Icon(
                        Icons.Default.CheckCircle, null,
                        tint     = Color.White,
                        modifier = Modifier.padding(5.dp).size(20.dp)
                    )
                else
                    Box(
                        modifier = Modifier.padding(5.dp).size(20.dp)
                            .clip(CircleShape).border(2.dp, Color.White, CircleShape)
                    )
            }
        }
    }
}