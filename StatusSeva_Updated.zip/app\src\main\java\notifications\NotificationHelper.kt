package com.statusseva.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresPermission
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.statusseva.app.R
import kotlin.random.Random

object NotificationHelper {

    private const val CHANNEL_ID = "daily_motivation_channel"

    fun createNotificationChannel(context: Context) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val name = "Daily Motivation"
            val descriptionText = "Daily 8 AM motivational notification"
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(
                CHANNEL_ID,
                name,
                importance
            ).apply {
                description = descriptionText
            }

            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE)
                        as NotificationManager

            notificationManager.createNotificationChannel(channel)
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun showNotification(context: Context) {

        val messages = listOf(
            "Start your day with positivity 💪",
            "Believe in yourself today 🌟",
            "Small steps lead to big success 🚀",
            "Stay strong and keep moving 🔥",
            "Your future is created today ✨"
        )

        val randomMessage = messages.random()

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.logo)
            .setContentTitle("Status Seva")
            .setContentText(randomMessage)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        val manager = NotificationManagerCompat.from(context)
        manager.notify(1, builder.build())  // 👈 Fixed ID
    }
    }