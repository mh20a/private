package com.statusseva.app.ui.feedback

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackScreen(onBack: () -> Unit) {

    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val firestore      = remember { FirebaseFirestore.getInstance() }
    val currentUser    = remember { FirebaseAuth.getInstance().currentUser }

    // ── State ─────────────────────────────────────────────────
    var feedbackText   by remember { mutableStateOf("") }
    var selectedRating by remember { mutableStateOf(0) }       // 0 = no rating yet
    var isSubmitting   by remember { mutableStateOf(false) }
    var isSubmitted    by remember { mutableStateOf(false) }
    var errorMsg       by remember { mutableStateOf<String?>(null) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title        = { Text("Feedback", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBack) { // FIX: Changed from navController
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { padding ->

        AnimatedContent(
            targetState    = isSubmitted,
            transitionSpec = {
                fadeIn(tween(400)) + slideInVertically { it / 8 } togetherWith
                        fadeOut(tween(200))
            },
            label = "feedback_content",
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) { submitted ->

            if (submitted) {
                // ── Thank You Screen ──────────────────────────
                Box(
                    modifier         = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier            = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Checkmark circle
                        Box(
                            modifier         = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF22C55E).copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector        = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint               = Color(0xFF22C55E),
                                modifier           = Modifier.size(52.dp)
                            )
                        }

                        Spacer(Modifier.height(24.dp))

                        Text(
                            text       = "Thank You! 🙏",
                            style      = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            textAlign  = TextAlign.Center
                        )

                        Spacer(Modifier.height(10.dp))

                        Text(
                            text      = "Your feedback has been received.\nIt helps us make StatusSeva better for you.",
                            style     = MaterialTheme.typography.bodyMedium,
                            color     = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(Modifier.height(36.dp))

                        Button(
                            onClick = onBack, // FIX: Changed from navController
                            shape   = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .height(48.dp)
                        ) {
                            Text("Go Back", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

            } else {
                // ── Feedback Form ─────────────────────────────
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {

                    // ── Header card ───────────────────────────
                    Surface(
                        shape          = RoundedCornerShape(16.dp),
                        tonalElevation = 1.dp,
                        modifier       = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier            = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text       = "💬",
                                fontSize   = 36.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text       = "Share Your Thoughts",
                                style      = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign  = TextAlign.Center
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text      = "Help us improve by sharing your experience",
                                style     = MaterialTheme.typography.bodySmall,
                                color     = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // ── Star Rating ───────────────────────────
                    Surface(
                        shape          = RoundedCornerShape(16.dp),
                        tonalElevation = 1.dp,
                        modifier       = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "Rate your experience",
                                style      = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color      = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(14.dp))
                            Row(
                                modifier              = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment     = Alignment.CenterVertically
                            ) {
                                repeat(5) { index ->
                                    val starIndex = index + 1
                                    val isFilled  = starIndex <= selectedRating

                                    // Bounce animation on selection
                                    val scale by animateFloatAsState(
                                        targetValue   = if (isFilled) 1.2f else 1f,
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioMediumBouncy,
                                            stiffness    = Spring.StiffnessMedium
                                        ),
                                        label = "star_scale_$index"
                                    )

                                    IconButton(
                                        onClick  = { selectedRating = starIndex },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector        = if (isFilled) Icons.Default.Star else Icons.Default.StarOutline,
                                            contentDescription = "Star $starIndex",
                                            tint               = if (isFilled) Color(0xFFFFC107)
                                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                                            modifier           = Modifier
                                                .size(36.dp)
                                                .graphicsLayer { scaleX = scale; scaleY = scale }
                                        )
                                    }
                                }
                            }

                            // Rating label
                            AnimatedVisibility(visible = selectedRating > 0) {
                                Text(
                                    text      = when (selectedRating) {
                                        1 -> "😞 Poor"
                                        2 -> "😕 Fair"
                                        3 -> "😊 Good"
                                        4 -> "😄 Great"
                                        5 -> "🤩 Excellent!"
                                        else -> ""
                                    },
                                    style     = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color     = when (selectedRating) {
                                        1, 2 -> MaterialTheme.colorScheme.error
                                        3    -> Color(0xFFF59E0B)
                                        4, 5 -> Color(0xFF22C55E)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    },
                                    modifier  = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // ── Message input ─────────────────────────
                    Surface(
                        shape          = RoundedCornerShape(16.dp),
                        tonalElevation = 1.dp,
                        modifier       = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "Your feedback",
                                style      = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color      = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value         = feedbackText,
                                onValueChange = {
                                    if (it.length <= 500) feedbackText = it
                                },
                                placeholder   = {
                                    Text(
                                        "Tell us what you love, what could be better, or any suggestions...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                },
                                modifier      = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp),
                                shape         = RoundedCornerShape(12.dp),
                                maxLines      = 8
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text  = "${feedbackText.length}/500",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (feedbackText.length > 450)
                                    MaterialTheme.colorScheme.error
                                else
                                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    // ── Error message ─────────────────────────
                    AnimatedVisibility(visible = errorMsg != null) {
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier          = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline, null,
                                    tint     = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text  = errorMsg ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    // ── Submit button ─────────────────────────
                    val canSubmit = feedbackText.trim().length >= 10 && !isSubmitting

                    Button(
                        onClick = {
                            if (selectedRating == 0 && feedbackText.trim().length < 10) {
                                errorMsg = "Please write at least 10 characters."
                                return@Button
                            }
                            errorMsg = null
                            coroutineScope.launch {
                                isSubmitting = true
                                try {
                                    val data = hashMapOf(
                                        "message"   to feedbackText.trim(),
                                        "rating"    to selectedRating,
                                        "userName"  to (currentUser?.displayName ?: "Anonymous"),
                                        "userEmail" to (currentUser?.email       ?: ""),
                                        "userId"    to (currentUser?.uid         ?: ""),
                                        "createdAt" to System.currentTimeMillis()
                                    )
                                    firestore.collection("feedback").add(data).await()
                                    isSubmitted = true
                                } catch (e: Exception) {
                                    errorMsg = "Failed to submit. Please try again."
                                } finally {
                                    isSubmitting = false
                                }
                            }
                        },
                        enabled  = canSubmit || selectedRating > 0,
                        shape    = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier    = Modifier.size(22.dp),
                                strokeWidth = 2.5.dp,
                                color       = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Submit Feedback",
                                style      = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Text(
                        "Your feedback is anonymous and helps improve the app.",
                        style     = MaterialTheme.typography.labelSmall,
                        color     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center,
                        modifier  = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}