package com.statusseva.app.ui.navigation
import androidx.compose.material.icons.filled.*
sealed class Screen(val route: String) {

    object Home : Screen("home")
    object Downloads : Screen("downloads")
    object Profile : Screen("profile")
    object Settings : Screen("settings")
}