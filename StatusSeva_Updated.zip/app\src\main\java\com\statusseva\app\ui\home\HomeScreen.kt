package com.statusseva.app.ui.home

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.ImageLoader
import coil.compose.AsyncImagePainter
import coil.compose.rememberAsyncImagePainter
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Size
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.statusseva.app.R
import com.statusseva.app.data.AppDownloadManager
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.GallerySaver
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.ProfileManager
import com.statusseva.app.data.UserBrandingManager
import com.statusseva.app.data.HqImageCache
import com.statusseva.app.data.WatermarkHelper
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.model.DownloadedPost
import com.statusseva.app.model.Post
import com.statusseva.app.ui.branding1.BrandingBottomSheetContent
import com.statusseva.app.ui.components.PremiumUnlockSheet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

object HomeStateCache {
    var posts        : List<Post>?       = null
    var lastDoc      : DocumentSnapshot? = null
    var lang         : String            = ""
    var category     : String            = "All"
    var scrollIndex  : Int               = 0
    var scrollOffset : Int               = 0
}

data class FirestoreCategory(
    val id           : String  = "",
    val name         : String  = "",
    val icon         : String  = "",
    val color        : String  = "",
    val showOnHome   : Boolean = true,
    val showOnExplore: Boolean = true,
    val position     : Int     = Int.MAX_VALUE,
    val bgImageUrl   : String  = "",
    val textColor    : String  = ""
)

private const val PAGE_SIZE  = 5
private const val LOAD_AHEAD = 3

private fun parsePost(doc: DocumentSnapshot): Post? {
    return try {
        val rawImageUrl = doc.getString("imageUrl") ?: ""
        val rawVideoUrl = doc.getString("videoUrl") ?: ""
        val isVideo     = rawImageUrl.contains(".mp4", ignoreCase = true) || rawVideoUrl.isNotBlank()

        val thumbUrl    = if (!isVideo && rawImageUrl.isNotBlank() && rawImageUrl.startsWith("https://firebasestorage.googleapis.com")) {
            val insertPoint = rawImageUrl.indexOf("?")
            if (insertPoint != -1) {
                val before = rawImageUrl.substring(0, insertPoint)
                val after  = rawImageUrl.substring(insertPoint)
                val ext    = listOf(".jpg", ".jpeg", ".png", ".webp")
                    .firstOrNull { before.endsWith(it, ignoreCase = true) } ?: ""
                if (ext.isNotEmpty()) before.dropLast(ext.length) + "_800x800$ext$after"
                else rawImageUrl
            } else rawImageUrl
        } else rawImageUrl

        @Suppress("UNCHECKED_CAST")
        val tags = (doc.get("tags") as? List<String>) ?: emptyList()

        Post(
            id          = doc.id,
            title       = doc.getString("title")       ?: "",
            description = doc.getString("description") ?: "",
            category    = doc.getString("category")    ?: "",
            imageUrl    = thumbUrl,
            videoUrl    = rawVideoUrl.ifBlank { rawImageUrl },
            type        = if (isVideo) "video" else "image",
            createdAt   = doc.getLong("createdAt")     ?: 0L,
            isFeatured  = false,
            language    = doc.getString("language")    ?: "",
            tags        = tags,
            position    = doc.getLong("position")?.toInt() ?: Int.MAX_VALUE,
            aspectRatio = doc.getDouble("aspectRatio")
        )
    } catch (_: Exception) { null }
}

@Composable
private fun CategoryChip(
    label    : String,
    selected : Boolean,
    onClick  : () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick  = onClick,
        modifier = Modifier.height(30.dp),
        label    = { Text(text = label, style = MaterialTheme.typography.labelSmall) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor     = MaterialTheme.colorScheme.onPrimary,
            containerColor         = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            labelColor             = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled             = true,
            selected            = selected,
            borderColor         = Color.Transparent,
            selectedBorderColor = Color.Transparent
        )
    )
}

fun isBrandingColorLight(color: Int): Boolean {
    if (color == -3) return false
    if (color == -2) return true
    val r = (color shr 16 and 0xFF) / 255.0
    val g = (color shr 8  and 0xFF) / 255.0
    val b = (color        and 0xFF) / 255.0
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) > 0.5
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigate      : (String) -> Unit,
    selectedPostId  : String? = null,
    initialCategory : String? = null,
    appLang         : String  = "hi",
    paywallEnabled  : Boolean = false,
    userPlan        : String  = "free",
    isVisible       : Boolean = true
) {
    val context   = LocalContext.current
    val activity  = context as? Activity
    val firestore = remember { FirebaseFirestore.getInstance() }

    fun str(key: String) = AppStrings.get(key, appLang)

    val imageLoader = remember {
        ImageLoader.Builder(context)
            .memoryCache { MemoryCache.Builder(context).maxSizePercent(0.20).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(context.cacheDir, "image_cache"))
                    .maxSizeBytes(200L * 1024L * 1024L)
                    .build()
            }
            .crossfade(true)
            .respectCacheHeaders(false)
            .build()
    }

    val prefs: SharedPreferences = remember {
        context.getSharedPreferences("notif_prefs", Context.MODE_PRIVATE)
    }

    var contentLang by remember { mutableStateOf(LanguagePreference.getContentLanguage(context)) }
    val myUserId = remember { ProfileManager.getUserId() }

    var lastSeenCount: Int by remember { mutableStateOf(prefs.getInt("last_seen_count", 0)) }
    var showShimmer        by remember { mutableStateOf(HomeStateCache.posts == null) }
    var errorMessage       by remember { mutableStateOf<String?>(null) }
    var searchMode         by remember { mutableStateOf(false) }
    var searchQuery        by remember { mutableStateOf("") }
    var debouncedQuery     by remember { mutableStateOf("") }
    var selectedCategory   by remember { mutableStateOf(HomeStateCache.category.ifBlank { initialCategory ?: "All" }) }

    LaunchedEffect(initialCategory) {
        if (!initialCategory.isNullOrBlank() && initialCategory != selectedCategory) {
            selectedCategory = initialCategory
        }
    }
    var unreadCount        by remember { mutableStateOf(0) }
    var homeChipCategories by remember { mutableStateOf<List<FirestoreCategory>>(emptyList()) }

    val allPosts      = remember { mutableStateListOf<Post>().apply { addAll(HomeStateCache.posts ?: emptyList()) } }
    var lastDoc       by remember { mutableStateOf<DocumentSnapshot?>(HomeStateCache.lastDoc) }
    var hasMore       by remember { mutableStateOf(true) }
    var isLoadingMore by remember { mutableStateOf(false) }

    var showBrandingSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = HomeStateCache.scrollIndex,
        initialFirstVisibleItemScrollOffset = HomeStateCache.scrollOffset
    )

    val coroutineScope = rememberCoroutineScope()
    val pullToRefreshState = rememberPullToRefreshState()
    var isRefreshing by remember { mutableStateOf(false) }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    val globalExoPlayer = remember {
        val cache          = getVideoCache(context)
        val cacheFactory   = androidx.media3.datasource.cache.CacheDataSource.Factory()
            .setCache(cache).setUpstreamDataSourceFactory(androidx.media3.datasource.DefaultDataSource.Factory(context))
        val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(cacheFactory)

        val loadControl    = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(1000, 30_000, 500, 1_000)
            .setPrioritizeTimeOverSizeThresholds(true).build()

        androidx.media3.exoplayer.ExoPlayer.Builder(context).setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl).build().apply { repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE }
    }

    DisposableEffect(Unit) { onDispose { globalExoPlayer.release() } }

    LaunchedEffect(isVisible) {
        if (!isVisible) {
            globalExoPlayer.pause()
        } else {
            val newLang = LanguagePreference.getContentLanguage(context)
            if (contentLang != newLang) {
                contentLang = newLang
            }
            searchMode = false
            searchQuery = ""
        }
    }

    LaunchedEffect(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) {
        HomeStateCache.scrollIndex = listState.firstVisibleItemIndex
        HomeStateCache.scrollOffset = listState.firstVisibleItemScrollOffset
    }

    val cachedGooglePhoto = remember { FirebaseAuth.getInstance().currentUser?.photoUrl }

    BackHandler(enabled = searchMode) { searchMode = false; searchQuery = "" }
    BackHandler(enabled = !searchMode && selectedCategory != "All") { selectedCategory = "All" }

    suspend fun fetchPostsAggressively(startAfter: DocumentSnapshot?): Pair<List<Post>, DocumentSnapshot?> {
        val fetchedPosts = mutableListOf<Post>()
        var currentAnchor = startAfter
        var more = true
        val qStr = debouncedQuery.trim()

        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val isMorningTime = currentHour in 4..9
        val isNightTime   = currentHour in 19..23

        while (fetchedPosts.size < PAGE_SIZE && more) {
            var q = firestore.collection("posts")
                .orderBy("position", Query.Direction.ASCENDING)
                .limit(PAGE_SIZE.toLong())

            if (currentAnchor != null) {
                q = q.startAfter(currentAnchor)
            }

            val snap = q.get().await()
            if (snap.isEmpty) {
                more = false
                break
            }

            val rawPosts = snap.documents.mapNotNull { parsePost(it) }

            val valid = rawPosts.filter { post ->
                val matchLang = contentLang.isBlank() || post.language.isBlank() || post.language.equals(contentLang, true)
                val matchCat = selectedCategory == "All" || post.category.equals(selectedCategory, true)
                val matchSearch = qStr.isEmpty() || post.title.contains(qStr, true) || post.description.contains(qStr, true) || post.tags.any { it.contains(qStr, true) }
                val isNotBlocked = post.uploadedBy.isNullOrEmpty() || !com.statusseva.app.data.BlockedUserManager.blockedUids.contains(post.uploadedBy)

                matchLang && matchCat && matchSearch && isNotBlocked
            }

            fetchedPosts.addAll(valid)
            currentAnchor = snap.documents.lastOrNull()
        }

        val finalSortedList = if (selectedCategory == "All" && qStr.isEmpty()) {
            when {
                isMorningTime -> {
                    fetchedPosts.sortedWith(
                        compareByDescending<Post> { it.category == "सुप्रभात" || it.category == "शुभ सकाळ" }
                            .thenBy { it.position }
                            .thenByDescending { it.createdAt }
                    )
                }
                isNightTime -> {
                    fetchedPosts.sortedWith(
                        compareByDescending<Post> { it.category == "शुभ रात्रि" || it.category == "शुभ रात्री" }
                            .thenBy { it.position }
                            .thenByDescending { it.createdAt }
                    )
                }
                else -> {
                    fetchedPosts.sortedWith(
                        compareBy<Post> { it.position }
                            .thenByDescending { it.createdAt }
                    )
                }
            }
        } else {
            fetchedPosts
        }

        return Pair(finalSortedList, currentAnchor)
    }

    suspend fun loadFirstPage() {
        if (!isRefreshing) showShimmer = true
        errorMessage = null
        allPosts.clear()
        lastDoc = null
        hasMore = true
        try {
            val (newPosts, nextAnchor) = fetchPostsAggressively(null)
            allPosts.clear()
            allPosts.addAll(newPosts)
            lastDoc = nextAnchor
            hasMore = nextAnchor != null
            showShimmer = false
            HomeStateCache.posts = allPosts
            HomeStateCache.lastDoc = lastDoc
        } catch (e: Exception) {
            errorMessage = e.message
            showShimmer = false
        }
    }

    suspend fun loadNextPage() {
        val anchor = lastDoc ?: return
        if (!hasMore || isLoadingMore) return
        isLoadingMore = true
        try {
            val (newPosts, nextAnchor) = fetchPostsAggressively(anchor)
            allPosts.addAll(newPosts)
            lastDoc = nextAnchor ?: lastDoc
            hasMore = nextAnchor != null
            HomeStateCache.posts = allPosts
            HomeStateCache.lastDoc = lastDoc
        } catch (_: Exception) {}
        isLoadingMore = false
    }

    LaunchedEffect(contentLang, selectedCategory, debouncedQuery) {
        HomeStateCache.lang = contentLang
        HomeStateCache.category = selectedCategory
        coroutineScope.launch { loadFirstPage() }
    }

    LaunchedEffect(contentLang) {
        firestore.collection("categories").addSnapshotListener { snap, _ ->
            if (snap != null) {
                homeChipCategories = snap.documents.mapNotNull { doc ->
                    val showOnHome = doc.getBoolean("showOnHome") ?: true
                    if (!showOnHome) return@mapNotNull null
                    val name = doc.getString("name") ?: return@mapNotNull null
                    val catLang = doc.getString("language") ?: ""
                    if (catLang.isNotBlank() && catLang != contentLang) return@mapNotNull null
                    FirestoreCategory(
                        id            = doc.id,
                        name          = name,
                        icon          = doc.getString("icon")           ?: "",
                        color         = doc.getString("color")          ?: "",
                        showOnHome    = true,
                        showOnExplore = doc.getBoolean("showOnExplore") ?: true,
                        position      = doc.getLong("position")?.toInt() ?: Int.MAX_VALUE,
                        bgImageUrl    = doc.getString("bgImageUrl")     ?: "",
                        textColor     = doc.getString("textColor")      ?: ""
                    )
                }.sortedWith(compareBy<FirestoreCategory> { it.position }.thenBy { it.name })
            }
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && activity != null) {
            ActivityCompat.requestPermissions(activity, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    LaunchedEffect(searchQuery) { delay(300); debouncedQuery = searchQuery }

    DisposableEffect(Unit) {
        val listener = firestore.collection("notifications").addSnapshotListener { snapshot, _ ->
            if (snapshot == null) { unreadCount = 0; return@addSnapshotListener }
            val relevant = snapshot.documents.count { doc ->
                val specificUid = doc.getString("specificUserId")?.trim() ?: ""
                val notifLang   = doc.getString("language")?.trim()        ?: ""
                (specificUid.isBlank() || specificUid == myUserId) &&
                        (notifLang.isBlank()   || notifLang == contentLang)
            }
            unreadCount = if (relevant > lastSeenCount) relevant - lastSeenCount else 0
        }
        onDispose { listener.remove() }
    }

    val visibleIndex by remember { derivedStateOf { listState.firstVisibleItemIndex } }

    LaunchedEffect(visibleIndex, allPosts.size) {
        if (allPosts.isNotEmpty() && visibleIndex >= allPosts.size - LOAD_AHEAD && hasMore && !isLoadingMore) {
            coroutineScope.launch { loadNextPage() }
        }
    }

    @kotlin.OptIn(FlowPreview::class)
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .debounce(200)
            .collectLatest { idx ->
                val limit = minOf(idx + 3, allPosts.size)
                for (i in idx until limit) {
                    val post = allPosts[i]
                    if (post.type == "image" && post.imageUrl.isNotBlank()) {
                        imageLoader.enqueue(ImageRequest.Builder(context).data(post.imageUrl)
                            .memoryCachePolicy(CachePolicy.ENABLED).diskCachePolicy(CachePolicy.ENABLED)
                            .size(Size(800, 800)).build())

                        val hqUrl = post.imageUrl.replace("_800x800", "")
                        launch(Dispatchers.IO) {
                            HqImageCache.preCacheIfNeeded(context, hqUrl)
                        }
                    }
                }
            }
    }

    val playingIndex by remember {
        derivedStateOf {
            if (!isVisible) return@derivedStateOf -1
            val layoutInfo   = listState.layoutInfo
            val visibleItems = layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) return@derivedStateOf -1
            val vpTop = layoutInfo.viewportStartOffset.toFloat()
            val vpBot = layoutInfo.viewportEndOffset.toFloat()
            var bestIndex = -1; var bestPct = 0f
            for (item in visibleItems) {
                val vis = (minOf((item.offset + item.size).toFloat(), vpBot) - maxOf(item.offset.toFloat(), vpTop)).coerceAtLeast(0f)
                val pct = vis / item.size.toFloat()
                if (pct > bestPct) { bestPct = pct; bestIndex = item.index }
            }
            if (bestPct >= 0.75f) bestIndex else -1
        }
    }

    LaunchedEffect(playingIndex, allPosts) {
        if (playingIndex == -1) {
            globalExoPlayer.pause()
        } else if (playingIndex in allPosts.indices) {
            val currentPost = allPosts[playingIndex]
            if (currentPost.type != "video") {
                globalExoPlayer.pause()
            }
        }
    }

    val allChips  = remember(homeChipCategories) { listOf("All") + homeChipCategories.map { it.name } }
    val row1Chips = remember(allChips) { allChips.take(3) }
    val row2Chips = remember(allChips) { allChips.drop(3) }

    val globalShimmerTrans = rememberInfiniteTransition(label = "global_shimmer")
    val globalShimmerX by globalShimmerTrans.animateFloat(initialValue = -600f, targetValue = 900f, animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "shimmer_x")

    val nestedScrollConnection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y < -5f) com.statusseva.app.SharedScrollState.isScrollingUp = false
                if (available.y > 5f) com.statusseva.app.SharedScrollState.isScrollingUp = true
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = Modifier.nestedScroll(nestedScrollConnection),
        topBar = {
            AnimatedVisibility(
                visible = com.statusseva.app.SharedScrollState.isScrollingUp || listState.firstVisibleItemIndex == 0,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                AnimatedContent(
                    targetState = searchMode,
                    transitionSpec = {
                        (slideInVertically { height -> -height } + fadeIn(tween(250)))
                            .togetherWith(slideOutVertically { height -> -height } + fadeOut(tween(250)))
                    },
                    label = "search_anim"
                ) { isSearch ->
                    if (isSearch) {
                        val focusRequester = remember { FocusRequester() }
                        val keyboardController = LocalSoftwareKeyboardController.current
                        LaunchedEffect(Unit) {
                            delay(200)
                            focusRequester.requestFocus()
                            keyboardController?.show()
                        }
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text(str("search_hint")) },
                                singleLine = true,
                                modifier = Modifier.weight(1f).focusRequester(focusRequester),
                                shape = RoundedCornerShape(50)
                            )
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = { searchMode = false; searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Close") }
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Row(modifier = Modifier.weight(1f).padding(start = 8.dp, top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    row1Chips.forEach { chipName ->
                                        val cat   = homeChipCategories.find { it.name == chipName }
                                        val label = if (chipName == "All") str("cat_all") else "${cat?.icon ?: ""} $chipName".trim()
                                        CategoryChip(label = label, selected = chipName == selectedCategory, onClick = { selectedCategory = chipName })
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        val total = unreadCount + lastSeenCount
                                        lastSeenCount = total
                                        prefs.edit().putInt("last_seen_count", total).apply()
                                        unreadCount = 0
                                        onNavigate("notifications")
                                    }) {
                                        BadgedBox(badge = {
                                            if (unreadCount > 0) Badge(containerColor = MaterialTheme.colorScheme.error) {
                                                Text(if (unreadCount > 99) "99+" else unreadCount.toString(), color = MaterialTheme.colorScheme.onError, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }) { Icon(Icons.Default.Notifications, contentDescription = "Notifications") }
                                    }
                                    IconButton(onClick = { searchMode = true }) { Icon(Icons.Default.Search, contentDescription = "Search") }
                                }
                            }
                            if (row2Chips.isNotEmpty()) {
                                LazyRow(modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp), contentPadding = PaddingValues(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    items(row2Chips.size) { idx ->
                                        val chipName = row2Chips[idx]
                                        val cat      = homeChipCategories.find { it.name == chipName }
                                        CategoryChip(label = "${cat?.icon ?: ""} $chipName".trim(), selected = chipName == selectedCategory, onClick = { selectedCategory = chipName })
                                    }
                                }
                            }
                        }
                    }
                }
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
            }
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = listState.firstVisibleItemIndex > 10,
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut()
            ) {
                FloatingActionButton(
                    onClick = {
                        coroutineScope.launch {
                            listState.animateScrollToItem(0)
                            com.statusseva.app.SharedScrollState.isScrollingUp = true
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(bottom = 72.dp)
                ) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Scroll to Top")
                }
            }
        }
    ) { innerPadding ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = {
                coroutineScope.launch {
                    isRefreshing = true
                    loadFirstPage()
                    isRefreshing = false
                }
            },
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            state = pullToRefreshState
        ) {
            if (showShimmer) {
                HomeShimmerList()
            } else {
                HomeContent(
                    posts               = allPosts,
                    listState           = listState,
                    errorMessage        = errorMessage,
                    onNavigate          = onNavigate,
                    imageLoader         = imageLoader,
                    playingIndexProvider= { playingIndex },
                    shimmerOffsetProvider = { globalShimmerX },
                    isLoadingMore       = isLoadingMore,
                    hasMore             = hasMore,
                    appLang             = appLang,
                    sharedPlayer        = globalExoPlayer,
                    paywallEnabled      = paywallEnabled,
                    userPlan            = userPlan,
                    cachedGooglePhoto   = cachedGooglePhoto,
                    onEditBrandingClick = { showBrandingSheet = true }
                )
            }
        }
    }

    if (showBrandingSheet) {
        ModalBottomSheet(
            onDismissRequest = { showBrandingSheet = false },
            sheetState       = sheetState,
            containerColor   = MaterialTheme.colorScheme.surface
        ) {
            BrandingBottomSheetContent(
                onDismiss = { showBrandingSheet = false }
            )
        }
    }
}

@Composable
fun HomeShimmerList() {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        items(4) {
            HomeShimmerCard()
            HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        }
    }
}

@Composable
fun HomeShimmerCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerX by infiniteTransition.animateFloat(initialValue = -700f, targetValue = 700f, animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "shimmerX")
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f), MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f), MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
        start = Offset(shimmerX - 300f, 0f), end = Offset(shimmerX + 300f, 0f)
    )
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(MaterialTheme.colorScheme.surface)) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Box(modifier = Modifier.width(80.dp).height(22.dp).clip(RoundedCornerShape(50)).background(shimmerBrush))
            Box(modifier = Modifier.width(50.dp).height(12.dp).clip(RoundedCornerShape(4.dp)).background(shimmerBrush))
        }
        Box(modifier = Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(12.dp)).background(shimmerBrush))
        Box(modifier = Modifier.padding(vertical = 10.dp).fillMaxWidth(0.65f).height(16.dp).clip(RoundedCornerShape(4.dp)).background(shimmerBrush))
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(modifier = Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp)).background(shimmerBrush))
            Box(modifier = Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp)).background(shimmerBrush))
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
fun HomeContent(
    posts              : List<Post>,
    listState          : LazyListState,
    errorMessage       : String?,
    onNavigate         : (String) -> Unit,
    imageLoader        : ImageLoader,
    playingIndexProvider: () -> Int,
    shimmerOffsetProvider: () -> Float,
    isLoadingMore      : Boolean,
    hasMore            : Boolean,
    appLang            : String  = "hi",
    sharedPlayer       : androidx.media3.exoplayer.ExoPlayer? = null,
    modifier           : Modifier = Modifier,
    paywallEnabled     : Boolean  = false,
    userPlan           : String   = "free",
    cachedGooglePhoto  : Uri? = null,
    onEditBrandingClick: () -> Unit
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    Box(modifier = modifier.fillMaxSize()) {
        when {
            errorMessage != null -> {
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.WifiOff, null, modifier = Modifier.size(48.dp).alpha(0.4f))
                    Spacer(Modifier.height(12.dp))
                    Text(str("load_error"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(0.6f))
                }
            }
            posts.isEmpty() -> {
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ImageSearch, null, modifier = Modifier.size(56.dp).alpha(0.35f))
                    Spacer(Modifier.height(12.dp))
                    Text(str("no_posts"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(0.5f))
                }
            }
            else -> {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                    itemsIndexed(items = posts, key = { _, post -> post.id }) { index, post ->
                        PostCardFeed(
                            post                = post,
                            index               = index,
                            imageLoader         = imageLoader,
                            onNavigate          = onNavigate,
                            playingIndexProvider= playingIndexProvider,
                            shimmerOffsetProvider = shimmerOffsetProvider,
                            appLang             = appLang,
                            sharedPlayer        = sharedPlayer,
                            paywallEnabled      = paywallEnabled,
                            userPlan            = userPlan,
                            cachedGooglePhoto   = cachedGooglePhoto,
                            onEditBrandingClick = onEditBrandingClick
                        )
                        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    }
                    if (isLoadingMore) {
                        item(key = "loading_more") {
                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                            }
                        }
                    }
                    if (!hasMore && posts.isNotEmpty()) {
                        item(key = "end_indicator") {
                            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text  = when (appLang) { "hi" -> "सभी पोस्ट लोड हो गई हैं"; "mr" -> "सर्व पोस्ट लोड झाल्या"; else -> "All posts loaded" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PostCardFeed(
    post               : Post,
    index              : Int,
    imageLoader        : ImageLoader,
    onNavigate         : (String) -> Unit,
    playingIndexProvider: () -> Int,
    shimmerOffsetProvider: () -> Float,
    appLang            : String  = "hi",
    sharedPlayer       : androidx.media3.exoplayer.ExoPlayer? = null,
    onImageLoaded      : (Int) -> Unit = {},
    paywallEnabled     : Boolean = false,
    userPlan           : String  = "free",
    cachedGooglePhoto  : Uri? = null,
    onEditBrandingClick: () -> Unit
) {
    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isDownloading  by remember { mutableStateOf(false) }
    var isWaSharing    by remember { mutableStateOf(false) }
    fun str(key: String) = AppStrings.get(key, appLang)

    val isPaywalled     = paywallEnabled && userPlan == "free"

    val isTallMedia = post.aspectRatio != null && post.aspectRatio < 0.9
    val sidePadding = if (isTallMedia) 24.dp else 12.dp

    var pendingDownloadAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showPremiumUnlockSheet by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            pendingDownloadAction?.invoke()
        } else {
            val msg = when (appLang) {
                "hi" -> "सेव करने के लिए स्टोरेज परमिशन चाहिए"
                "mr" -> "सेव्ह करण्यासाठी स्टोरेज परवानगी आवश्यक आहे"
                else -> "Storage Permission Required to Download"
            }
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
        pendingDownloadAction = null
    }

    fun checkStorageAndExecute(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Android 9 and below: Definitely need WRITE_EXTERNAL_STORAGE
            val permission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                action()
            } else {
                pendingDownloadAction = action
                permissionLauncher.launch(permission)
            }
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            // Android 10, 11, 12: Request permission for legacy/manufacturers logic
            val permission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                action()
            } else {
                pendingDownloadAction = action
                permissionLauncher.launch(permission)
            }
        } else {
            // Android 13+: Direct MediaStore (No WRITE permission exists)
            action()
        }
    }

    fun handleAction(action: () -> Unit) {
        val requiresPremium = com.statusseva.app.data.UserBrandingManager.isBrandingEnabled && userPlan == "free"
        if (requiresPremium) {
            pendingDownloadAction = action
            showPremiumUnlockSheet = true
        } else {
            checkStorageAndExecute(action)
        }
    }

    Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = sidePadding)) {

        var showReportMenu   by remember { mutableStateOf(false) }
        var showReportDialog by remember { mutableStateOf(false) }
        var reportReason     by remember { mutableStateOf("") }
        var reportSubmitting by remember { mutableStateOf(false) }

        if (showReportDialog) {
            AlertDialog(
                onDismissRequest = { if (!reportSubmitting) { showReportDialog = false; reportReason = "" } },
                title   = { Text("Report Content", fontWeight = FontWeight.Bold) },
                text    = {
                    Column {
                        Text(
                            "Please describe why you are reporting this content.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value         = reportReason,
                            onValueChange = { reportReason = it },
                            label         = { Text("Reason to report this content") },
                            placeholder   = { Text("e.g. Inappropriate, Spam, Offensive…") },
                            modifier      = Modifier.fillMaxWidth(),
                            minLines      = 3,
                            maxLines      = 5,
                            enabled       = !reportSubmitting
                        )
                    }
                },
                confirmButton = {
                    Button(
                        enabled = reportReason.isNotBlank() && !reportSubmitting,
                        onClick = {
                            reportSubmitting = true
                            coroutineScope.launch {
                                try {
                                    val myUid   = GoogleAuthHelper.currentUser?.uid   ?: "anonymous"
                                    val myName  = GoogleAuthHelper.currentUser?.displayName ?: "User"
                                    val myEmail = GoogleAuthHelper.currentUser?.email ?: ""
                                    val hqUrl   = post.imageUrl.replace("_800x800", "")
                                    val reportData = hashMapOf(
                                        "postId"          to post.id,
                                        "reportedByUid"   to myUid,
                                        "reportedByName"  to myName,
                                        "reportedByEmail" to myEmail,
                                        "uploadedByUid"   to (post.uploadedBy ?: ""),
                                        "uploadedByName"  to "Admin / User",
                                        "contentCaption"  to post.title.ifBlank { post.category },
                                        "contentImageUrl" to if (post.type == "video") post.videoUrl else hqUrl,
                                        "reason"          to reportReason.trim(),
                                        "language"        to post.language,
                                        "status"          to "pending",
                                        "reportCount"     to 1,
                                        "createdAt"       to FieldValue.serverTimestamp()
                                    )
                                    FirebaseFirestore.getInstance().collection("reports").add(reportData).await()
                                    showReportDialog = false
                                    reportReason     = ""
                                    Toast.makeText(context, "Content reported. Admins will review it.", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Failed to report: ${e.message}", Toast.LENGTH_LONG).show()
                                } finally {
                                    reportSubmitting = false
                                }
                            }
                        }
                    ) {
                        if (reportSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(6.dp))
                        }
                        Text("Submit")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showReportDialog = false; reportReason = "" }, enabled = !reportSubmitting) {
                        Text("Cancel")
                    }
                }
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    IconButton(onClick = { showReportMenu = true }, modifier = Modifier.size(24.dp).padding(end = 6.dp)) {
                        Icon(Icons.Default.MoreVert, "More Options", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    DropdownMenu(expanded = showReportMenu, onDismissRequest = { showReportMenu = false }) {
                        DropdownMenuItem(
                            text    = { Text("Report Content", color = MaterialTheme.colorScheme.error) },
                            onClick = { showReportMenu = false; showReportDialog = true }
                        )
                        val currentUserUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
                        if (!post.uploadedBy.isNullOrBlank() && post.uploadedBy != currentUserUid) {
                            DropdownMenuItem(
                                text    = { Text("Block User", color = MaterialTheme.colorScheme.error) },
                                onClick = { 
                                    showReportMenu = false
                                    com.statusseva.app.data.BlockedUserManager.blockUser(post.uploadedBy!!, "Blocked User")
                                    Toast.makeText(context, "User Blocked. Please refresh.", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(text = post.category.ifBlank { "General" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
                }
            }
            if (post.createdAt > 0L) {
                Text(text = getRelativeTime(post.createdAt, appLang), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Surface(shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {

            // 🌟 FIXED AUTOCROP/PICHKI FRAME BUG 🌟
            // First check if a valid aspect ratio is provided by Firestore
            val validRatio = post.aspectRatio != null && post.aspectRatio > 0.0

            val mediaModifier = Modifier.fillMaxWidth().then(
                if (validRatio) {
                    // Force the parent Box to the EXACT aspect ratio of the image immediately
                    Modifier.aspectRatio(post.aspectRatio!!.toFloat())
                } else {
                    // Fallback if there is NO ratio available on the server
                    Modifier.wrapContentHeight()
                }
            )

            Box(modifier = mediaModifier) {
                if (post.type == "video" && post.videoUrl.isNotBlank()) {
                    LaunchedEffect(Unit) { onImageLoaded(index) }
                    VideoPlayer(
                        videoUrl = post.videoUrl,
                        isVisible = playingIndexProvider() == index,
                        sharedPlayer = sharedPlayer,
                        aspectRatio = post.aspectRatio?.toFloat(),
                        modifier = Modifier.fillMaxWidth().then(
                            if (validRatio) Modifier.fillMaxSize()
                            else Modifier.aspectRatio(0.8f) // Usually videos are portrait fallback
                        )
                    )
                } else {
                    val painter = rememberAsyncImagePainter(
                        model = ImageRequest.Builder(context).data(post.imageUrl)
                            .crossfade(false)
                            .memoryCacheKey(post.imageUrl).diskCacheKey(post.imageUrl)
                            .diskCachePolicy(CachePolicy.ENABLED).memoryCachePolicy(CachePolicy.ENABLED)
                            .allowHardware(true).size(Size.ORIGINAL).build(),
                        imageLoader = imageLoader
                    )

                    val state = painter.state
                    LaunchedEffect(state) {
                        if (state is AsyncImagePainter.State.Success) {
                            onImageLoaded(index)
                        }
                    }

                    if (state is AsyncImagePainter.State.Loading || state is AsyncImagePainter.State.Empty) {
                        val color1 = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                        val color2 = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)

                        // 🌟 SHIMMER WILL NOW ADAPT PERFECTLY 🌟
                        Box(modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (validRatio) Modifier.fillMaxSize() // Fill exact known ratio
                                else Modifier.aspectRatio(1f) // Fallback: Clean 1:1 Square if no ratio known
                            )
                            .drawBehind {
                                val x = shimmerOffsetProvider()
                                val brush = Brush.linearGradient(
                                    colors = listOf(color1, color2, color1),
                                    start = Offset(x - 300f, 0f), end = Offset(x + 300f, 0f)
                                )
                                drawRect(brush)
                            }
                        )
                    }
                    if (state is AsyncImagePainter.State.Error) {
                        LaunchedEffect(Unit) { onImageLoaded(index) }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (validRatio) Modifier.fillMaxSize()
                                    else Modifier.aspectRatio(1f)
                                )
                                .background(MaterialTheme.colorScheme.errorContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.BrokenImage, null, tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(40.dp))
                        }
                    }

                    Image(
                        painter = painter,
                        contentDescription = post.title,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (validRatio) Modifier.fillMaxSize()
                                else Modifier.wrapContentHeight() // Wrap to whatever image says when it finally loads
                            )
                    )

                    Box(modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter)) {
                        IsolatedBrandingOverlay(cachedGooglePhoto = cachedGooglePhoto)
                    }
                }
            }
        }

        if (post.title.isNotBlank()) {
            Text(text = post.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {

            Surface(
                onClick = {
                    handleAction {
                        if (!isDownloading) {
                            coroutineScope.launch {
                                isDownloading = true
                                try {
                                    val hqUrl = post.imageUrl.replace("_800x800", "")
                                    val saved = if (post.type == "video" && post.videoUrl.isNotBlank()) {
                                        GallerySaver.saveVideo(context, post.videoUrl)
                                    } else {
                                        GallerySaver.saveImage(context, hqUrl)
                                    }

                                    if (saved) {
                                        com.statusseva.app.data.FirestoreRepository.incrementDownloadCount(post.id, GoogleAuthHelper.currentUser?.uid)

                                        AppDownloadManager.addPost(DownloadedPost(
                                            id = post.id,
                                            title = post.title,
                                            description = post.description,
                                            category = post.category,
                                            imageUrl = if (post.type == "video" && post.videoUrl.isNotBlank()) post.videoUrl else hqUrl,
                                            downloadedAt = System.currentTimeMillis()
                                        ))
                                        Toast.makeText(context, str("saved_ok"), Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Gallery Save Failed. Try again.", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                } finally { isDownloading = false }
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                tonalElevation = 0.dp
            ) {
                Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    if (isDownloading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    } else {
                        Icon(Icons.Default.Download, contentDescription = str("btn_download"), tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(str("btn_download"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Surface(
                onClick = {
                    handleAction {
                        if (!isWaSharing) {
                            coroutineScope.launch {
                                isWaSharing = true
                                try {
                                    val hqUrl = post.imageUrl.replace("_800x800", "")
                                    if (post.type == "video" && post.videoUrl.isNotBlank()) {
                                        Toast.makeText(context, str("loading"), Toast.LENGTH_SHORT).show()
                                        val videoFile = GallerySaver.downloadVideoToCache(context, post.videoUrl)
                                            ?: run { Toast.makeText(context, str("wa_load_fail"), Toast.LENGTH_SHORT).show(); return@launch }
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", videoFile)
                                        context.startActivity(Intent(Intent.ACTION_SEND).apply {
                                            com.statusseva.app.data.FirestoreRepository.incrementShareCount(post.id)
                                            type = "video/mp4"; `package` = "com.whatsapp"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            putExtra(Intent.EXTRA_TEXT, WatermarkHelper.getRandomCaption())
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        })
                                    } else {
                                        if (post.imageUrl.isBlank()) return@launch
                                        val watermarked = GallerySaver.getWatermarkedBitmap(context, hqUrl) ?: return@launch
                                        val file = withContext(Dispatchers.IO) {
                                            val f = File(context.cacheDir, "wa_share.png")
                                            FileOutputStream(f).use { fos -> watermarked.compress(Bitmap.CompressFormat.PNG, 100, fos) }
                                            watermarked.recycle(); f
                                        }
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                        context.startActivity(Intent(Intent.ACTION_SEND).apply {
                                            com.statusseva.app.data.FirestoreRepository.incrementShareCount(post.id)
                                            type = "image/*"; `package` = "com.whatsapp"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            putExtra(Intent.EXTRA_TEXT, WatermarkHelper.getRandomCaption())
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        })
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Share Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                } finally { isWaSharing = false }
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(12.dp),
                color = Color(0xFF25D366),
                tonalElevation = 0.dp
            ) {
                Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    if (isWaSharing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Image(
                            painter = painterResource(R.drawable.ic_whatsapp),
                            contentDescription = str("btn_share"),
                            modifier = Modifier.size(20.dp),
                            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Color.White)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(str("btn_share"), style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (post.type != "video") {
                IsolatedBrandingEditButton(onClick = onEditBrandingClick)
            }
        }
        
        if (showPremiumUnlockSheet) {
            PremiumUnlockSheet(
                onDismiss = { showPremiumUnlockSheet = false },
                onWatchAdClick = {
                    showPremiumUnlockSheet = false
                    Toast.makeText(context, "Loading Ad...", Toast.LENGTH_SHORT).show()
                    com.statusseva.app.data.RewardedAdManager.showAd(
                        activity = context as android.app.Activity,
                        onRewardEarned = {
                            val savedAction = pendingDownloadAction
                            pendingDownloadAction = null
                            if (savedAction != null) {
                                checkStorageAndExecute(savedAction)
                            }
                        },
                        onAdClosedEarly = {
                            Toast.makeText(context, "Ad closed early", Toast.LENGTH_SHORT).show()
                            pendingDownloadAction = null
                        },
                        onAdFailedToLoad = {
                            Toast.makeText(context, "Failed to load Ad. Try again.", Toast.LENGTH_SHORT).show()
                            pendingDownloadAction = null
                        }
                    )
                },
                onGoPremiumClick = {
                    showPremiumUnlockSheet = false
                    onNavigate("subscription")
                }
            )
        }
    }
}

@Composable
fun IsolatedBrandingOverlay(cachedGooglePhoto: Uri?) {
    val branding = UserBrandingManager
    if (!branding.isBrandingEnabled) return

    val context = LocalContext.current
    val isDarkMode = isSystemInDarkTheme()
    val isLeft = branding.isLeftDesign

    val rawBgColor = branding.brandingColor
    val bgColor = if (rawBgColor == android.graphics.Color.WHITE || rawBgColor == 0) {
        if (isDarkMode) Color.White else Color(0xFF800080)
    } else {
        Color(rawBgColor)
    }

    val bgBrush = when (rawBgColor) {
        -2 -> Brush.horizontalGradient(listOf(Color(0xFFFF9933), Color.White, Color(0xFF138808)))
        -3 -> Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta))
        else -> Brush.linearGradient(listOf(bgColor, bgColor))
    }

    val isLightBg = remember(rawBgColor) {
        if (rawBgColor == -2) true
        else if (rawBgColor == -3) false
        else isBrandingColorLight(rawBgColor)
    }

    val textCol = if (isLightBg) Color(0xFF1a1a1a) else Color.White
    val brandingName = branding.brandingName.ifBlank { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName ?: "StatusSeva User" }
    val photoSrc: Any? = branding.brandingPhotoUri ?: cachedGooglePhoto

    val stripH      = 44.dp
    val photoSize   = 88.dp
    val photoOffset = -(stripH - photoSize * 0.30f)

    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stripH)
                .align(Alignment.BottomCenter)
                .background(bgBrush, alpha = 0.92f)
                .border(0.5.dp, Color.Black, RectangleShape)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = if (isLeft) photoSize + 12.dp else 12.dp,
                    end   = if (isLeft) 12.dp else photoSize + 12.dp
                )
                .height(stripH)
                .align(Alignment.BottomCenter),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = brandingName,
                color = textCol,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }

        val photoAlign = if (isLeft) Alignment.BottomStart else Alignment.BottomEnd
        val photoPadding = if (isLeft) Modifier.padding(start = 10.dp) else Modifier.padding(end = 10.dp)

        Box(
            modifier = Modifier
                .align(photoAlign)
                .then(photoPadding)
                .offset(y = photoOffset)
                .size(photoSize)
                .clip(CircleShape)
                .then(
                    if (branding.isOutlineEnabled) {
                        Modifier.border(
                            width = 3.dp,
                            brush = Brush.sweepGradient(
                                listOf(Color.Red, Color.White, Color.Magenta, Color.Blue, Color.Cyan, Color.Green, Color.Yellow, Color.Red)
                            ),
                            shape = CircleShape
                        )
                    } else {
                        val bCol = if (rawBgColor == android.graphics.Color.WHITE) Color.LightGray else Color.White
                        Modifier.border(1.5.dp, bCol, CircleShape)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (photoSrc != null) {
                Image(
                    painter = rememberAsyncImagePainter(
                        model = ImageRequest.Builder(context).data(photoSrc).crossfade(false).build()
                    ),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(modifier = Modifier.fillMaxSize().background(Color(0xFF6C63FF)), contentAlignment = Alignment.Center) {
                    Text(text = brandingName.trim().take(1).uppercase().ifBlank { "U" }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun IsolatedBrandingEditButton(onClick: () -> Unit) {
    val brandingEnabled = UserBrandingManager.isBrandingEnabled
    Surface(
        onClick        = onClick,
        modifier       = Modifier.size(46.dp),
        shape          = RoundedCornerShape(12.dp),
        color          = if (brandingEnabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 0.dp
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(imageVector = Icons.Default.Edit, contentDescription = "Branding", modifier = Modifier.size(18.dp), tint = if (brandingEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
        }
    }
}

fun getRelativeTime(timestamp: Long, appLang: String = "hi"): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60_000L      -> AppStrings.get("just_now", appLang)
        diff < 3_600_000L   -> "${diff / 60_000}m ago"
        diff < 86_400_000L  -> "${diff / 3_600_000}h ago"
        diff < 604_800_000L -> "${diff / 86_400_000}d ago"
        else                -> "${diff / 604_800_000L}w ago"
    }
}