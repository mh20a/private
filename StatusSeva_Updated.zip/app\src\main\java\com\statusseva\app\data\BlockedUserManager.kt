package com.statusseva.app.data

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

data class BlockedUser(
    val uid: String,
    val name: String
)

object BlockedUserManager {
    private val db = FirebaseFirestore.getInstance()
    private var listenerRegistration: ListenerRegistration? = null

    // Reactive list of blocked UIDs to filter posts easily
    val blockedUids = mutableStateListOf<String>()

    fun init() {
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return
        
        listenerRegistration?.remove()
        listenerRegistration = db.collection("users")
            .document(currentUser.uid)
            .collection("blockedUsers")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BlockedUserManager", "Error listening to blocked users", error)
                    return@addSnapshotListener
                }
                
                if (snapshot != null) {
                    val uids = snapshot.documents.map { it.id }
                    blockedUids.clear()
                    blockedUids.addAll(uids)
                }
            }
    }

    fun blockUser(uid: String, name: String) {
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return
        if (uid.isBlank() || uid == currentUser.uid) return

        val data = hashMapOf(
            "uid" to uid,
            "name" to name,
            "blockedAt" to FieldValue.serverTimestamp()
        )

        // Optimistically add to local state
        if (!blockedUids.contains(uid)) blockedUids.add(uid)

        db.collection("users").document(currentUser.uid)
            .collection("blockedUsers").document(uid)
            .set(data)
            .addOnFailureListener {
                Log.e("BlockedUserManager", "Failed to block user $uid", it)
            }
    }

    fun unblockUser(uid: String) {
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return
        
        // Optimistically remove from local state
        blockedUids.remove(uid)

        db.collection("users").document(currentUser.uid)
            .collection("blockedUsers").document(uid)
            .delete()
            .addOnFailureListener {
                Log.e("BlockedUserManager", "Failed to unblock user $uid", it)
            }
    }

    fun getBlockedUsers(onResult: (List<BlockedUser>) -> Unit) {
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            onResult(emptyList())
            return
        }

        db.collection("users").document(currentUser.uid)
            .collection("blockedUsers")
            .get()
            .addOnSuccessListener { result ->
                val users = result.mapNotNull { doc ->
                    val name = doc.getString("name") ?: "Unknown User"
                    BlockedUser(doc.id, name)
                }
                onResult(users)
            }
            .addOnFailureListener {
                Log.e("BlockedUserManager", "Failed to fetch blocked users", it)
                onResult(emptyList())
            }
    }
}
