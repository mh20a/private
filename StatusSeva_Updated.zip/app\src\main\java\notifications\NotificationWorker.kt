package com.statusseva.app.notifications

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class NotificationWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {

        NotificationHelper.createNotificationChannel(applicationContext)
        NotificationHelper.showNotification(applicationContext)

        return Result.success()
    }
}