package com.statusseva.app.ui.subscription

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.data.BillingManager
import com.statusseva.app.data.SubscriptionManager
import com.statusseva.app.data.SubscriptionStatus
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import com.statusseva.app.data.PaymentEvent // ADDED: Import for the new event system
import kotlin.collections.find

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    appLang  : String = "hi",
    userPlan : String = "free",
    onBack   : () -> Unit = {}
) {
    val context        = LocalContext.current
    val activity       = context as Activity
    val coroutineScope = rememberCoroutineScope()
    val googleUser     = GoogleAuthHelper.currentUser
    val firestore      = remember { FirebaseFirestore.getInstance() }

    var subStatus    by remember { mutableStateOf<SubscriptionStatus?>(null) }
    var isLoading    by remember { mutableStateOf(true) }
    var isPaying     by remember { mutableStateOf(false) }
    var payStep      by remember { mutableStateOf("") }
    var errorMsg     by remember { mutableStateOf("") }
    var showSuccess  by remember { mutableStateOf(false) }
    var userPhone    by remember { mutableStateOf("") }

    // 🌟 ADDED: Listen for external payment events from MainActivity
    val paymentEvent by BillingManager.paymentEventFlow.collectAsState()

    fun str(hi: String, mr: String, en: String) = when (appLang) {
        "hi" -> hi; "mr" -> mr; else -> en
    }

    suspend fun refreshStatus() {
        val uid = googleUser?.uid ?: return
        try {
            subStatus = SubscriptionManager.getSubscriptionStatus(uid)
        } catch (_: Exception) {}
    }

    LaunchedEffect(Unit) {
        BillingManager.initialize(context)
        refreshStatus()
        isLoading = false
    }

    // 🌟 ADDED: Handle external payment cancellations/errors to stop the loader
    LaunchedEffect(paymentEvent) {
        when (val event = paymentEvent) {
            is PaymentEvent.Error -> {
                isPaying = false
                payStep = ""
                errorMsg = event.message
                BillingManager.paymentEventFlow.value = PaymentEvent.Idle // Reset event
            }
            is PaymentEvent.Verifying -> {
                payStep = str("Verification चल रही है...", "Verification चालू आहे...", "Verifying payment...")
            }
            is PaymentEvent.Idle -> {}
            is PaymentEvent.Loading -> {
                payStep = str("Payment खुल रहा है...", "Payment उघडत आहे...", "Opening payment...")
            }
            is PaymentEvent.Success -> {
                isPaying = false
                payStep = ""
                showSuccess = true
                BillingManager.paymentEventFlow.value = PaymentEvent.Idle
            }
        }
    }

    DisposableEffect(googleUser?.uid) {
        val uid = googleUser?.uid ?: return@DisposableEffect onDispose {}
        val listener = firestore.collection("users").document(uid)
            .addSnapshotListener { snap, _ ->
                val plan    = snap?.getString("plan") ?: "free"
                val expires = snap?.getTimestamp("planExpires")?.toDate()?.time ?: 0L
                val now     = System.currentTimeMillis()

                userPhone   = snap?.getString("phone") ?: ""

                subStatus = SubscriptionStatus(
                    plan          = plan,
                    isActive      = plan == "pro" && expires > now,
                    expiresAt     = expires,
                    daysRemaining = if (expires > now) ((expires - now) / (24*60*60*1000)).toInt() else 0
                )

                // When backend confirms success, stop paying loader and show success screen
                if (plan == "pro" && expires > now && isPaying) {
                    isPaying    = false
                    payStep     = ""
                    showSuccess = true
                    // 🌟 ADDED: Reset the event flow
                    BillingManager.paymentEventFlow.value = PaymentEvent.Idle
                }
            }
        onDispose { listener.remove() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        str("सदस्यता", "सदस्यत्व", "Subscription"),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (!isPaying) onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize()) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isLoading) {
                    Box(
                        modifier         = Modifier.fillMaxWidth().height(200.dp),
                        contentAlignment = Alignment.Center
                    ) { CircularProgressIndicator() }
                    return@Column
                }

                val status = subStatus

                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Row(
                        modifier          = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.AccountCircle, null,
                            modifier = Modifier.size(48.dp),
                            tint     = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                googleUser?.displayName ?: "User",
                                style      = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                googleUser?.email ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(14.dp),
                    colors   = CardDefaults.cardColors(
                        containerColor = if (status?.isActive == true)
                            Color(0xFF16a34a).copy(alpha = 0.1f)
                        else
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier              = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                str("वर्तमान प्लान", "सध्याचा प्लान", "Current Plan"),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (status?.isActive == true) Color(0xFF16a34a)
                                else MaterialTheme.colorScheme.outline
                            ) {
                                Text(
                                    text     = if (status?.isActive == true)
                                        str("✅ सक्रिय", "✅ सक्रिय", "✅ Active")
                                    else
                                        str("❌ निष्क्रिय", "❌ निष्क्रिय", "❌ Inactive"),
                                    color    = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text       = if (status?.isActive == true) "👑 StatusSeva Pro"
                            else str("🆓 Free Plan", "🆓 Free Plan", "🆓 Free Plan"),
                            style      = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color      = if (status?.isActive == true) Color(0xFF16a34a)
                            else MaterialTheme.colorScheme.onSurface
                        )
                        if (status?.isActive == true && status.expiresAt > 0L) {
                            Spacer(Modifier.height(6.dp))
                            val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                .format(Date(status.expiresAt))
                            Text(
                                text  = str(
                                    "वैधता: $dateStr (${status.daysRemaining} दिन बचे)",
                                    "वैधता: $dateStr (${status.daysRemaining} दिवस शिल्लक)",
                                    "Valid till: $dateStr (${status.daysRemaining} days left)"
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            str("Pro के फायदे", "Pro चे फायदे", "Pro Benefits"),
                            style      = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            str("✅ Unlimited Downloads", "✅ अमर्यादित Downloads", "✅ Unlimited Downloads"),
                            str("✅ Unlimited WhatsApp Share", "✅ अमर्यादित WhatsApp Share", "✅ Unlimited WhatsApp Share"),
                            str("✅ रोज़ नया Content", "✅ रोज नवीन Content", "✅ New content daily"),
                            str("✅ Hindi + Marathi Status", "✅ Hindi + Marathi Status", "✅ Hindi + Marathi Status"),
                            str("✅ कोई Ads नहीं", "✅ कोणत्याही जाहिराती नाही", "✅ No Ads")
                        ).forEach { feature ->
                            Text(
                                text     = feature,
                                style    = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(vertical = 3.dp)
                            )
                        }
                    }
                }

                AnimatedContent(
                    targetState = status?.isActive == true,
                    transitionSpec = { fadeIn(tween(300)).togetherWith(fadeOut(tween(300))) },
                    label = "sub_card"
                ) { isActive ->
                    if (!isActive) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape    = RoundedCornerShape(14.dp),
                            colors   = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        ) {
                            Column(
                                modifier            = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text       = str(
                                        "₹199/माह — Unlimited Status",
                                        "₹199/महिना — Unlimited Status",
                                        "₹199/month — Unlimited Status"
                                    ),
                                    style      = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    textAlign  = TextAlign.Center,
                                    color      = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text  = str(
                                        "3 दिन का फ्री डेमो लें। उसके बाद ₹199/माह। Play Store से कभी भी Cancel करें।",
                                        "3 दिवसांचा फ्री डेमो घ्या. त्यानंतर ₹199/महिना. Play Store मधून कधीही Cancel करा.",
                                        "Start 3-Day Free Trial. Then ₹199/mo. Cancel anytime via Play Store."
                                    ),
                                    style     = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center,
                                    color     = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
                                )

                                AnimatedVisibility(visible = errorMsg.isNotBlank()) {
                                    Spacer(Modifier.height(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.errorContainer
                                    ) {
                                        Text(
                                            text     = errorMsg,
                                            style    = MaterialTheme.typography.bodySmall,
                                            color    = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.padding(10.dp),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }

                                Spacer(Modifier.height(20.dp))

                                // 🌟 20% BIGGER PAY BUTTON 🌟
                                Button(
                                    onClick = {
                                        errorMsg = ""
                                        isPaying = true
                                        payStep  = str(
                                            "तैयारी हो रही है...",
                                            "तयारी होत आहे...",
                                            "Preparing..."
                                        )
                                        coroutineScope.launch {
                                            try {
                                                val products = BillingManager.subscriptionProducts.value
                                                val monthlyProduct = products.find { it.productId == BillingManager.PRO_MONTHLY }
                                                
                                                if (monthlyProduct != null) {
                                                    payStep = str(
                                                        "Payment खुल रहा है...",
                                                        "Payment उघडत आहे...",
                                                        "Opening payment..."
                                                    )
                                                    BillingManager.launchPurchaseFlow(activity, monthlyProduct)
                                                } else {
                                                    isPaying = false
                                                    payStep  = ""
                                                    errorMsg = "Subscription plan not available right now."
                                                }
                                            } catch (e: Exception) {
                                                isPaying = false
                                                payStep  = ""
                                                errorMsg = str(
                                                    "कुछ गलत हुआ। दोबारा कोशिश करें।",
                                                    "काहीतरी चुकले. पुन्हा प्रयत्न करा.",
                                                    "Something went wrong. Please try again."
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(64.dp), // 🔥 Height increased to 64dp
                                    shape    = RoundedCornerShape(16.dp),
                                    enabled  = !isPaying
                                ) {
                                    if (isPaying) {
                                        CircularProgressIndicator(
                                            modifier    = Modifier.size(24.dp),
                                            strokeWidth = 3.dp,
                                            color       = MaterialTheme.colorScheme.onPrimary
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Text(
                                            payStep,
                                            fontSize   = 16.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    } else {
                                        Text(
                                            str("Start 3-Day Free Demo", "Start 3-Day Free Demo", "Start 3-Day Free Demo"),
                                            fontSize   = 18.sp, // 🔥 Font size increased to match bigger button
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(Modifier.height(16.dp))

                                // 🌟 50% LARGER & SHORTER LEGAL TEXT 🌟
                                Text(
                                    text = str(
                                        "Note: पहले 3 दिन बिलकुल फ्री हैं। उसके बाद Google Play द्वारा ₹199/माह कटेंगे। चार्ज से बचने के लिए 3 दिन पूरे होने से पहले Play Store Subscriptions से कैंसिल करें।",
                                        "Note: पहिले 3 दिवस पूर्णपणे फ्री आहेत. त्यानंतर Google Play द्वारे ₹199/महिना कापले जातील. पहिले पेमेंट टाळण्यासाठी 3 दिवस पूर्ण होण्यापूर्वी Play Store Subscriptions मधून रद्द करा.",
                                        "Note: First 3 days are completely free. ₹199/month will be auto-deducted via Google Play after 3 days. Cancel in Play Store Subscriptions before the trial ends to avoid being charged."
                                    ),
                                    style      = MaterialTheme.typography.labelMedium,
                                    fontSize   = 12.sp,
                                    lineHeight = 20.sp,
                                    color      = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                                    textAlign  = TextAlign.Justify,
                                    modifier   = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                                )
                            }
                        }
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape    = RoundedCornerShape(14.dp),
                            colors   = CardDefaults.cardColors(
                                containerColor = Color(0xFF16a34a).copy(alpha = 0.1f)
                            )
                        ) {
                            Column(
                                modifier            = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🎉", fontSize = 36.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    str("आप Pro Member हैं!", "तुम्ही Pro Member आहात!", "You are a Pro Member!"),
                                    style      = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color      = Color(0xFF16a34a)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    str(
                                        "सभी features unlocked हैं। आनंद लें! 🚀",
                                        "सर्व features unlock आहेत. आनंद घ्या! 🚀",
                                        "All features unlocked. Enjoy! 🚀"
                                    ),
                                    style     = MaterialTheme.typography.bodySmall,
                                    color     = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(40.dp))
            }

            AnimatedVisibility(
                visible = showSuccess,
                enter   = fadeIn(tween(400)) + scaleIn(initialScale = 0.8f, animationSpec = tween(400)),
                exit    = fadeOut(tween(300))
            ) {
                Box(
                    modifier         = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.padding(32.dp),
                        shape    = RoundedCornerShape(24.dp),
                        color    = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        Column(
                            modifier            = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🎉", fontSize = 64.sp)
                            Spacer(Modifier.height(16.dp))
                            Text(
                                str("Welcome to Pro!", "Pro मध्ये स्वागत!", "Welcome to Pro!"),
                                style      = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color      = Color(0xFF16a34a)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                str(
                                    "आपकी subscription activate हो गई!\nDownload और Share unlimited करें।",
                                    "तुमची subscription activate झाली!\nDownload आणि Share unlimited करा.",
                                    "Your subscription is now active!\nEnjoy unlimited downloads & sharing."
                                ),
                                style     = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color     = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(24.dp))
                            Button(
                                onClick  = {
                                    showSuccess = false
                                    onBack()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape    = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    str("शुरू करें 🚀", "सुरू करा 🚀", "Let's Go 🚀"),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}