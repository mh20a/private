package com.statusseva.app.ui.explore

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.R
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.FirestoreRepository
import com.statusseva.app.model.Post
import kotlinx.coroutines.delay

// ── ExploreCategory — bgImageUrl + textColor added ───────────────────────────
private data class ExploreCategory(
    val id         : String,
    val name       : String,
    val icon       : String,
    val color      : String,
    val position   : Int    = Int.MAX_VALUE,
    val bgImageUrl : String = "",   // Admin se set ki gayi background image
    val textColor  : String = ""    // Admin se set ki gayi text color
)

private object ExploreStateCache {
    var categories: List<ExploreCategory>? = null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    onNavigate : (String) -> Unit,
    appLang    : String = "hi"
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    val context     = LocalContext.current
    val firestore   = remember { FirebaseFirestore.getInstance() }
    val contentLang = LanguagePreference.getContentLanguage(context)

    var firestoreCategories by remember { mutableStateOf<List<ExploreCategory>>(ExploreStateCache.categories ?: emptyList()) }
    var isLoading           by remember { mutableStateOf(ExploreStateCache.categories == null) }
    var searchMode          by remember { mutableStateOf(false) }
    var searchQuery         by remember { mutableStateOf("") }
    
    var bannerPosts         by remember { mutableStateOf<List<Post>>(emptyList()) }

    LaunchedEffect(appLang) {
        FirestoreRepository.fetchPosts(appLang) { posts ->
            bannerPosts = posts.groupBy { it.category }
                .mapNotNull { it.value.firstOrNull() }
                .take(10)
        }
    }

    BackHandler(enabled = searchMode) {
        searchMode  = false
        searchQuery = ""
    }

    DisposableEffect(Unit) {
        val listener = firestore.collection("categories")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    firestoreCategories = snap.documents
                        .mapNotNull { doc ->
                            val showOnExplore = doc.getBoolean("showOnExplore") ?: true
                            if (!showOnExplore) return@mapNotNull null
                            val name = doc.getString("name") ?: return@mapNotNull null
                            val catLang = doc.getString("language") ?: ""
                            if (catLang.isNotBlank() && catLang != contentLang) return@mapNotNull null
                            ExploreCategory(
                                id         = doc.id,
                                name       = name,
                                icon       = doc.getString("icon")      ?: "",
                                color      = doc.getString("color")     ?: "",
                                position   = doc.getLong("position")?.toInt() ?: Int.MAX_VALUE,
                                bgImageUrl = doc.getString("bgImageUrl") ?: "",
                                textColor  = doc.getString("textColor")  ?: ""
                            )
                        }
                        .sortedWith(
                            compareBy<ExploreCategory> { it.position }.thenBy { it.name.lowercase() }
                        )
                    ExploreStateCache.categories = firestoreCategories
                }
                isLoading = false
            }
        onDispose { listener.remove() }
    }

    val filteredCategories = remember(firestoreCategories, searchQuery) {
        if (searchQuery.isBlank()) firestoreCategories
        else firestoreCategories.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    val gradientPairs = listOf(
        listOf(Color(0xFFE040FB), Color(0xFFAB47BC)),
        listOf(Color(0xFFFF6D00), Color(0xFFFF9E40)),
        listOf(Color(0xFF1E88E5), Color(0xFF42A5F5)),
        listOf(Color(0xFF43A047), Color(0xFF66BB6A)),
        listOf(Color(0xFFE53935), Color(0xFFEF5350)),
        listOf(Color(0xFF00ACC1), Color(0xFF26C6DA)),
        listOf(Color(0xFFF4511E), Color(0xFFFF7043)),
        listOf(Color(0xFF8E24AA), Color(0xFFBA68C8)),
        listOf(Color(0xFF3949AB), Color(0xFF5C6BC0)),
        listOf(Color(0xFF00897B), Color(0xFF26A69A)),
    )

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        AnimatedContent(
                            targetState    = searchMode,
                            transitionSpec = { fadeIn(tween(200)).togetherWith(fadeOut(tween(200))) },
                            label          = "explore_topbar"
                        ) { searching ->
                            if (searching) {
                                OutlinedTextField(
                                    value         = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder   = { Text(str("explore_hint")) },
                                    singleLine    = true,
                                    modifier      = Modifier.fillMaxWidth().padding(end = 8.dp),
                                    shape         = RoundedCornerShape(50)
                                )
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter            = painterResource(R.drawable.logo),
                                        contentDescription = null,
                                        modifier           = Modifier.height(30.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text       = str("explore_title"),
                                        fontWeight = FontWeight.Bold,
                                        style      = MaterialTheme.typography.titleLarge
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            searchMode = !searchMode
                            if (!searchMode) searchQuery = ""
                        }) {
                            Icon(
                                imageVector        = if (searchMode) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = null
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {

            if (isLoading) {
                LazyVerticalGrid(
                    columns               = GridCells.Fixed(2),
                    modifier              = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(6) { ExploreShimmerCard() }
                }
            }

            if (!isLoading && filteredCategories.isEmpty()) {
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text  = if (searchQuery.isBlank()) str("no_categories")
                        else "\"$searchQuery\" — ${str("no_categories")}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (!isLoading && filteredCategories.isNotEmpty()) {
                LazyVerticalGrid(
                    columns               = GridCells.Fixed(2),
                    modifier              = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding        = PaddingValues(bottom = 80.dp)
                ) {
                    if (bannerPosts.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            val pagerState = rememberPagerState(pageCount = { bannerPosts.size })
                            
                            LaunchedEffect(pagerState) {
                                while (true) {
                                    delay(1500)
                                    val nextPage = (pagerState.currentPage + 1) % bannerPosts.size
                                    pagerState.animateScrollToPage(nextPage)
                                }
                            }
                            
                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .padding(bottom = 12.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            ) { page ->
                                val post = bannerPosts[page]
                                val imgUrl = post.originalImageUrl.takeIf { it.isNotBlank() } ?: post.imageUrl
                                
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(imgUrl)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = "Banner",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clickable {
                                            onNavigate("home?category=${post.category}")
                                        }
                                )
                            }
                        }
                    }

                    items(items = filteredCategories, key = { it.id }) { category ->

                        // ── Color gradient (sirf tab use hoga jab bgImage nahi ho) ────
                        val bgColors = if (category.color.isNotBlank()) {
                            try {
                                val parsed = android.graphics.Color.parseColor(category.color)
                                val base   = Color(parsed)
                                listOf(base, base.copy(red = base.red * 0.75f, green = base.green * 0.75f, blue = base.blue * 0.75f))
                            } catch (_: Exception) {
                                gradientPairs[kotlin.math.abs(category.name.lowercase().hashCode()) % gradientPairs.size]
                            }
                        } else {
                            gradientPairs[kotlin.math.abs(category.name.lowercase().hashCode()) % gradientPairs.size]
                        }

                        // ── Text color from admin, default White ──────────────────────
                        val textCol = if (category.textColor.isNotBlank()) {
                            try { Color(android.graphics.Color.parseColor(category.textColor)) }
                            catch (_: Exception) { Color.White }
                        } else {
                            Color.White
                        }

                        val hasBgImage = category.bgImageUrl.isNotBlank()

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clickable { onNavigate("home?category=${category.name}") },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {

                                if (hasBgImage) {
                                    // ── Background image — admin se set ───────────────
                                    AsyncImage(
                                        model = ImageRequest.Builder(LocalContext.current)
                                            .data(category.bgImageUrl)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = null,
                                        modifier           = Modifier.fillMaxSize(),
                                        contentScale       = ContentScale.Crop
                                    )
                                    // Dark overlay for text readability
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color.Black.copy(alpha = 0.28f))
                                    )
                                } else {
                                    // ── Gradient background ───────────────────────────
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Brush.linearGradient(bgColors))
                                    )
                                }

                                // ── Icon + Name ───────────────────────────────────────
                                Column(
                                    modifier            = Modifier.align(Alignment.Center),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (category.icon.isNotBlank()) {
                                        Text(text = category.icon, style = MaterialTheme.typography.titleLarge)
                                        Spacer(Modifier.height(4.dp))
                                    }
                                    Text(
                                        text       = category.name,
                                        style      = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color      = textCol
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ExploreShimmerCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "explore_shimmer")
    val shimmerX by infiniteTransition.animateFloat(
        initialValue  = -400f, targetValue = 400f,
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "shimmer_x"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            Color(0xFF2A2A2A).copy(alpha = 0.7f),
            Color(0xFF3A3A3A).copy(alpha = 0.4f),
            Color(0xFF2A2A2A).copy(alpha = 0.7f)
        ),
        start = Offset(shimmerX - 200f, 0f),
        end   = Offset(shimmerX + 200f, 0f)
    )
    Box(modifier = Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(14.dp)).background(shimmerBrush))
}