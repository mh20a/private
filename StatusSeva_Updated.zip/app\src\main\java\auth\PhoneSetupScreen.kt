package com.statusseva.app.ui.auth

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.identity.GetPhoneNumberHintIntentRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.R
import com.statusseva.app.data.GoogleAuthHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneSetupScreen(
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var phone by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val user = GoogleAuthHelper.currentUser

    // 🌟 1. Launcher to handle the bottom sheet result for Auto-Fill
    val phoneNumberHintLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            try {
                // Get the number from Google
                val fullNumber = Identity.getSignInClient(context).getPhoneNumberFromIntent(result.data)

                // Clean the number (+91 aur spaces hata do)
                val cleanNumber = fullNumber.replace("+91", "").replace(" ", "").trim()
                if (cleanNumber.length >= 10) {
                    phone = cleanNumber.takeLast(10) // Akhiri 10 digit le lo
                } else {
                    phone = cleanNumber // fallback
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // 🌟 2. Auto-trigger the Google Hint pop-up when screen opens
    LaunchedEffect(Unit) {
        try {
            val request = GetPhoneNumberHintIntentRequest.builder().build()
            Identity.getSignInClient(context)
                .getPhoneNumberHintIntent(request)
                .addOnSuccessListener { result ->
                    try {
                        phoneNumberHintLauncher.launch(
                            IntentSenderRequest.Builder(result.intentSender).build()
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                .addOnFailureListener {
                    // Agar phone mein SIM nahi hai ya feature support nahi karta,
                    // toh user khud type kar lega, error show karne ki zaroorat nahi.
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Scaffold { padding ->
        Box(modifier = Modifier.fillMaxSize()) {
            
            // 🌟 1. Background Video Layer
            BackgroundVideoPlayer()

            // 🌟 2. Gradient Overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // 🌟 3. Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(80.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "One Last Step!",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Please enter your 10-digit mobile number for account security and billing.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = {
                    if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                        if (it.isNotEmpty() && it[0] !in listOf('6', '7', '8', '9')) {
                            Toast.makeText(context, "Invalid number", Toast.LENGTH_SHORT).show()
                        } else {
                            phone = it
                        }
                    }
                },
                label = { Text("Mobile Number") },
                prefix = { Text("+91 ") },
                leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (phone.length == 10 && user != null) {
                        isLoading = true
                        FirebaseFirestore.getInstance().collection("users").document(user.uid)
                            .update("phone", phone)
                            .addOnSuccessListener {
                                isLoading = false
                                onSuccess()
                            }
                            .addOnFailureListener {
                                isLoading = false
                                Toast.makeText(context, "Error saving number", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(context, "Please enter a valid 10-digit number", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp),
                enabled = !isLoading && phone.length == 10
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Save & Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            }
        }
    }
}