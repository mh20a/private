package com.statusseva.app.data

import android.content.Context
import android.graphics.*
import android.content.res.Configuration
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object BrandingStripHelper {

    suspend fun applyBrandingStrip(
        context : Context,
        source  : Bitmap
    ): Bitmap = withContext(Dispatchers.IO) {

        val branding = UserBrandingManager
        if (!branding.isBrandingEnabled) return@withContext source

        val imgW   = source.width
        val imgH   = source.height

        val stripH    = (imgW * (44f / 360f)).toInt()
        val photoSize = (imgW * (66f / 360f)).toInt()
        val photoRadius = photoSize / 2f

        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val stripTop  = (imgH - stripH).toFloat()

        val isDarkMode = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val defaultColor = if (isDarkMode) 0xFFFFFFFF.toInt() else 0xFFFFA500.toInt()

        val rawBgColor = branding.brandingColor
        val bgColor = if (rawBgColor == android.graphics.Color.WHITE || rawBgColor == 0) defaultColor else rawBgColor

        val isLightBg = isColorLight(bgColor)
        val isLeft = branding.isLeftDesign

        // 1. Strip background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (bgColor) {
            -2 -> {
                val colors = intArrayOf(0xFFFF9933.toInt(), 0xFFFFFFFF.toInt(), 0xFF138808.toInt())
                bgPaint.shader = LinearGradient(0f, stripTop, imgW.toFloat(), stripTop, colors, null, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, stripTop, imgW.toFloat(), imgH.toFloat(), bgPaint)
                bgPaint.shader = null
            }
            -3 -> {
                val colors = intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED)
                bgPaint.shader = LinearGradient(0f, stripTop, imgW.toFloat(), stripTop, colors, null, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, stripTop, imgW.toFloat(), imgH.toFloat(), bgPaint)
                bgPaint.shader = null
            }
            else -> {
                bgPaint.color = bgColor
                canvas.drawRect(0f, stripTop, imgW.toFloat(), imgH.toFloat(), bgPaint)
            }
        }

        // 2. Black Outline
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = (imgW * (1.2f / 360f))
        }
        canvas.drawRect(0f, stripTop, imgW.toFloat(), imgH.toFloat(), outlinePaint)

        // 3. Positioning Logic
        val photoMargin = imgW * (12f / 360f)
        val photoCenterX = if (isLeft) photoMargin + photoRadius else imgW - photoMargin - photoRadius

        val photoOffset = -(stripH - photoSize * 0.35f)
        val photoBottom = imgH + photoOffset
        val photoCenterY = photoBottom - photoRadius

        // 4. Logo Outline Logic
        if (branding.isOutlineEnabled) {
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = (imgW * (3.5f / 360f))
                shader = SweepGradient(photoCenterX, photoCenterY,
                    intArrayOf(Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN, Color.GREEN, Color.YELLOW, Color.RED), null)
            }
            canvas.drawCircle(photoCenterX, photoCenterY, photoRadius + (glowPaint.strokeWidth/2f), glowPaint)
        } else {
            val normalBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (bgColor == android.graphics.Color.WHITE || bgColor == 0) Color.LTGRAY else Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = (imgW * (2.5f / 360f))
            }
            canvas.drawCircle(photoCenterX, photoCenterY, photoRadius, normalBorderPaint)
        }

        // 5. Text Area Drawing
        val textColor = if (bgColor == -2) Color.BLACK else if (isLightBg) 0xFF1a1a1a.toInt() else 0xFFFFFFFF.toInt()
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            color          = textColor
            textSize       = (imgW * (15f / 360f))
            typeface       = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign      = Paint.Align.CENTER
            isSubpixelText = true
            hinting        = Paint.HINTING_ON
        }

        val googleUser = FirebaseAuth.getInstance().currentUser
        val nameText = branding.brandingName.ifBlank { googleUser?.displayName ?: "StatusSeva User" }
        val stripCenterY = stripTop + (stripH / 2f)
        val nameY = stripCenterY - (namePaint.descent() + namePaint.ascent()) / 2f

        val textPadding = imgW * (15f / 360f)
        val spaceStart = if (isLeft) photoCenterX + photoRadius + textPadding else textPadding
        val spaceEnd   = if (isLeft) imgW - textPadding else photoCenterX - photoRadius - textPadding
        val textMidX   = spaceStart + (spaceEnd - spaceStart) / 2f

        canvas.drawText(nameText, textMidX, nameY, namePaint)

        // 6. Photo Load and Draw
        val photoUri   = branding.brandingPhotoUri
        val photoSource: Any? = when {
            photoUri != null             -> photoUri
            googleUser?.photoUrl != null -> {
                val url = googleUser.photoUrl.toString()
                url.replace(Regex("s\\d+-c"), "s800-c")
            }
            else                         -> null
        }

        val photoBitmap = if (photoSource != null) {
            loadAndFitCircularPhoto(context, photoSource, photoSize)
        } else null

        if (photoBitmap != null) {
            val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { isFilterBitmap = true }
            canvas.drawBitmap(photoBitmap, photoCenterX - photoRadius, photoCenterY - photoRadius, photoPaint)
            photoBitmap.recycle()
        } else {
            val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6C63FF.toInt() }
            canvas.drawCircle(photoCenterX, photoCenterY, photoRadius, circlePaint)
            val initial = nameText.trim().take(1).uppercase()
            val initPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (imgW * (24f / 360f))
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val initY = photoCenterY - (initPaint.descent() + initPaint.ascent()) / 2f
            canvas.drawText(initial, photoCenterX, initY, initPaint)
        }

        result
    }

    private fun isColorLight(color: Int): Boolean {
        if (color == -2 || color == -3) return false
        val r = (color shr 16 and 0xFF) / 255.0
        val g = (color shr 8  and 0xFF) / 255.0
        val b = (color        and 0xFF) / 255.0
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) > 0.5
    }

    private suspend fun loadAndFitCircularPhoto(context: Context, source: Any, size: Int): Bitmap? {
        return try {
            val loader = ImageLoader(context)
            val loadSize = size * 4
            val request = ImageRequest.Builder(context)
                .data(source)
                .allowHardware(false)
                .size(loadSize, loadSize)
                .build()
            val result = loader.execute(request)
            if (result is SuccessResult) {
                val bmp = (result.drawable as android.graphics.drawable.BitmapDrawable).bitmap
                val cropped = centerSquareCrop(bmp)
                val scaled = Bitmap.createScaledBitmap(cropped, size, size, true)
                if (cropped !== bmp) cropped.recycle()
                makeCircularExact(scaled)
            } else null
        } catch (_: Exception) { null }
    }

    private fun centerSquareCrop(src: Bitmap): Bitmap {
        val size = minOf(src.width, src.height)
        return Bitmap.createBitmap(src, (src.width - size) / 2, (src.height - size) / 2, size, size)
    }

    private fun makeCircularExact(src: Bitmap): Bitmap {
        val size = src.width
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { isFilterBitmap = true }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, 0f, 0f, paint)
        src.recycle()
        return output
    }
}