package com.statusseva.app.data

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await

object GoogleAuthHelper {

    private const val WEB_CLIENT_ID =
        "581145036355-787551e60g2atg23pcoelpq6eau9tvb2.apps.googleusercontent.com"

    private val auth      = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    val isLoggedIn: Boolean
        get() = auth.currentUser != null

    suspend fun signInWithGoogle(context: Context): Result<FirebaseUser> {
        var lastException: Exception? = null

        // 🌟 RETRY LOGIC: CredentialManager can fail on first attempt on some devices
        for (attempt in 1..3) {
            try {
                val credentialManager = CredentialManager.create(context)

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(
                    request = request,
                    context = context
                )

                val googleIdToken = GoogleIdTokenCredential
                    .createFrom(result.credential.data)
                    .idToken

                val firebaseCredential = GoogleAuthProvider
                    .getCredential(googleIdToken, null)

                val authResult = auth.signInWithCredential(firebaseCredential).await()
                val user = authResult.user!!

                // 🌟 QUICK BLOCK CHECK BEFORE ALLOWING LOGIN 🌟
                try {
                    val doc = firestore.collection("users").document(user.uid).get().await()
                    if (doc.exists()) {
                        val status = doc.getString("status") ?: "active"
                        if (status.equals("blocked", ignoreCase = true)) {
                            auth.signOut()
                            return Result.failure(Exception("USER_BLOCKED"))
                        }
                    }
                } catch (e: Exception) {
                    // Ignore transient network errors here; allow regular flow or fallback
                }

                saveUserToFirestore(user, context)
                ProfileManager.syncWithFirebaseUid(user.uid)

                return Result.success(user)

            } catch (e: GetCredentialException) {
                lastException = e
                if (attempt < 3) {
                    kotlinx.coroutines.delay(500L) // Wait before retry
                }
            } catch (e: Exception) {
                lastException = e
                if (attempt < 3) {
                    kotlinx.coroutines.delay(500L)
                }
            }
        }

        return Result.failure(lastException ?: Exception("Sign-in failed after 3 attempts"))
    }

    fun signOut() {
        auth.signOut()
    }

    private suspend fun saveUserToFirestore(user: FirebaseUser, context: Context? = null) {
        val docRef = firestore.collection("users").document(user.uid)
        val doc    = docRef.get().await()

        // ── App version get karo ──────────────────────────────
        val appVersion = try {
            context?.packageManager
                ?.getPackageInfo(context.packageName, 0)
                ?.versionName ?: "unknown"
        } catch (_: Exception) { "unknown" }

        // ── Content language get karo ─────────────────────────
        val contentLang = try {
            context?.let { LanguagePreference.getContentLanguage(it) } ?: "hi"
        } catch (_: Exception) { "hi" }

        // ── Har login pe update hone wale fields ──────────────
        val updateData = hashMapOf<String, Any>(
            "uid"        to user.uid,
            "name"       to (user.displayName ?: ""),
            "email"      to (user.email       ?: ""),
            "photoUrl"   to (user.photoUrl?.toString() ?: ""),
            "provider"   to "google",
            "deviceModel"   to android.os.Build.MODEL,
            "deviceBrand"   to android.os.Build.BRAND,
            "androidVersion" to android.os.Build.VERSION.RELEASE,
            "status"     to "active",
            "lastLogin"  to com.google.firebase.Timestamp.now(),
            "lastActive" to com.google.firebase.Timestamp.now(),
            "appVersion" to appVersion,
            "contentLang" to contentLang
        )

        // ── Sirf naye user ke liye ye fields set karo ─────────
        if (!doc.exists()) {
            // ✅ FIX: "createdAt" add kiya — admin panel "createdAt" field read karta hai
            // "joinedAt" bhi rakha backward compatibility ke liye
            updateData["createdAt"]      = com.google.firebase.Timestamp.now()
            updateData["joinedAt"]       = com.google.firebase.Timestamp.now()
            updateData["plan"]           = "free"
            updateData["planStarted"]    = com.google.firebase.firestore.FieldValue.delete()
            updateData["planExpires"]    = com.google.firebase.firestore.FieldValue.delete()
            updateData["downloadsToday"] = 0
            updateData["totalDownloads"] = 0
            updateData["uploadsCount"]   = 0
            updateData["downloads"]      = 0  // Admin panel "downloads" field read karta hai
        }

        docRef.set(updateData, SetOptions.merge()).await()

        // ── FCM token save karo ───────────────────────────────
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            if (token.isNotBlank()) {
                docRef.set(mapOf("fcmToken" to token), SetOptions.merge()).await()
            }
        } catch (_: Exception) {}
    }

    fun listenForBlockStatus(
        onBlocked   : () -> Unit,
        onUnblocked : () -> Unit
    ) {
        val uid = currentUser?.uid ?: return
        firestore.collection("users")
            .document(uid)
            .addSnapshotListener { snapshot, _ ->
                // snapshot = null means network issue — don't block on null
                if (snapshot == null) return@addSnapshotListener
                val status = snapshot.getString("status") ?: "active"
                if (status == "blocked" || status == "Blocked") {
                    onBlocked()
                } else {
                    onUnblocked()
                }
            }
    }
}