package com.statusseva.app.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.util.Date

object SubscriptionManager {

    private val firestore = FirebaseFirestore.getInstance()

    // ── Payment success hone pe call karo ─────────────────────
    suspend fun activateSubscription(
        uid       : String,
        paymentId : String,
        planId    : String = "plan_SUGTEPGSBQ7nPs"
    ) {
        val now     = System.currentTimeMillis()
        val expires = now + (30L * 24 * 60 * 60 * 1000)   // 30 days

        val data = mapOf(
            "plan"            to "pro",
            "planStarted"     to Timestamp(Date(now)),
            "planExpires"     to Timestamp(Date(expires)),
            "lastPaymentId"   to paymentId,
            "planId"          to planId,
            "subscriptionActive" to true
        )
        firestore.collection("users")
            .document(uid)
            .set(data, SetOptions.merge())
            .await()

        // ── Subscription history save karo ────────────────────
        firestore.collection("subscriptions").add(
            mapOf(
                "uid"        to uid,
                "paymentId"  to paymentId,
                "planId"     to planId,
                "amount" to 1000,
                "status"     to "active",
                "startedAt"  to Timestamp(Date(now)),
                "expiresAt"  to Timestamp(Date(expires)),
                "createdAt"  to Timestamp.now()
            )
        ).await()
    }

    // ── Subscription status check ─────────────────────────────
    suspend fun getSubscriptionStatus(uid: String): SubscriptionStatus {
        val doc = firestore.collection("users").document(uid).get().await()
        val plan    = doc.getString("plan") ?: "free"
        val expires = doc.getTimestamp("planExpires")?.toDate()?.time ?: 0L
        val now     = System.currentTimeMillis()

        return SubscriptionStatus(
            plan          = plan,
            isActive      = plan == "pro" && expires > now,
            expiresAt     = expires,
            daysRemaining = if (expires > now) ((expires - now) / (24 * 60 * 60 * 1000)).toInt() else 0
        )
    }
}

data class SubscriptionStatus(
    val plan          : String  = "free",
    val isActive      : Boolean = false,
    val expiresAt     : Long    = 0L,
    val daysRemaining : Int     = 0
)