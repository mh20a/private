package com.statusseva.app.ui.home

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ── Global Video Cache — 100MB ────────────────────────────────
@SuppressLint("UnsafeOptInUsageError")
var videoCache: SimpleCache? = null

@OptIn(UnstableApi::class)
fun getVideoCache(context: android.content.Context): SimpleCache {
    if (videoCache == null) {
        val cacheDir = File(context.cacheDir, "video_cache")
        val evictor  = LeastRecentlyUsedCacheEvictor(100L * 1024L * 1024L)
        videoCache   = SimpleCache(cacheDir, evictor)
    }
    return videoCache!!
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayer(
    videoUrl     : String,
    modifier     : Modifier = Modifier,
    isVisible    : Boolean  = true,
    sharedPlayer : ExoPlayer? = null,
    aspectRatio  : Float? = null
) {
    val context        = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var videoRatio  by remember { mutableStateOf<Float?>(aspectRatio) }
    var isBuffering by remember { mutableStateOf(true) }

    // ── Pre-fetch ratio BEFORE play ───────────────────────────
    LaunchedEffect(videoUrl, aspectRatio) {
        if (aspectRatio != null) {
            videoRatio = aspectRatio
            return@LaunchedEffect
        }
        if (videoUrl.isBlank()) return@LaunchedEffect
        coroutineScope.launch {
            try {
                val ratio = withContext(Dispatchers.IO) {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(videoUrl, HashMap<String, String>())
                    val width    = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
                    )?.toFloatOrNull()
                    val height   = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
                    )?.toFloatOrNull()
                    val rotation = retriever.extractMetadata(
                        android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
                    )?.toIntOrNull() ?: 0
                    retriever.release()
                    if (width != null && height != null && width > 0 && height > 0) {
                        if (rotation == 90 || rotation == 270) height / width
                        else width / height
                    } else null
                }
                if (ratio != null) videoRatio = ratio
            } catch (_: Exception) {}
        }
    }

    // ── ExoPlayer with Cache + Progressive Streaming ──────────
    val internalPlayer = remember(videoUrl, sharedPlayer) {
        if (sharedPlayer != null) null else {
            val cache           = getVideoCache(context)
            val upstreamFactory = DefaultDataSource.Factory(context)
            val cacheFactory    = CacheDataSource.Factory()
                .setCache(cache)
                .setUpstreamDataSourceFactory(upstreamFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
            val mediaSourceFactory = DefaultMediaSourceFactory(cacheFactory)

            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(2_000, 30_000, 1_000, 2_000)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()

            ExoPlayer.Builder(context)
                .setMediaSourceFactory(mediaSourceFactory)
                .setLoadControl(loadControl)
                .build()
                .apply {
                    setMediaItem(MediaItem.fromUri(videoUrl))
                    prepare()
                    repeatMode = Player.REPEAT_MODE_ONE
                }
        }
    }

    val activePlayer = sharedPlayer ?: internalPlayer!!

    DisposableEffect(activePlayer, videoUrl) {
        // Initialize immediately based on current state
        val isCurrentVideo = activePlayer.currentMediaItem?.localConfiguration?.uri?.toString() == videoUrl
        if (isCurrentVideo) {
            isBuffering = when (activePlayer.playbackState) {
                Player.STATE_BUFFERING, Player.STATE_IDLE -> true
                else -> false
            }
        } else {
            isBuffering = true
        }

        val listener = object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.width > 0 && size.height > 0)
                    videoRatio = size.width.toFloat() / size.height.toFloat()
            }
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = when (state) {
                    Player.STATE_BUFFERING -> true
                    Player.STATE_IDLE      -> true
                    Player.STATE_READY     -> false
                    Player.STATE_ENDED     -> false
                    else                   -> false
                }
            }
        }
        activePlayer.addListener(listener)
        onDispose { activePlayer.removeListener(listener) }
    }

    LaunchedEffect(isVisible, videoUrl) {
        if (isVisible) {
            val currentUri = activePlayer.currentMediaItem?.localConfiguration?.uri?.toString()
            if (currentUri != videoUrl) {
                activePlayer.setMediaItem(MediaItem.fromUri(videoUrl))
                activePlayer.prepare()
            }
            activePlayer.play()
        } else {
            val currentUri = activePlayer.currentMediaItem?.localConfiguration?.uri?.toString()
            if (currentUri == videoUrl) activePlayer.pause()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE  -> activePlayer.pause()
                Lifecycle.Event.ON_RESUME -> if (isVisible) activePlayer.play()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            internalPlayer?.release()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "video_shimmer")
    val shimmerX by infiniteTransition.animateFloat(
        initialValue  = -800f,
        targetValue   = 800f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label         = "shimmer_x"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(Color(0xFF2A2A2A), Color(0xFF3D3D3D), Color(0xFF2A2A2A)),
        start  = Offset(shimmerX - 400f, shimmerX - 400f),
        end    = Offset(shimmerX + 400f, shimmerX + 400f)
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (videoRatio != null) Modifier.aspectRatio(videoRatio!!)
                else Modifier.aspectRatio(9f / 16f)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                if (isVisible) {
                    if (activePlayer.isPlaying) {
                        activePlayer.pause()
                    } else {
                        activePlayer.play()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player        = activePlayer
                    // ── Controls BILKUL nahi — na buttons, na speed ──
                    useController = false
                    resizeMode    = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams  = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                if (playerView.player != activePlayer) {
                    playerView.player = activePlayer
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isBuffering) {
            Box(
                modifier         = Modifier
                    .fillMaxSize()
                    .background(shimmerBrush),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier    = Modifier.size(44.dp),
                    color       = Color.White.copy(alpha = 0.8f),
                    strokeWidth = 3.dp
                )
            }
        }
    }
}