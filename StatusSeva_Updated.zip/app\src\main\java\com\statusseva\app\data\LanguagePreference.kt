package com.statusseva.app.data

import android.content.Context
import android.util.Log
import com.google.firebase.messaging.FirebaseMessaging

object LanguagePreference {

    private const val PREFS_NAME       = "lang_prefs"
    private const val KEY_CONTENT_LANG = "content_language"
    private const val KEY_APP_LANG     = "app_language"
    private const val KEY_FIRST_TIME   = "is_first_time"

    // ── Content language (posts filter) ───────────────────────
    fun setContentLanguage(context: Context, lang: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CONTENT_LANG, lang).apply()
        // Language change hone pe FCM topics bhi update karo
        updateFCMTopics(lang)
    }

    fun getContentLanguage(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CONTENT_LANG, "") ?: ""
    }

    // ── App UI language ───────────────────────────────────────
    fun setAppLanguage(context: Context, lang: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_APP_LANG, lang).apply()
    }

    fun getAppLanguage(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_APP_LANG, "hi") ?: "hi"
    }

    // ── First time check ──────────────────────────────────────
    fun isFirstTime(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_FIRST_TIME, true)
    }

    fun setFirstTimeDone(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_FIRST_TIME, false).apply()
    }

    // ── FCM Topics update — language ke hisaab se ─────────────
    // "all"     = sabhi users ko milegi (hamesha subscribe)
    // "lang_hi" = sirf Hindi users
    // "lang_mr" = sirf Marathi users
    fun updateFCMTopics(lang: String) {
        val messaging = FirebaseMessaging.getInstance()

        // "all" topic hamesha subscribe rehta hai
        messaging.subscribeToTopic("all")
            .addOnCompleteListener { Log.d("FCM_TOPICS", "Subscribed: all") }

        when (lang) {
            "hi" -> {
                messaging.subscribeToTopic("lang_hi")
                    .addOnCompleteListener { Log.d("FCM_TOPICS", "Subscribed: lang_hi") }
                messaging.unsubscribeFromTopic("lang_mr")
                    .addOnCompleteListener { Log.d("FCM_TOPICS", "Unsubscribed: lang_mr") }
            }
            "mr" -> {
                messaging.subscribeToTopic("lang_mr")
                    .addOnCompleteListener { Log.d("FCM_TOPICS", "Subscribed: lang_mr") }
                messaging.unsubscribeFromTopic("lang_hi")
                    .addOnCompleteListener { Log.d("FCM_TOPICS", "Unsubscribed: lang_hi") }
            }
            else -> {
                // Blank = dono languages subscribe karo
                messaging.subscribeToTopic("lang_hi")
                messaging.subscribeToTopic("lang_mr")
                Log.d("FCM_TOPICS", "Subscribed both: lang_hi + lang_mr")
            }
        }
    }
}