package com.statusseva.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.ProfileManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyFirebaseMessagingService : FirebaseMessagingService() {

    // ── New token milne pe ProfileManager se save karo ───────
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM_TOKEN", "New token received")
        // ProfileManager handle karega — userId check + Firestore save
        ProfileManager.saveFcmTokenToFirestore(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {

        val title    = remoteMessage.notification?.title
            ?: remoteMessage.data["title"]
            ?: "New Notification"
        val body     = remoteMessage.notification?.body
            ?: remoteMessage.data["body"]
            ?: ""
        val imageUrl = remoteMessage.notification?.imageUrl?.toString()
            ?: remoteMessage.data["imageUrl"]
            ?: ""
        val postId         = remoteMessage.data["postId"]         ?: ""
        val category       = remoteMessage.data["category"]       ?: ""
        val notifLang      = remoteMessage.data["language"]       ?: ""
        val specificUserId = remoteMessage.data["specificUserId"] ?: ""

        // ── Filter 1: Specific user check ────────────────────
        if (specificUserId.isNotBlank()) {
            val myUserId = ProfileManager.getUserId()
            if (myUserId != specificUserId) {
                Log.d("FCM_FILTER", "Ignoring — specific user mismatch")
                return
            }
        }

        // ── Filter 2: Language check ──────────────────────────
        if (notifLang.isNotBlank()) {
            val myLang = LanguagePreference.getContentLanguage(applicationContext)
            if (myLang.isNotBlank() && myLang != notifLang) {
                Log.d("FCM_FILTER", "Ignoring — lang mismatch: notif=$notifLang user=$myLang")
                return
            }
        }

        if (imageUrl.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                val bitmap = downloadImage(imageUrl)
                showNotification(title, body, bitmap, postId, category)
            }
        } else {
            showNotification(title, body, null, postId, category)
        }
    }

    private suspend fun downloadImage(url: String): Bitmap? {
        return try {
            val loader  = ImageLoader(applicationContext)
            val request = ImageRequest.Builder(applicationContext)
                .data(url)
                .allowHardware(false)
                .build()
            val result = loader.execute(request)
            if (result is SuccessResult) (result.drawable as BitmapDrawable).bitmap
            else null
        } catch (e: Exception) {
            Log.e("FCM_IMAGE", "Image download failed: ${e.message}")
            null
        }
    }

    private fun showNotification(
        title    : String,
        body     : String,
        image    : Bitmap?,
        postId   : String,
        category : String
    ) {
        val channelId = "status_channel"
        val manager   = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Status Seva",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "StatusSeva notifications" }
            manager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("postId",           postId)
            putExtra("category",         category)
            putExtra("fromNotification", true)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.drawable.logo)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(
                if (image != null) {
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(image)
                        .setBigContentTitle(title)
                        .setSummaryText(body)
                } else {
                    NotificationCompat.BigTextStyle().bigText(body)
                }
            )
            .apply { if (image != null) setLargeIcon(image) }

        manager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
}