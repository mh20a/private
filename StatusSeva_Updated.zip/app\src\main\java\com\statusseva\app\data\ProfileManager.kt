package com.statusseva.app.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.util.UUID

object ProfileManager {

    private const val PREFS_NAME = "statusseva_profile_prefs"

    private const val KEY_NAME = "user_name"
    private const val KEY_EMAIL = "user_email"
    private const val KEY_IMAGE_URI = "profile_image_uri"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_REGISTERED = "is_registered"

    private lateinit var prefs: SharedPreferences

    private val firestore = FirebaseFirestore.getInstance()

    var userName by mutableStateOf("")
        private set

    var userEmail by mutableStateOf("")
        private set

    var profileImageUri by mutableStateOf<Uri?>(null)
        private set

    private var userId: String = ""

    // ----------------------------------
    // INIT (CALL IN MAIN ACTIVITY)
    // ----------------------------------

    fun init(context: Context) {

        prefs = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        userName = prefs.getString(KEY_NAME, "") ?: ""
        userEmail = prefs.getString(KEY_EMAIL, "") ?: ""

        val uriString = prefs.getString(KEY_IMAGE_URI, null)
        profileImageUri = uriString?.let { Uri.parse(it) }

        userId = prefs.getString(KEY_USER_ID, null)
            ?: UUID.randomUUID().toString()

        prefs.edit().putString(KEY_USER_ID, userId).apply()

        saveUserToFirestore()
    }

    // ── Firebase Auth UID se sync karo — login ke baad call hota hai
    // Ye ensure karta hai ki ProfileManager aur Firestore same UID use karein
    fun syncWithFirebaseUid(firebaseUid: String) {
        if (firebaseUid.isBlank()) return
        if (userId == firebaseUid) return  // already synced

        // Purana UUID wala document tha to migrate nahi karte — bas UID update
        userId = firebaseUid
        prefs.edit().putString(KEY_USER_ID, firebaseUid).apply()

        Log.d("PROFILE_SYNC", "Synced to Firebase UID: $firebaseUid")

        // Naye UID se FCM token bhi save karo
        fetchAndSaveFcmToken()
    }

    // ── FCM token fetch karke save karo ──────────────────────
    fun fetchAndSaveFcmToken() {
        if (userId.isBlank()) return
        com.google.firebase.messaging.FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                if (token.isNotBlank()) {
                    saveFcmTokenToFirestore(token)
                }
            }
            .addOnFailureListener {
                Log.e("FCM_TOKEN", "Token fetch failed: ${it.message}")
            }
    }

    // ── Token directly save karo (onNewToken se call hota hai)
    fun saveFcmTokenToFirestore(token: String) {
        if (userId.isBlank() || token.isBlank()) return
        firestore.collection("users")
            .document(userId)
            .set(mapOf("fcmToken" to token), SetOptions.merge())
            .addOnSuccessListener {
                Log.d("FCM_TOKEN", "Token saved for: $userId")
            }
            .addOnFailureListener {
                Log.e("FCM_TOKEN", "Token save failed: ${it.message}")
            }
    }

    // ----------------------------------
    // CHECK FIRST TIME USER
    // ----------------------------------

    fun isUserRegistered(): Boolean {

        return prefs.getBoolean(KEY_REGISTERED, false)
    }

    // ----------------------------------
    // SAVE USER (FIRST POPUP)
    // ----------------------------------

    fun registerUser(name: String, email: String) {

        userName = name
        userEmail = email

        prefs.edit()
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, email)
            .putBoolean(KEY_REGISTERED, true)
            .apply()

        saveUserToFirestore()
    }

    // ----------------------------------
    // UPDATE NAME
    // ----------------------------------

    fun saveName(name: String) {

        userName = name

        prefs.edit()
            .putString(KEY_NAME, name)
            .apply()

        saveUserToFirestore()
    }

    // ----------------------------------
    // SAVE PROFILE IMAGE
    // ----------------------------------

    fun saveImageUri(uri: Uri?) {

        profileImageUri = uri

        if (uri != null) {

            prefs.edit()
                .putString(KEY_IMAGE_URI, uri.toString())
                .apply()

        } else {

            prefs.edit()
                .remove(KEY_IMAGE_URI)
                .apply()
        }

        saveUserToFirestore()
    }

    // ----------------------------------
    // FIRESTORE USER SAVE
    // ----------------------------------

    private fun saveUserToFirestore() {

        if (userId.isEmpty()) return

        val userData = hashMapOf(

            "userId" to userId,
            "name" to userName,
            "email" to userEmail,
            "downloads" to 0,
            "blocked" to false,
            "createdAt" to System.currentTimeMillis()
        )

        firestore.collection("users")
            .document(userId)
            .set(userData, SetOptions.merge())
            .addOnSuccessListener {

                Log.d("FIRESTORE_USER", "User saved")

            }
            .addOnFailureListener {

                Log.e("FIRESTORE_USER", "Error saving user")
            }
    }

    // ----------------------------------
    // REALTIME BLOCK LISTENER
    // ----------------------------------

    fun listenForBlockStatus(
        onBlocked: () -> Unit,
        onUnblocked: () -> Unit
    ) {

        if (userId.isEmpty()) return

        firestore.collection("users")
            .document(userId)
            .addSnapshotListener { snapshot, error ->

                if (error != null) {
                    Log.e("BLOCK_CHECK", "Error listening block status")
                    return@addSnapshotListener
                }

                val blocked = snapshot?.getBoolean("blocked") ?: false

                if (blocked) {

                    Log.d("BLOCK_CHECK", "User is BLOCKED")

                    onBlocked()

                } else {

                    Log.d("BLOCK_CHECK", "User is UNBLOCKED")

                    onUnblocked()
                }
            }
    }

    // ----------------------------------
    // GET USER ID
    // ----------------------------------

    fun getUserId(): String {

        return userId
    }
}