package com.statusseva.app.ui.branding1

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.firebase.auth.FirebaseAuth
import com.statusseva.app.data.UserBrandingManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrandingBottomSheetContent(
    onDismiss: () -> Unit
) {
    val context  = LocalContext.current
    val branding = UserBrandingManager
    val isSystemDark = isSystemInDarkTheme()

    // ── STATES ──
    var name          by remember { mutableStateOf(branding.brandingName) }
    var photoUri      by remember { mutableStateOf(branding.brandingPhotoUri) }
    var selectedColor by remember { mutableStateOf(branding.brandingColor) }
    var isEnabled     by remember { mutableStateOf(branding.isBrandingEnabled) }
    var isLeft        by remember { mutableStateOf(branding.isLeftDesign) }
    var isOutlineOn   by remember { mutableStateOf(branding.isOutlineEnabled) }

    // 🌟 BUG FIX STATE: For instant photo update bypass caching
    var imageRefreshTrigger by remember { mutableLongStateOf(0L) }

    val googlePhotoUrl = remember { FirebaseAuth.getInstance().currentUser?.photoUrl }
    val displayPhoto: Any? = photoUri ?: googlePhotoUrl

    // ── AUTO-SAVE ON SHEET DISMISS ──
    // Jab ye bottom sheet close hogi toh name auto save ho jayega.
    DisposableEffect(Unit) {
        onDispose {
            branding.setName(context, name)
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri
            imageRefreshTrigger = System.currentTimeMillis() // 🌟 Instantly trigger recomposition
            branding.setPhotoUri(context, uri)
        }
    }

    fun isColorLight(color: Int): Boolean {
        if (color == -2 || color == -3) return false
        val r = (color shr 16 and 0xFF) / 255.0
        val g = (color shr 8  and 0xFF) / 255.0
        val b = (color        and 0xFF) / 255.0
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) > 0.5
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ── SHEET TITLE & CLOSE ROW ──
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text       = "Branding Strip Setup",
                fontWeight = FontWeight.Bold,
                style      = MaterialTheme.typography.titleLarge
            )
            // Added close icon top right since we removed save button
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close and Save")
            }
        }

        // ── 1. ENABLE/DISABLE CARD ──
        Card(
            modifier  = Modifier.fillMaxWidth(),
            shape     = RoundedCornerShape(14.dp),
            colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier          = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Style, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Branding Strip", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text("Share/Download pe apna naam aur photo dikhao", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked         = isEnabled,
                    onCheckedChange = { isEnabled = it; branding.setEnabled(context, it) }
                )
            }
        }

        if (isEnabled) {
            // ── 2. DESIGN POSITION TOGGLE (LEFT/RIGHT) ──
            Card(
                onClick = {
                    isLeft = !isLeft
                    branding.setDesignPosition(context, isLeft)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Flip, null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Change Design Position", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text("Logo Position: ${if(isLeft) "Left" else "Right"}", style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }

            // ── 3. LOGO BORDER GLOW TOGGLE ──
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BlurOn, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Logo Border Glow", fontWeight = FontWeight.SemiBold)
                        Text("Mixed colourful outline on photo", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = isOutlineOn, onCheckedChange = { isOutlineOn = it; branding.setOutlineEnabled(context, it) })
                }
            }

            // ── 4. LIVE PREVIEW BOX ──
            Text("Preview", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

            val stripBg = when(selectedColor) {
                -2 -> Brush.horizontalGradient(listOf(Color(0xFFFF9933), Color.White, Color(0xFF138808))) // Tiranga
                -3 -> Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta)) // Mixed
                else -> {
                    // DEFAULT LOGIC: Dark->White, Light->Orange
                    val finalCol = if (selectedColor == 0 || selectedColor == android.graphics.Color.WHITE) {
                        if (isSystemDark) Color.White else Color(0xFFFFA500)
                    } else Color(selectedColor)
                    Brush.linearGradient(listOf(finalCol, finalCol))
                }
            }

            val isLight      = remember(selectedColor) { isColorLight(selectedColor) }
            val previewTxtCol = if (selectedColor == -2) Color.Black else if (isLight) Color(0xFF1a1a1a) else Color.White
            val stripH       = 44.dp
            val photoSize    = 66.dp
            val photoHalf    = photoSize / 2

            Box(modifier = Modifier.fillMaxWidth().height(stripH + photoHalf).clip(RoundedCornerShape(12.dp)).border(0.5.dp, Color.Black.copy(0.1f), RoundedCornerShape(12.dp))) {

                // Background with Black Thin Outline
                Box(modifier = Modifier.fillMaxWidth().height(stripH).align(Alignment.BottomCenter).background(stripBg).border(1.dp, Color.Black, RectangleShape))

                Box(
                    modifier = Modifier.fillMaxWidth().padding(
                        start = if (isLeft) photoSize + 12.dp else 12.dp,
                        end   = if (isLeft) 12.dp else photoSize + 12.dp
                    ).height(stripH).align(Alignment.BottomCenter), 
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = name.ifBlank { googlePhotoUrl?.let { FirebaseAuth.getInstance().currentUser?.displayName } ?: "Aapka Naam" }, color = previewTxtCol, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 1)
                }

                // Logo Position and Glow Logic
                val photoAlign = if (isLeft) Alignment.BottomStart else Alignment.BottomEnd
                val photoPadding = if (isLeft) Modifier.padding(start = 10.dp) else Modifier.padding(end = 10.dp)

                Box(modifier = Modifier.align(photoAlign).then(photoPadding).offset(y = -photoHalf).size(photoSize).clip(CircleShape)
                    .then(
                        if (isOutlineOn) {
                            Modifier.border(3.dp, Brush.sweepGradient(listOf(Color.Red, Color.Magenta, Color.Blue, Color.Cyan, Color.Green, Color.Yellow, Color.Red)), CircleShape)
                        } else {
                            Modifier.border(2.dp, if (selectedColor == android.graphics.Color.WHITE) Color.LightGray else Color.White, CircleShape)
                        }
                    ), contentAlignment = Alignment.Center) {
                    if (displayPhoto != null) {
                        // 🌟 INSTANT LOAD BUG FIX: Memory Cache Busted using refresh trigger
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(displayPhoto)
                                .memoryCacheKey("${displayPhoto}_$imageRefreshTrigger")
                                .diskCacheKey("${displayPhoto}_$imageRefreshTrigger")
                                .crossfade(true)
                                .build(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize().background(Color(0xFF6C63FF)), contentAlignment = Alignment.Center) {
                            Text(text = name.trim().take(1).uppercase().ifBlank { "U" }, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ── 5. NAME INPUT FIELD ──
            Text("Aapka Naam", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(
                value         = name,
                onValueChange = { name = it; branding.setName(context, it) }, // Autosave on type
                placeholder   = { Text("Naam type karein...") },
                singleLine    = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                leadingIcon   = { Icon(Icons.Default.Person, null) }
            )

            // ── 6. PHOTO SELECTION SECTION (RESTORED FROM REFERENCE) ──
            Text("Profile Photo", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

            // Info message if using default Google photo
            if (photoUri == null && googlePhotoUrl != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Text("Abhi Google account ki photo use ho rahi hai", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Profile Photo Select UI Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { photoLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (displayPhoto != null) {
                        // 🌟 INSTANT LOAD BUG FIX
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(displayPhoto)
                                .memoryCacheKey("${displayPhoto}_$imageRefreshTrigger")
                                .diskCacheKey("${displayPhoto}_$imageRefreshTrigger")
                                .crossfade(true)
                                .build(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { photoLauncher.launch("image/*") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Image, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (photoUri != null) "Photo Change Karein" else "Custom Photo Select Karein")
                    }

                    if (photoUri != null) {
                        TextButton(
                            onClick = {
                                photoUri = null
                                branding.setPhotoUri(context, null)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Remove (Use Google Photo)", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                    }
                }
            }

            // ── 7. COLOR PALETTE ──
            Text("Strip Color", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(horizontal = 2.dp)) {
                items(UserBrandingManager.presetColors) { colorInt ->
                    val isSelected = selectedColor == colorInt
                    val isWhiteCol = colorInt == android.graphics.Color.WHITE
                    val lightColor = remember(colorInt) { isColorLight(colorInt) }

                    Box(
                        modifier = Modifier.size(48.dp).clip(CircleShape)
                            .then(
                                when(colorInt) {
                                    -2 -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFFFF9933), Color.White, Color(0xFF138808))))
                                    -3 -> Modifier.background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta, Color.Red)))
                                    else -> Modifier.background(Color(colorInt))
                                }
                            )
                            // BORDER LOGIC FOR WHITE COLOR VISIBILITY
                            .border(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                else if (isWhiteCol) Color.Gray else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable {
                                selectedColor = colorInt
                                branding.setColor(context, colorInt)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (colorInt == -2) Text("🇮🇳", fontSize = 10.sp)
                        if (isSelected) {
                            Icon(Icons.Default.Check, null, tint = if (lightColor) Color.Black else Color.White, modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }

            // AUTO-SAVE INFO TEXT
            Text(
                text = "Changes are saved automatically when you go back.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(40.dp))
    }
}