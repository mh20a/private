package com.statusseva.app.model

data class NotificationItem(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val createdAt: Long = 0L,
    val isRead: Boolean = false,
    val postId: String = ""
)