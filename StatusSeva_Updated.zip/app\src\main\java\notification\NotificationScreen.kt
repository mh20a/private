package com.statusseva.app.ui.notification

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.ProfileManager
import com.statusseva.app.model.NotificationItem
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

private const val SEVEN_DAYS_MS = 7L * 24 * 60 * 60 * 1000
private const val PREF_NAME     = "notif_deleted_prefs"
private const val KEY_DELETED   = "deleted_ids"

private fun getDeletedIds(context: Context): MutableSet<String> {
    return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        .getStringSet(KEY_DELETED, emptySet())!!.toMutableSet()
}

private fun saveDeletedId(context: Context, id: String) {
    val prefs    = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    val existing = prefs.getStringSet(KEY_DELETED, emptySet())!!.toMutableSet()
    existing.add(id)
    prefs.edit().putStringSet(KEY_DELETED, existing).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationScreen(
    onBack  : () -> Unit,
    appLang       : String = "hi"
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    val context     = LocalContext.current
    val firestore   = remember { FirebaseFirestore.getInstance() }

    val contentLang = remember { LanguagePreference.getContentLanguage(context) }
    val myUserId    = remember { ProfileManager.getUserId() }

    var notifications by remember { mutableStateOf<List<NotificationItem>>(emptyList()) }
    var isLoading     by remember { mutableStateOf(true) }

    // 🌟 FIX: Real-time Snapshot Listener lagaya hai jisse instant notifications aayengi
    DisposableEffect(Unit) {
        val listener = firestore.collection("notifications")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    // Agar Firebase Rules ki error hogi, toh ab yahan clearly pata chal jayega
                    Toast.makeText(context, "Error: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
                    isLoading = false
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val deletedIds = getDeletedIds(context)
                    val now        = System.currentTimeMillis()
                    val list       = mutableListOf<NotificationItem>()

                    for (doc in snapshot.documents) {
                        if (doc.id in deletedIds) continue

                        val timestamp = doc.get("createdAt") as? Timestamp
                        val time      = timestamp?.toDate()?.time ?: 0L

                        if (time > 0L && (now - time) > SEVEN_DAYS_MS) continue

                        val specificUid = doc.getString("specificUserId")?.trim() ?: ""
                        if (specificUid.isNotBlank() && specificUid != myUserId) continue

                        // 🌟 FIX: Case Insensitive Language Match
                        val notifLang = doc.getString("language")?.trim() ?: ""
                        if (notifLang.isNotBlank() && !notifLang.equals(contentLang, ignoreCase = true)) continue

                        list.add(
                            NotificationItem(
                                id        = doc.id,
                                title     = doc.getString("title")   ?: "",
                                message   = doc.getString("message") ?: "",
                                createdAt = time,
                                isRead    = doc.getBoolean("isRead") ?: false,
                                postId    = doc.getString("postId")  ?: ""
                            )
                        )
                    }

                    notifications = list.sortedByDescending { it.createdAt }
                    isLoading     = false
                }
            }

        onDispose { listener.remove() }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        Text(
                            text       = str("notif_title"),
                            fontWeight = FontWeight.Bold,
                            style      = MaterialTheme.typography.titleLarge
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick  = onBack,
                            modifier = Modifier.size(56.dp)
                        ) {
                            Icon(
                                imageVector        = Icons.Default.ArrowBack,
                                contentDescription = str("cancel"),
                                modifier           = Modifier.size(28.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color     = MaterialTheme.colorScheme.outlineVariant
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            AnimatedVisibility(
                visible = isLoading,
                enter   = fadeIn(tween(150)),
                exit    = fadeOut(tween(150))
            ) { ShimmerNotificationList() }

            if (!isLoading && notifications.isEmpty()) {
                Column(
                    modifier            = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector        = Icons.Default.NotificationsNone,
                        contentDescription = null,
                        modifier           = Modifier.size(64.dp).alpha(0.3f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text     = str("no_notifs"),
                        style    = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.alpha(0.5f)
                    )
                }
            }

            if (!isLoading && notifications.isNotEmpty()) {
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(
                        items = notifications,
                        key   = { _, item -> item.id }
                    ) { index, notification ->
                        SwipeToDeleteNotificationCard(
                            notification = notification,
                            index        = index,
                            appLang      = appLang,
                            onDismiss    = {
                                saveDeletedId(context, notification.id)
                                notifications = notifications.filter {
                                    it.id != notification.id
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  SHIMMER
// ─────────────────────────────────────────────────────────────

@Composable
fun ShimmerNotificationList() {
    LazyColumn(
        modifier            = Modifier.fillMaxSize(),
        contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(7) { ShimmerCard() }
    }
}

@Composable
fun ShimmerCard() {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerX by infiniteTransition.animateFloat(
        initialValue  = -600f,
        targetValue   = 600f,
        animationSpec = infiniteRepeatable(
            animation  = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerX"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        start = Offset(shimmerX - 200f, 0f),
        end   = Offset(shimmerX + 200f, 0f)
    )
    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier          = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(shimmerBrush))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Box(modifier = Modifier.fillMaxWidth(0.6f).height(14.dp).clip(RoundedCornerShape(4.dp)).background(shimmerBrush))
                Spacer(Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth(0.9f).height(10.dp).clip(RoundedCornerShape(4.dp)).background(shimmerBrush))
                Spacer(Modifier.height(6.dp))
                Box(modifier = Modifier.fillMaxWidth(0.3f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(shimmerBrush))
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  SWIPE TO DELETE
// ─────────────────────────────────────────────────────────────

@Composable
fun SwipeToDeleteNotificationCard(
    notification : NotificationItem,
    index        : Int,
    appLang      : String = "hi",
    onDismiss    : () -> Unit
) {
    var offsetX     by remember { mutableStateOf(0f) }
    var isDismissed by remember { mutableStateOf(false) }
    val dismissThreshold = 280f

    val animatedOffset by animateFloatAsState(
        targetValue      = if (isDismissed)
            if (offsetX > 0) 1200f else -1200f
        else offsetX,
        animationSpec    = if (isDismissed) tween(200)
        else spring(stiffness = Spring.StiffnessMedium),
        finishedListener = { if (isDismissed) onDismiss() },
        label            = "swipe_offset"
    )

    val cardAlpha by animateFloatAsState(
        targetValue   = if (isDismissed) 0f
        else (1f - (offsetX.absoluteValue / 500f)).coerceIn(0.3f, 1f),
        animationSpec = tween(150),
        label         = "card_alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .draggable(
                orientation   = Orientation.Horizontal,
                state         = rememberDraggableState { delta ->
                    if (!isDismissed) offsetX += delta
                },
                onDragStopped = {
                    if (offsetX.absoluteValue > dismissThreshold) isDismissed = true
                    else offsetX = 0f
                }
            )
    ) {
        if (offsetX.absoluteValue > 40f) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        MaterialTheme.colorScheme.errorContainer.copy(
                            alpha = (offsetX.absoluteValue / 500f).coerceIn(0.2f, 0.7f)
                        )
                    ),
                contentAlignment = if (offsetX > 0) Alignment.CenterStart
                else Alignment.CenterEnd
            ) {
                Text(
                    text     = "🗑️",
                    modifier = Modifier.padding(horizontal = 20.dp),
                    style    = MaterialTheme.typography.titleMedium
                )
            }
        }

        Box(
            modifier = Modifier
                .offset { IntOffset(animatedOffset.roundToInt(), 0) }
                .alpha(cardAlpha)
        ) {
            NotificationCard(
                notification = notification,
                index        = index,
                appLang      = appLang
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  NOTIFICATION CARD
// ─────────────────────────────────────────────────────────────

@Composable
fun NotificationCard(
    notification : NotificationItem,
    index        : Int,
    appLang      : String = "hi"
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (notification.isRead)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (notification.isRead) 0.dp else 2.dp
        )
    ) {
        Row(
            modifier          = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier         = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        if (notification.isRead)
                            MaterialTheme.colorScheme.surfaceVariant
                        else
                            MaterialTheme.colorScheme.primaryContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.Notifications,
                    contentDescription = null,
                    modifier           = Modifier.size(20.dp),
                    tint               = if (notification.isRead)
                        MaterialTheme.colorScheme.onSurfaceVariant
                    else
                        MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text       = notification.title,
                    style      = MaterialTheme.typography.titleSmall,
                    fontWeight = if (notification.isRead) FontWeight.Normal
                    else FontWeight.SemiBold
                )
                if (notification.message.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text  = notification.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (notification.createdAt > 0L) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text  = getNotifRelativeTime(notification.createdAt, appLang),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
            if (!notification.isRead) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  RELATIVE TIME HELPER
// ─────────────────────────────────────────────────────────────

fun getNotifRelativeTime(timestamp: Long, lang: String = "hi"): String {
    val diff = System.currentTimeMillis() - timestamp
    return when (lang) {
        "mr" -> when {
            diff < 60_000L      -> "आत्ताच"
            diff < 3_600_000L   -> "${diff / 60_000} मि. पूर्वी"
            diff < 86_400_000L  -> "${diff / 3_600_000} तास पूर्वी"
            diff < 604_800_000L -> "${diff / 86_400_000} दिवस पूर्वी"
            else                -> "${diff / 604_800_000L} आठवडा पूर्वी"
        }
        "en" -> when {
            diff < 60_000L      -> "Just now"
            diff < 3_600_000L   -> "${diff / 60_000}m ago"
            diff < 86_400_000L  -> "${diff / 3_600_000}h ago"
            diff < 604_800_000L -> "${diff / 86_400_000}d ago"
            else                -> "${diff / 604_800_000L}w ago"
        }
        else -> when {
            diff < 60_000L      -> "अभी"
            diff < 3_600_000L   -> "${diff / 60_000} मिनट पहले"
            diff < 86_400_000L  -> "${diff / 3_600_000} घंटे पहले"
            diff < 604_800_000L -> "${diff / 86_400_000} दिन पहले"
            else                -> "${diff / 604_800_000L} हफ्ते पहले"
        }
    }
}