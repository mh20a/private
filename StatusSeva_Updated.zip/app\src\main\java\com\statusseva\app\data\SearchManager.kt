package com.statusseva.app.data

import android.content.Context

class SearchManager(context: Context) {

    private val prefs =
        context.getSharedPreferences("search_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_RECENT_SEARCHES = "recent_searches"
        private const val MAX_HISTORY = 10
    }

    /* -----------------------------------------
       Get Recent Searches
     ----------------------------------------- */
    fun getRecentSearches(): List<String> {

        val saved =
            prefs.getStringSet(KEY_RECENT_SEARCHES, emptySet())
                ?: emptySet()

        // Convert to list and reverse so newest comes first
        return saved.toList().reversed()
    }

    /* -----------------------------------------
       Save Search Query
     ----------------------------------------- */
    fun saveSearch(query: String) {

        if (query.isBlank()) return

        val current =
            prefs.getStringSet(KEY_RECENT_SEARCHES, emptySet())
                ?.toMutableList()
                ?: mutableListOf()

        // Remove if already exists (avoid duplicate)
        current.remove(query)

        // Add to top
        current.add(0, query)

        // Trim if exceeds limit
        if (current.size > MAX_HISTORY) {
            current.subList(MAX_HISTORY, current.size).clear()
        }

        prefs.edit()
            .putStringSet(KEY_RECENT_SEARCHES, current.toSet())
            .apply()
    }

    /* -----------------------------------------
       Clear All History
     ----------------------------------------- */
    fun clearHistory() {
        prefs.edit()
            .remove(KEY_RECENT_SEARCHES)
            .apply()
    }
}