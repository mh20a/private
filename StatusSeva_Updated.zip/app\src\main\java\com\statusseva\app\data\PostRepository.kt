package com.statusseva.app.data

import com.statusseva.app.model.Post

/**
 * PostRepository
 *
 * - Default me dummy data diya gaya hai (offline/testing ke liye)
 * - Future me FirestoreRepository se replace ho sakta hai
 */
object PostRepository {

    // ✅ Categories list (UI ke liye use hoti hai)
    val categories = listOf(
        "All",
        "Motivation",
        "Love",
        "Sad",
        "Friendship",
        "Life",
        "Success"
    )

    // ✅ Dummy data (fallback / testing ke liye)
    private val posts = listOf(
        Post(
            id = "1",
            title = "Believe in Yourself",
            description = "Push yourself because no one else is going to do it for you.",
            category = "Motivation",
            imageUrl = "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee"
        ),
        Post(
            id = "2",
            title = "True Love",
            description = "Love is not what you say. Love is what you do.",
            category = "Love",
            imageUrl = "https://images.unsplash.com/photo-1492724441997-5dc865305da7"
        ),
        Post(
            id = "3",
            title = "Broken Inside",
            description = "Sometimes it's better to be alone. Nobody can hurt you.",
            category = "Sad",
            imageUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330"
        ),
        Post(
            id = "4",
            title = "Best Friends",
            description = "Friends are the family we choose for ourselves.",
            category = "Friendship",
            imageUrl = "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e"
        ),
        Post(
            id = "5",
            title = "Life Journey",
            description = "Life is a journey, not a destination.",
            category = "Life",
            imageUrl = "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429"
        ),
        Post(
            id = "6",
            title = "Success Mindset",
            description = "Success doesn’t come from what you do occasionally. It comes from what you do consistently.",
            category = "Success",
            imageUrl = "https://images.unsplash.com/photo-1498050108023-c5249f4df085"
        )
    )

    /**
     * ✅ Sabhi posts return karega
     * Future: Firestore se replace kar sakte ho
     */
    fun getAllPosts(): List<Post> {
        return posts
    }

    /**
     * ✅ Category ke hisaab se filter
     */
    fun getPostsByCategory(category: String): List<Post> {
        return if (category.equals("All", ignoreCase = true)) {
            posts
        } else {
            posts.filter {
                it.category.equals(category, ignoreCase = true)
            }
        }
    }
}