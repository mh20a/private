# Add project specific ProGuard rules here.
-keep class com.statusseva.app.model.** { *; }
-dontwarn proguard.annotation.Keep
-dontwarn proguard.annotation.KeepClassMembers