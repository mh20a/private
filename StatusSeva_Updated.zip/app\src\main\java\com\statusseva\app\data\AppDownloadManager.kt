package com.statusseva.app.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.model.DownloadedPost
import org.json.JSONArray
import org.json.JSONObject

object AppDownloadManager {

    private const val PREFS_NAME    = "statusseva_download_prefs"
    private const val KEY_DOWNLOADS = "downloaded_posts"

    private lateinit var prefs: SharedPreferences

    private val firestore = FirebaseFirestore.getInstance()

    val downloadedPosts = mutableStateListOf<DownloadedPost>()

    fun init(context: Context) {
        prefs = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadFromPrefs()
    }

    fun addPost(post: DownloadedPost) {
        if (downloadedPosts.none { it.id == post.id }) {
            downloadedPosts.add(0, post)
            saveToPrefs()
            incrementDownloadCount()
        }
    }

    fun deletePost(postId: String) {
        downloadedPosts.removeAll { it.id == postId }
        saveToPrefs()
    }

    fun clearAll() {
        downloadedPosts.clear()
        saveToPrefs()
    }

    fun isDownloaded(postId: String): Boolean {
        return downloadedPosts.any { it.id == postId }
    }

    // ── Firestore download counter — bug fixed ────────────────
    private fun incrementDownloadCount() {
        // ← Direct method call, no reflection
        val userId = ProfileManager.getUserId()
        if (userId.isEmpty()) {
            Log.w("FIRESTORE_DOWNLOAD", "userId empty, skipping download count")
            return
        }
        firestore.collection("users")
            .document(userId)
            .update("downloads", FieldValue.increment(1))
            .addOnSuccessListener {
                Log.d("FIRESTORE_DOWNLOAD", "Download count updated for $userId")
            }
            .addOnFailureListener { e ->
                // User doc exist nahi karta to set karo
                firestore.collection("users")
                    .document(userId)
                    .set(mapOf("downloads" to 1), com.google.firebase.firestore.SetOptions.merge())
                    .addOnFailureListener {
                        Log.e("FIRESTORE_DOWNLOAD", "Failed to update: ${e.message}")
                    }
            }
    }

    // ── SharedPreferences Save ────────────────────────────────
    private fun saveToPrefs() {
        if (!::prefs.isInitialized) return
        val array = JSONArray()
        downloadedPosts.forEach { post ->
            val obj = JSONObject().apply {
                put("id",           post.id)
                put("title",        post.title)
                put("description",  post.description)
                put("category",     post.category)
                put("imageUrl",     post.imageUrl)
                put("downloadedAt", post.downloadedAt)
            }
            array.put(obj)
        }
        prefs.edit().putString(KEY_DOWNLOADS, array.toString()).apply()
    }

    // ── Load From SharedPreferences ───────────────────────────
    private fun loadFromPrefs() {
        if (!::prefs.isInitialized) return
        val json = prefs.getString(KEY_DOWNLOADS, null) ?: return
        try {
            val array = JSONArray(json)
            downloadedPosts.clear()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                downloadedPosts.add(
                    DownloadedPost(
                        id           = obj.optString("id"),
                        title        = obj.optString("title"),
                        description  = obj.optString("description"),
                        category     = obj.optString("category"),
                        imageUrl     = obj.optString("imageUrl"),
                        downloadedAt = obj.optLong("downloadedAt")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}