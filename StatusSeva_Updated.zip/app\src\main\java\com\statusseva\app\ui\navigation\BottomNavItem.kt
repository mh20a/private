package com.statusseva.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.*
data class BottomNavItem(
    val label: String,
    val icon: ImageVector,
    val screen: Screen
)

val bottomNavItems = listOf(
    BottomNavItem(
        label = "Home",
        icon = Icons.Filled.Home,
        screen = Screen.Home
    ),
    BottomNavItem(
        label = "Downloads",
        icon = Icons.Filled.Download,
        screen = Screen.Downloads
    ),
    BottomNavItem(
        label = "Profile",
        icon = Icons.Filled.Person,
        screen = Screen.Profile
    ),
    BottomNavItem(
        label = "Settings",
        icon = Icons.Filled.Settings,
        screen = Screen.Settings
    )
)