package com.statusseva.app.ui.auth

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.statusseva.app.R
import com.statusseva.app.data.GoogleAuthHelper

import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    onLoginSuccess: () -> Unit,
    onUserBlocked: () -> Unit
) {
    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isLoading    by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }



    val logoScale by animateFloatAsState(
        targetValue   = if (visible) 1f else 0.6f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness    = Spring.StiffnessLow
        ),
        label = "logo_scale"
    )

    val contentAlpha by animateFloatAsState(
        targetValue   = if (visible) 1f else 0f,
        animationSpec = tween(600),
        label         = "content_alpha"
    )

    Box(modifier = Modifier.fillMaxSize()) {

        // 🌟 1. Background Video Layer (Sabse peeche)
        BackgroundVideoPlayer()

        // 🌟 2. Gradient Overlay (Video ko thoda dim/blend karne ke liye taaki text clear padha jaye)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.5f), // Top se thoda transparent
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.95f) // Bottom se almost solid
                        )
                    )
                )
        )

        // 🌟 3. Original Content Layer (Sabse aage)
        Column(
            modifier            = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            // ── Logo ──────────────────────────────────────────
            Image(
                painter            = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier           = Modifier
                    .size(100.dp)
                    .scale(logoScale)
            )

            Spacer(Modifier.height(20.dp))

            // ── App Name ──────────────────────────────────────
            Text(
                text       = stringResource(R.string.app_name),
                style      = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color      = MaterialTheme.colorScheme.onSurface,
                modifier   = Modifier.alpha(contentAlpha)
            )

            Spacer(Modifier.height(8.dp))

            // ── Tagline ───────────────────────────────────────
            Text(
                text      = "Beautiful status for every moment",
                style     = MaterialTheme.typography.bodyMedium,
                color     = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier  = Modifier.alpha(contentAlpha)
            )

            Spacer(Modifier.height(60.dp))

            // ── Google Sign In Button ─────────────────────────
            AnimatedVisibility(
                visible = !isLoading,
                enter   = fadeIn(tween(300)) + scaleIn(tween(300)),
                exit    = fadeOut(tween(200))
            ) {
                OutlinedButton(
                    onClick = {
                        isLoading    = true
                        errorMessage = null
                        coroutineScope.launch {
                            val result = GoogleAuthHelper.signInWithGoogle(context)
                            result.fold(
                                onSuccess = {
                                    isLoading = false
                                    onLoginSuccess()
                                },
                                onFailure = { exception ->
                                    isLoading = false
                                    if (exception.message == "USER_BLOCKED") {
                                        onUserBlocked()
                                    } else {
                                        errorMessage = "Sign in failed: ${exception.message}"
                                    }
                                }
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape  = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Image(
                        painter            = painterResource(R.drawable.ic_google),
                        contentDescription = null,
                        modifier           = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text       = "Continue with Google",
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color      = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // ── Loading ───────────────────────────────────────
            AnimatedVisibility(
                visible = isLoading,
                enter   = fadeIn(tween(200)),
                exit    = fadeOut(tween(200))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text  = "Signing in...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ── Error ─────────────────────────────────────────
            errorMessage?.let { msg ->
                Spacer(Modifier.height(16.dp))
                Text(
                    text  = msg,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(Modifier.height(40.dp))

            // ── Clickable Legal Footer ──────────────────────────
            val annotatedString = buildAnnotatedString {
                append("By continuing you agree to our ")

                // Clickable Terms
                pushStringAnnotation(tag = "terms", annotation = "terms")
                withStyle(style = SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)) {
                    append("Terms")
                }
                pop()

                append(" & ")

                // Clickable Privacy Policy
                pushStringAnnotation(tag = "privacy", annotation = "privacy")
                withStyle(style = SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)) {
                    append("Privacy Policy")
                }
                pop()
            }

            ClickableText(
                text = annotatedString,
                style = TextStyle(
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    fontSize = MaterialTheme.typography.labelSmall.fontSize,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth().alpha(contentAlpha),
                onClick = { offset ->
                    annotatedString.getStringAnnotations(tag = "terms", start = offset, end = offset).firstOrNull()?.let {
                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://statusseva.in/privacy.html")))
                    }
                    annotatedString.getStringAnnotations(tag = "privacy", start = offset, end = offset).firstOrNull()?.let {
                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://statusseva.in/privacy.html")))
                    }
                }
            )
        }


    }
}

// 🌟 NEW: Background Video Player Composable
@OptIn(UnstableApi::class)
@Composable
fun BackgroundVideoPlayer() {
    val context = LocalContext.current

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            // Raw folder me rakhi 'animations.mp4' file ko access karna
            val uri = Uri.parse("android.resource://${context.packageName}/${R.raw.animations}")
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            volume = 0f // Video ko mute karna taaki background me sound disturb na kare
            repeatMode = Player.REPEAT_MODE_ONE // Continuous loop
            playWhenReady = true
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release() // Memory leak se bachne ke liye release karna zaroori hai
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                useController = false // User video ko pause/play na kar sake
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM // Screen ko full cover karne ke liye
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                // Video aspect ratio fill karne ke karan jo black bars aate hain unhe hatane ke liye
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}