package com.statusseva.app.ui.branding

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.firebase.auth.FirebaseAuth
import com.statusseva.app.data.UserBrandingManager

/**
 * BRANDING SETUP SCREEN
 * Features: Auto-Save on Back, Save in TopBar, Instant Photo Update Fix, Design Flip, Logo Outline Toggle, Premium Colors.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrandingSetupScreen(onBack: () -> Unit) {

    // ──────────────────────────────────────────────────────────
    // 1. INITIALIZATION & CONTEXT
    // ──────────────────────────────────────────────────────────
    val context = LocalContext.current
    val branding = UserBrandingManager
    val isSystemDark = isSystemInDarkTheme()

    // ──────────────────────────────────────────────────────────
    // 2. STATES MANAGEMENT
    // ──────────────────────────────────────────────────────────
    var name by remember { mutableStateOf(branding.brandingName) }
    var photoUri by remember { mutableStateOf(branding.brandingPhotoUri) }
    var selectedColor by remember { mutableStateOf(branding.brandingColor) }
    var isEnabled by remember { mutableStateOf(branding.isBrandingEnabled) }
    var isLeftDesign by remember { mutableStateOf(branding.isLeftDesign) }
    var isOutlineOn by remember { mutableStateOf(branding.isOutlineEnabled) }

    // 🌟 BUG FIX STATE: Isse Coil cache bypass karke photo turant 1st time me update karega
    var imageRefreshTrigger by remember { mutableLongStateOf(0L) }

    // Firebase Auth for default profile photo fallback
    val googlePhotoUrl = remember {
        FirebaseAuth.getInstance().currentUser?.photoUrl
    }

    // Display priority: Custom Uploaded Photo > Google Account Photo > Initials
    val displayPhoto: Any? = photoUri ?: googlePhotoUrl

    // ──────────────────────────────────────────────────────────
    // 3. AUTO-SAVE LOGIC & LAUNCHERS
    // ──────────────────────────────────────────────────────────

    // Auto-Save Function
    val saveAndExit = {
        branding.setName(context, name)
        // Baki options (Color, Toggle) turant save ho jate hain, Name yahan save hoga.
        onBack()
    }

    // Intercept System Back Button & Gesture for Auto-Save
    BackHandler(onBack = saveAndExit)

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri
            imageRefreshTrigger = System.currentTimeMillis() // 🌟 Cache Buster update
            branding.setPhotoUri(context, uri)
        }
    }

    /**
     * Determines if a color is light or dark to switch text colors (Black/White).
     */
    fun isColorLight(color: Int): Boolean {
        // Special markers for Mixed and Tiranga
        if (color == -2 || color == -3) return false

        val r = (color shr 16 and 0xFF) / 255.0
        val g = (color shr 8  and 0xFF) / 255.0
        val b = (color        and 0xFF) / 255.0

        val luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b)
        return luminance > 0.5
    }

    // ──────────────────────────────────────────────────────────
    // 4. UI STRUCTURE (SCAFFOLD)
    // ──────────────────────────────────────────────────────────
    Scaffold(
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        Text(
                            text = "Branding Setup",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = saveAndExit) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    // 🌟 NEW: SAVE BUTTON IN TOP BAR
                    actions = {
                        TextButton(onClick = saveAndExit) {
                            Text(
                                text = "Save",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outlineVariant
                )
            }
        }
    ) { paddingValues ->

        // Main Scrolling Container
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {

            // ── SECTION 1: MASTER ENABLE SWITCH ──────────────────
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(0.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Branding Strip Status",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Enable to show your logo on posts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = {
                            isEnabled = it
                            branding.setEnabled(context, it)
                        }
                    )
                }
            }

            if (isEnabled) {

                // ── SECTION 2: DESIGN FLIP (LEFT/RIGHT) ──────────
                Text(
                    text = "Layout Configuration",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    onClick = {
                        isLeftDesign = !isLeftDesign
                        branding.setDesignPosition(context, isLeftDesign)
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Swap Photo Position",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = "Currently aligned to: ${if(isLeftDesign) "LEFT" else "RIGHT"}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Icon(Icons.Default.SyncAlt, null, tint = MaterialTheme.colorScheme.secondary)
                    }
                }

                // ── SECTION 3: LOGO BORDER GLOW TOGGLE ───────────
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BlurOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Logo Border Glow",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Add colorful gradient around photo",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = isOutlineOn,
                            onCheckedChange = {
                                isOutlineOn = it
                                branding.setOutlineEnabled(context, it)
                            }
                        )
                    }
                }

                // ── SECTION 4: LIVE PREVIEW BOX ───────────────────
                Text(
                    text = "Live Interactive Preview",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // BACKGROUND BRUSH LOGIC
                val stripBg = when(selectedColor) {
                    -2 -> Brush.horizontalGradient(listOf(Color(0xFFFF9933), Color.White, Color(0xFF138808))) // 🇮🇳
                    -3 -> Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta)) // 🌈
                    else -> {
                        val finalCol = if (selectedColor == android.graphics.Color.WHITE || selectedColor == 0) {
                            if (isSystemDark) Color.White else Color(0xFFFFA500)
                        } else {
                            Color(selectedColor)
                        }
                        Brush.linearGradient(listOf(finalCol, finalCol))
                    }
                }

                val previewTxtCol = if (selectedColor == -2) Color.Black else if (isColorLight(selectedColor)) Color(0xFF1a1a1a) else Color.White
                val stripHeight = 44.dp
                val photoSize = 66.dp
                val photoYOffset = -(stripHeight - photoSize * 0.35f)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(stripHeight + 35.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(0.5.dp, Color.Gray.copy(0.2f), RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    // STRIP BACKGROUND
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(stripHeight)
                            .align(Alignment.BottomCenter)
                            .background(stripBg)
                            .border(1.2.dp, Color.Black, RectangleShape)
                    )

                    // NAME TEXT
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                start = if (isLeftDesign) photoSize + 15.dp else 15.dp,
                                end   = if (isLeftDesign) 15.dp else photoSize + 15.dp
                            )
                            .height(stripHeight)
                            .align(Alignment.BottomCenter),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name.ifBlank { googlePhotoUrl?.let { FirebaseAuth.getInstance().currentUser?.displayName } ?: "StatusSeva User" },
                            color = previewTxtCol,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }

                    // LOGO
                    val align = if (isLeftDesign) Alignment.BottomStart else Alignment.BottomEnd
                    val paddingSide = if (isLeftDesign) Modifier.padding(start = 12.dp) else Modifier.padding(end = 12.dp)
                    val activeDisplayPhoto = photoUri ?: googlePhotoUrl

                    Box(
                        modifier = Modifier
                            .align(align)
                            .then(paddingSide)
                            .offset(y = photoYOffset)
                            .size(photoSize)
                            .clip(CircleShape)
                            .then(
                                if (isOutlineOn) {
                                    Modifier.border(
                                        width = 3.5.dp,
                                        brush = Brush.sweepGradient(listOf(Color.Red, Color.Magenta, Color.Blue, Color.Cyan, Color.Green, Color.Yellow, Color.Red)),
                                        shape = CircleShape
                                    )
                                } else {
                                    val bCol = if (selectedColor == android.graphics.Color.WHITE) Color.LightGray else Color.White
                                    Modifier.border(2.dp, bCol, CircleShape)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (activeDisplayPhoto != null) {
                            // 🌟 INSTANT LOAD BUG FIX: Memory Cache Busted using refresh trigger
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(activeDisplayPhoto)
                                    .memoryCacheKey("${activeDisplayPhoto}_$imageRefreshTrigger")
                                    .diskCacheKey("${activeDisplayPhoto}_$imageRefreshTrigger")
                                    .crossfade(true)
                                    .build(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize().background(Color(0xFF6C63FF)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = name.trim().take(1).uppercase().ifBlank { "?" },
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // ── SECTION 5: NAME INPUT FIELD ──────────────────
                Text(
                    text = "Display Name",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("Enter your name...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    leadingIcon = { Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                // ── SECTION 6: PHOTO SELECTION ───────────────────
                Text(
                    text = "Branding Photo",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                if (photoUri == null && googlePhotoUrl != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text("Abhi Google account ki photo use ho rahi hai", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val activeDisplayPhoto2 = photoUri ?: googlePhotoUrl

                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            .clickable { photoLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (activeDisplayPhoto2 != null) {
                            // 🌟 INSTANT LOAD BUG FIX
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(activeDisplayPhoto2)
                                    .memoryCacheKey("${activeDisplayPhoto2}_$imageRefreshTrigger")
                                    .diskCacheKey("${activeDisplayPhoto2}_$imageRefreshTrigger")
                                    .crossfade(true)
                                    .build(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { photoLauncher.launch("image/*") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                        ) {
                            Icon(Icons.Default.Image, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (photoUri != null) "Change Photo" else "Upload Photo", fontWeight = FontWeight.Bold)
                        }

                        if (photoUri != null) {
                            TextButton(
                                onClick = {
                                    photoUri = null
                                    branding.setPhotoUri(context, null)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Remove (Use Google Photo)", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // ── SECTION 7: COLOR PALETTE ──────────────────────
                Text(
                    text = "Select Strip Color Theme",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                ) {
                    items(UserBrandingManager.presetColors) { colorInt ->
                        val isSelected = selectedColor == colorInt
                        val isWhiteCol = colorInt == android.graphics.Color.WHITE
                        val lightColor = remember(colorInt) { isColorLight(colorInt) }

                        // OUTER CIRCLE (SELECTION INDICATOR)
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .then(
                                    when(colorInt) {
                                        -2 -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFFFF9933), Color.White, Color(0xFF138808))))
                                        -3 -> Modifier.background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta, Color.Red)))
                                        else -> Modifier.background(Color(colorInt))
                                    }
                                )
                                .border(
                                    width = if (isSelected) 3.5.dp else 1.5.dp,
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else if (isWhiteCol) {
                                        Color.Gray // 🌟 Changed to Gray so it's clearly visible
                                    } else {
                                        Color.Transparent
                                    },
                                    shape = CircleShape
                                )
                                .clickable {
                                    selectedColor = colorInt
                                    branding.setColor(context, colorInt)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (colorInt == -2) {
                                Text("🇮🇳", fontSize = 12.sp)
                            }

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = if (lightColor) Color.Black else Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }

                // AUTO-SAVE INFO TEXT
                Text(
                    text = "Changes are saved automatically when you go back.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    textAlign = TextAlign.Center
                )
            }

            // Bottom Spacing
            Spacer(Modifier.height(60.dp))
        }
    }
}