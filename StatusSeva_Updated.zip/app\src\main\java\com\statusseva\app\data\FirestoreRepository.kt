package com.statusseva.app.data

import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.statusseva.app.model.Post
import java.util.Calendar

object FirestoreRepository {

    private val db = FirebaseFirestore.getInstance()

    fun fetchPosts(
        language : String = "",
        onResult : (List<Post>) -> Unit
    ) {
        var query = db.collection("posts")
            .orderBy("position", Query.Direction.ASCENDING)
            .orderBy("createdAt", Query.Direction.DESCENDING)

        if (language.isNotBlank()) {
            query = query.whereEqualTo("language", language) as com.google.firebase.firestore.Query
        }

        query.get()
            .addOnSuccessListener { result ->
                val now = System.currentTimeMillis()

                val posts = result.mapNotNull { document ->
                    val status      = document.getString("status")      ?: "Published"
                    val scheduledAt = document.getLong("scheduledAt")   ?: 0L

                    // Scheduled / Draft filter
                    if (status.equals("Scheduled", ignoreCase = true)) return@mapNotNull null
                    if (scheduledAt > 0L && scheduledAt > now)          return@mapNotNull null
                    if (status.equals("Draft", ignoreCase = true))      return@mapNotNull null

                    Post(
                        id               = document.id,
                        title            = document.getString("title")            ?: "",
                        description      = document.getString("description")      ?: "",
                        category         = document.getString("category")         ?: "",
                        imageUrl         = document.getString("imageUrl")         ?: "",
                        videoUrl         = document.getString("videoUrl")         ?: "",
                        type             = document.getString("type")             ?: "image",
                        createdAt        = document.getLong("createdAt")          ?: 0L,
                        isFeatured       = document.getBoolean("isFeatured")      ?: false,
                        language         = document.getString("language")         ?: "",
                        position         = document.getLong("position")?.toInt()  ?: Int.MAX_VALUE,
                        aspectRatio      = document.getDouble("aspectRatio"),
                        uploadedBy       = document.getString("uploadedBy").takeIf { !it.isNullOrBlank() } ?: document.getString("userId") ?: "",
                        originalImageUrl = document.getString("originalImageUrl") ?: ""
                    ).takeIf { 
                        it.uploadedBy.isNullOrBlank() || it.uploadedBy !in BlockedUserManager.blockedUids
                    }
                }

                // 🌟 AUTOMATION LOGIC: Check Current Time
                val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val isMorning   = currentHour in 4..10   // 4:00 AM to 10:59 AM
                val isNight     = currentHour in 20..23 || currentHour == 0 // 8:00 PM to 12:59 AM

                // 🌟 RE-SORT IN MEMORY BASED ON TIME
                val finalPosts = when {
                    isMorning -> {
                        posts.sortedWith(
                            compareByDescending<Post> { it.category == "सुप्रभात" } // Good Morning posts sabse upar
                                .thenBy { it.position }
                                .thenByDescending { it.createdAt }
                        )
                    }
                    isNight -> {
                        posts.sortedWith(
                            compareByDescending<Post> { it.category == "शुभ रात्रि" } // Good Night posts sabse upar
                                .thenBy { it.position }
                                .thenByDescending { it.createdAt }
                        )
                    }
                    else -> posts // Baki time normal order mein chalega
                }

                onResult(finalPosts)
            }
            .addOnFailureListener { e ->
                Log.e("FirestoreRepo", "fetchPosts failed: ${e.message}")
                onResult(emptyList())
            }
    }

    fun fetchPosts(onResult: (List<Post>) -> Unit) {
        fetchPosts(language = "", onResult = onResult)
    }

    fun incrementDownloadCount(postId: String, userId: String?) {
        try {
            if (postId.isNotBlank()) {
                db.collection("posts").document(postId)
                    .update("downloads", FieldValue.increment(1))
                    .addOnFailureListener { Log.e("Analytics", "Post download track failed: ${it.message}") }
            }
            if (!userId.isNullOrBlank()) {
                db.collection("users").document(userId)
                    .update("downloads", FieldValue.increment(1))
                    .addOnFailureListener { Log.e("Analytics", "User download track failed: ${it.message}") }
            }
        } catch (e: Exception) {
            Log.e("Analytics", "Error tracking download: ${e.message}")
        }
    }

    fun incrementShareCount(postId: String) {
        try {
            if (postId.isNotBlank()) {
                db.collection("posts").document(postId)
                    .update("shares", FieldValue.increment(1))
                    .addOnFailureListener { Log.e("Analytics", "Share track failed: ${it.message}") }
            }
        } catch (e: Exception) {
            Log.e("Analytics", "Error tracking share: ${e.message}")
        }
    }
}