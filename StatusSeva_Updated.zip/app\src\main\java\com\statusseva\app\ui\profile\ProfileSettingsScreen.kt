package com.statusseva.app.ui.profile

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.statusseva.app.R
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.FirestoreRepository
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.ThemeManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    onNavigate      : (String) -> Unit = {},
    onBack          : () -> Unit = {},
    appLang         : String = "hi",
    onAppLangChange : (String) -> Unit = {},
    onLogout        : () -> Unit = {}
) {
    fun str(key: String) = AppStrings.get(key, appLang)
    fun strCustom(hi: String, mr: String, en: String) = when (appLang) {
        "hi" -> hi; "mr" -> mr; else -> en
    }

    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val googleUser     = GoogleAuthHelper.currentUser
    val googleName     = googleUser?.displayName ?: ""
    val googleEmail    = googleUser?.email       ?: ""
    val googlePhotoUrl = googleUser?.photoUrl

    var isDark             by remember { mutableStateOf(ThemeManager.isDark) }
    var isAuto             by remember { mutableStateOf(ThemeManager.isAuto) }
    var currentContentLang by remember { mutableStateOf(LanguagePreference.getContentLanguage(context)) }
    var currentAppLang     by remember { mutableStateOf(appLang) }

    var showThemeDialog    by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showAppLangDialog  by remember { mutableStateOf(false) }
    var showHelpDialog     by remember { mutableStateOf(false) }
    var showAboutDialog    by remember { mutableStateOf(false) }
    var showLogoutDialog   by remember { mutableStateOf(false) }
    var showDeleteDialog   by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        Text(
                            text       = "Settings",
                            fontWeight = FontWeight.Bold,
                            style      = MaterialTheme.typography.titleLarge
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { onBack() }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color     = MaterialTheme.colorScheme.outlineVariant
                )
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = padding.calculateTopPadding())
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp) // 🌟 REDUCED SPACE
        ) {

            // ── User Profile Card ─────────────────────────────
            Card(
                modifier  = Modifier.fillMaxWidth(),
                shape     = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(0.dp),
                colors    = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier              = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AsyncImage(
                        model              = googlePhotoUrl,
                        contentDescription = null,
                        modifier           = Modifier.size(52.dp).clip(CircleShape),
                        contentScale       = ContentScale.Crop,
                        error              = painterResource(R.drawable.logo),
                        placeholder        = painterResource(R.drawable.logo)
                    )
                    Column {
                        Text(
                            text       = googleName.ifBlank { "User" },
                            style      = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text  = googleEmail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // ── ALL MAIN SETTINGS IN ONE CARD (No Section Titles) ─────────────────
            SettingsCard {
                Column {
                    SettingsRow(
                        icon    = if (isAuto) Icons.Default.BrightnessAuto else if (isDark) Icons.Default.DarkMode else Icons.Default.LightMode,
                        title   = "Theme",
                        value   = if (isAuto) "System Default" else if (isDark) "Dark" else "Light",
                        onClick = { showThemeDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.Translate,
                        title   = str("content_language").ifBlank { "Content Language" },
                        value   = when (currentContentLang) {
                            "hi" -> str("lang_hindi")
                            "mr" -> str("lang_marathi")
                            else -> ""
                        },
                        onClick = { showLanguageDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.Language,
                        title   = str("app_language").ifBlank { "App Language" },
                        value   = when (currentAppLang) {
                            "hi" -> str("lang_hindi")
                            "mr" -> str("lang_marathi")
                            "en" -> str("lang_english")
                            else -> ""
                        },
                        onClick = { showAppLangDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.Notifications,
                        title   = str("notifications").ifBlank { "Notifications" },
                        onClick = { onNavigate("notifications") }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.Feedback,
                        title   = str("feedback").ifBlank { "Feedback" },
                        onClick = { onNavigate("feedback") }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    
                    SettingsRow(
                        icon    = Icons.Default.Block,
                        title   = "Blocked Users",
                        value   = "Advanced",
                        onClick = { onNavigate("blocked_users") }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.HeadsetMic,
                        title   = str("help_support").ifBlank { "Help & Support" },
                        onClick = { showHelpDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsRow(
                        icon    = Icons.Default.Info,
                        title   = stringResource(R.string.about),
                        onClick = { onNavigate("about") }
                    )
                }
            }

            // ── LOGOUT (Separate Card for visibility) ─────────────────────────
            SettingsCard {
                SettingsRow(
                    icon       = Icons.Default.Logout,
                    title      = str("logout").ifBlank { "Logout" },
                    titleColor = MaterialTheme.colorScheme.error,
                    iconColor  = MaterialTheme.colorScheme.error,
                    showArrow  = false,
                    onClick    = { showLogoutDialog = true }
                )
            }

            Spacer(Modifier.height(8.dp)) // A little breathing room before footer

            // ── LEGAL LINKS & DELETE ACCOUNT (Bottom Section) ─
            Column(
                modifier              = Modifier.fillMaxWidth(),
                horizontalAlignment   = Alignment.CenterHorizontally,
                verticalArrangement   = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text  = strCustom("कानूनी जानकारी", "कायदेशीर माहिती", "Legal Information"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick      = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://statusseva.in/privacy.html"))) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text  = strCustom("गोपनीयता नीति", "गोपनीयता धोरण", "Privacy Policy"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text  = "•",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    TextButton(
                        onClick        = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://statusseva.in/privacy.html"))) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text  = strCustom("नियम व शर्तें", "अटी व शर्ती", "Terms & Conditions"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text  = "•",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    TextButton(
                        onClick        = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://statusseva.in/privacy.html"))) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text  = strCustom("रिफंड नीति", "परतावा धोरण", "Refund Policy"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // 🌟 CHHOTA DELETE ACCOUNT BUTTON
                TextButton(
                    onClick        = { showDeleteDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text  = "Delete Account & Data",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                Text(
                    text      = "© 2026 StatusSeva",
                    style     = MaterialTheme.typography.labelSmall,
                    color     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(60.dp))
        }
    }

    // ══════════════════════════════════════════════════════════
    // DIALOGS
    // ══════════════════════════════════════════════════════════

    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            confirmButton    = {},
            title = { Text("Theme Select karein", fontWeight = FontWeight.Bold) },
            text  = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val themeOptions = listOf(
                        Triple("system", "System Default", Icons.Default.SettingsSuggest),
                        Triple("light", "Light", Icons.Default.LightMode),
                        Triple("dark", "Dark", Icons.Default.DarkMode)
                    )

                    themeOptions.forEach { (mode, label, icon) ->
                        val isSelected = when(mode) {
                            "system" -> isAuto
                            "light" -> !isAuto && !isDark
                            "dark" -> !isAuto && isDark
                            else -> false
                        }

                        Surface(
                            onClick  = {
                                ThemeManager.setThemeMode(context, mode)
                                isAuto = ThemeManager.isAuto
                                isDark = ThemeManager.isDark
                                showThemeDialog = false
                            },
                            shape    = RoundedCornerShape(12.dp),
                            color    = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier              = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment     = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f))
                                if (isSelected) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        )
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            confirmButton    = { TextButton(onClick = { showLanguageDialog = false }) { Text(str("save")) } },
            title            = { Text(str("content_language"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("hi" to str("lang_hindi"), "mr" to str("lang_marathi")).forEach { (code, label) ->
                        Surface(
                            onClick  = {
                                LanguagePreference.setContentLanguage(context, code)
                                currentContentLang = code
                                showLanguageDialog = false
                                LanguagePreference.updateFCMTopics(code)
                                FirestoreRepository.fetchPosts { onBack() }
                            },
                            shape    = RoundedCornerShape(12.dp),
                            color    = if (currentContentLang == code) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier          = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f))
                                if (currentContentLang == code) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        )
    }

    if (showAppLangDialog) {
        AlertDialog(
            onDismissRequest = { showAppLangDialog = false },
            confirmButton    = { TextButton(onClick = { showAppLangDialog = false }) { Text(str("save")) } },
            title            = { Text(str("app_language"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "hi" to str("lang_hindi"),
                        "mr" to str("lang_marathi"),
                        "en" to str("lang_english")
                    ).forEach { (code, label) ->
                        Surface(
                            onClick  = {
                                LanguagePreference.setAppLanguage(context, code)
                                currentAppLang = code
                                onAppLangChange(code)
                                showAppLangDialog = false
                            },
                            shape    = RoundedCornerShape(12.dp),
                            color    = if (currentAppLang == code) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier          = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f))
                                if (currentAppLang == code) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Text(
                        text  = when (currentAppLang) {
                            "hi" -> "पूरे ऐप की भाषा बदल जाएगी"
                            "mr" -> "संपूर्ण ॲपची भाषा बदलेल"
                            else -> "App UI language will change"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        )
    }

    if (showHelpDialog) {
        HelpSupportDialog(
            appLang   = appLang,
            userEmail = googleEmail,
            userName  = googleName,
            onDismiss = { showHelpDialog = false }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            confirmButton    = { TextButton(onClick = { showAboutDialog = false }) { Text(stringResource(R.string.ok)) } },
            title            = { Text(stringResource(R.string.app_name)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Founders: Gothwal Studio")
                    Text("Version 1.0")
                }
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title            = { Text(str("logout") + "?") },
            text             = { Text("Are you sure you want to logout?") },
            confirmButton    = {
                TextButton(onClick = {
                    showLogoutDialog = false
                    GoogleAuthHelper.signOut()
                    onLogout()
                }) {
                    Text(str("logout"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(str("cancel"))
                }
            }
        )
    }

    // 🌟 NEW: DELETE ACCOUNT DIALOG
    if (showDeleteDialog) {
        var isDeleting by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isDeleting) showDeleteDialog = false },
            title = { Text("Delete Account", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = {
                Text(
                    text = "This action is permanent and cannot be undone. Your profile, settings, and personal data will be deleted from our servers.\n\nAre you sure you want to proceed?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uid = GoogleAuthHelper.currentUser?.uid
                        if (uid != null) {
                            isDeleting = true
                            coroutineScope.launch {
                                try {
                                    // 🌟 FIX: Client se sirf Auth delete hoga.
                                    // Firestore, Razorpay aur baaki sab kachra index.js (Cloud Function) piche se khud saaf karega.
                                    FirebaseAuth.getInstance().currentUser?.delete()?.await()

                                    Toast.makeText(context, "Account permanently deleted.", Toast.LENGTH_SHORT).show()
                                    showDeleteDialog = false
                                    isDeleting = false
                                    GoogleAuthHelper.signOut()
                                    onLogout()
                                } catch (e: Exception) {
                                    isDeleting = false
                                    showDeleteDialog = false

                                    // 🌟 SMART UX: Agar lamba time ho gaya hai aur Firebase error deta hai,
                                    // toh user ko auto-logout karke bata do ki wapas login karna hai.
                                    Toast.makeText(
                                        context,
                                        "Security Check: Account delete karne ke liye ek baar wapas Login karein.",
                                        Toast.LENGTH_LONG
                                    ).show()

                                    GoogleAuthHelper.signOut()
                                    onLogout()
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onError, strokeWidth = 2.dp)
                    } else {
                        Text("Delete Permanently", color = MaterialTheme.colorScheme.onError)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }, enabled = !isDeleting) {
                    Text(str("cancel"))
                }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────
//  HELPER COMPOSABLES
// ─────────────────────────────────────────────────────────────

// Removed SettingsSectionTitle as it's no longer needed

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(0.dp),
        colors    = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) { content() }
}

@Composable
private fun SettingsRow(
    icon       : ImageVector,
    title      : String,
    value      : String     = "",
    titleColor : Color      = Color.Unspecified,
    iconColor  : Color      = Color.Unspecified,
    showArrow  : Boolean    = true,
    onClick    : () -> Unit
) {
    Surface(
        onClick  = onClick,
        shape    = RoundedCornerShape(14.dp),
        color    = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier              = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = null,
                tint               = if (iconColor == Color.Unspecified)
                    MaterialTheme.colorScheme.onSurfaceVariant else iconColor
            )
            Text(
                text     = title,
                style    = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
                color    = titleColor
            )
            if (value.isNotBlank()) {
                Text(
                    text  = value,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (showArrow) {
                Icon(
                    imageVector        = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        }
    }
}