package com.statusseva.app.ui.update

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ─────────────────────────────────────────────────────────────
//  ForceUpdateScreen
//  - Full screen, back button se band nahi hogi
//  - Redirect to statusseva.in for update
// ─────────────────────────────────────────────────────────────

@Composable
fun ForceUpdateScreen(
    apkUrl        : String,    // Can be used as fallback URL if starting with http
    latestVersion : String,    // e.g. "2.0.0"
    updateMessage : String = "Naya version available hai! Behtar experience ke liye update karo."
) {
    val context = LocalContext.current

    // Pulse animation for logo
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue    = 1f,
        targetValue     = 1.08f,
        animationSpec   = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label           = "scale"
    )

    // Full screen — gradient background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D0D0F), Color(0xFF1A1208), Color(0xFF0D0D0F))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            // ── App Logo ──────────────────────────────────────
            Box(
                modifier        = Modifier
                    .size(90.dp)
                    .scale(scale)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFF0A500), Color(0xFFFF6B35))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("🪔", fontSize = 42.sp)
            }

            Spacer(Modifier.height(28.dp))

            // ── Title ─────────────────────────────────────────
            Text(
                text       = "Update Required",
                fontSize   = 26.sp,
                fontWeight = FontWeight.Bold,
                color      = Color.White,
                textAlign  = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            // ── Version badge ─────────────────────────────────
            if (latestVersion.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF0A500).copy(alpha = 0.15f)
                ) {
                    Text(
                        text     = "Version $latestVersion available",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                        fontSize = 13.sp,
                        color    = Color(0xFFF0A500),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // ── Message ───────────────────────────────────────
            Text(
                text      = updateMessage,
                fontSize  = 15.sp,
                color     = Color(0xFF9B9693),
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(Modifier.height(36.dp))

            // ── Update Button ─────────────────────────────────
            Button(
                onClick  = {
                    val url = if (apkUrl.startsWith("http")) apkUrl else "https://statusseva.in"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape  = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(listOf(Color(0xFFF0A500), Color(0xFFFF6B35))),
                            shape = RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text       = "🚀 Update Now",
                        color      = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 16.sp
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            // ── Footer note ───────────────────────────────────
            Text(
                text      = "App use karne ke liye update zaroori hai",
                fontSize  = 12.sp,
                color     = Color(0xFF5C5956),
                textAlign = TextAlign.Center
            )
        }
    }
}