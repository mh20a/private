package com.statusseva.app.data

import android.widget.Toast

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.FileDataSource
import androidx.media3.datasource.cache.CacheDataSink
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.statusseva.app.ui.home.getVideoCache
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object GallerySaver {

    private fun getBrandingClipFile(context: Context): File {
        val file = File(context.cacheDir, "branding_clip.mp4")
        if (!file.exists()) {
            val resId = context.resources.getIdentifier(
                "branding_clip", "raw", context.packageName
            )
            context.resources.openRawResource(resId).use { input ->
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            }
        }
        return file
    }

    @OptIn(UnstableApi::class)
    private suspend fun getVideoFileFromCacheOrDownload(context: Context, videoUrl: String, destFile: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val cache = getVideoCache(context)
                val upstreamFactory = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)

                val cacheDataSource = CacheDataSource(
                    cache,
                    upstreamFactory.createDataSource(),
                    FileDataSource(),
                    CacheDataSink(cache, CacheDataSink.DEFAULT_FRAGMENT_SIZE),
                    CacheDataSource.FLAG_BLOCK_ON_CACHE or CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR,
                    null
                )

                val dataSpec = DataSpec(Uri.parse(videoUrl))
                cacheDataSource.open(dataSpec)

                FileOutputStream(destFile).use { out ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val bytesRead = cacheDataSource.read(buffer, 0, buffer.size)
                        if (bytesRead == C.RESULT_END_OF_INPUT) {
                            break
                        }
                        out.write(buffer, 0, bytesRead)
                    }
                }
                cacheDataSource.close()
                return@withContext true
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext downloadToFileSync(videoUrl, destFile)
            }
        }
    }

    private fun downloadToFileSync(videoUrl: String, destFile: File): Boolean {
        return try {
            var connection = URL(videoUrl).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connect()
            val code = connection.responseCode
            if (code == HttpURLConnection.HTTP_MOVED_TEMP ||
                code == HttpURLConnection.HTTP_MOVED_PERM || code == 307) {
                val newUrl = connection.getHeaderField("Location")
                connection.disconnect()
                connection = URL(newUrl).openConnection() as HttpURLConnection
                connection.connect()
            }
            FileOutputStream(destFile).use { out ->
                connection.inputStream.use { it.copyTo(out) }
            }
            connection.disconnect()
            true
        } catch (_: Exception) { false }
    }

    @OptIn(UnstableApi::class)
    private suspend fun appendBrandingClip(
        context      : Context,
        originalFile : File,
        outputFile   : File
    ): Boolean = suspendCancellableCoroutine { cont ->
        try {
            val brandingFile = getBrandingClipFile(context)

            val transformer = Transformer.Builder(context).build()
            val item1 = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(originalFile))).build()
            val item2 = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(brandingFile))).build()

            val sequence = EditedMediaItemSequence(item1, item2)
            val composition = Composition.Builder(listOf(sequence)).build()

            transformer.addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(true)
                }
                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    if (cont.isActive) cont.resume(false)
                }
            })
            transformer.start(composition, outputFile.absolutePath)
        } catch (_: Exception) {
            if (cont.isActive) cont.resume(false)
        }
    }

    suspend fun saveImage(context: Context, imageUrl: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // 🌟 Notify start
                withContext(Dispatchers.Main) { 
                    // Toast for starting? Maybe too much, but let's at least ensure we don't return false silently.
                }

                // 🌟 PREMIUM: Direct download — bypass Coil for original quality
                val original = downloadOriginalBitmap(context, imageUrl) ?: return@withContext false

                // 🌟 UPSCALING FOR TALL/SMALL IMAGES
                val workingBitmap = if (original.width < 1080) {
                    val scale = 1080f / original.width
                    val newH = (original.height * scale).toInt()
                    val scaled = Bitmap.createScaledBitmap(original, 1080, newH, true)
                    if (scaled !== original) original.recycle()
                    scaled
                } else {
                    original
                }

                val watermarked = WatermarkHelper.addWatermark(context, workingBitmap)
                val finalBitmap = BrandingStripHelper.applyBrandingStrip(context, watermarked)
                if (finalBitmap !== watermarked) watermarked.recycle()
                if (workingBitmap !== finalBitmap && workingBitmap !== watermarked) workingBitmap.recycle()

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "StatusSeva_${System.currentTimeMillis()}.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/StatusSeva")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                
                val uri = context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                ) ?: return@withContext false

                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                } ?: return@withContext false

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                } else {
                    // Manual refresh for legacy android
                    val path = getFilePathFromUri(context, uri)
                    if (path != null) {
                        android.media.MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
                    }
                }

                finalBitmap.recycle()
                withContext(Dispatchers.Main) { Toast.makeText(context, "Image saved successfully", Toast.LENGTH_SHORT).show() }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) { Toast.makeText(context, "Failed to save image", Toast.LENGTH_SHORT).show() }
                false
            }
        }
    }

    suspend fun saveVideo(context: Context, videoUrl: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val originalFile = File(context.cacheDir, "original_video.mp4")
                val downloaded = getVideoFileFromCacheOrDownload(context, videoUrl, originalFile)
                if (!downloaded) return@withContext false

                val mergedFile = File(context.cacheDir, "merged_video.mp4")
                appendBrandingClip(context, originalFile, mergedFile)
                val finalFile = if (mergedFile.exists() && mergedFile.length() > 0)
                    mergedFile else originalFile

                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "StatusSeva_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/StatusSeva")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                
                var uri = context.contentResolver.insert(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
                )
                
                if (uri == null) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        val saved = saveVideoToLegacyPath(context, finalFile)
                        originalFile.delete()
                        mergedFile.delete()
                        if (saved) withContext(Dispatchers.Main) { Toast.makeText(context, "Video saved successfully", Toast.LENGTH_SHORT).show() }
                        return@withContext saved
                    }
                    return@withContext false
                }

                context.contentResolver.openOutputStream(uri)?.use { out ->
                    finalFile.inputStream().use { it.copyTo(out) }
                } ?: return@withContext false

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                } else {
                    val path = getFilePathFromUri(context, uri)
                    if (path != null) {
                        android.media.MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
                    }
                }

                originalFile.delete()
                mergedFile.delete()
                withContext(Dispatchers.Main) { Toast.makeText(context, "Video saved successfully", Toast.LENGTH_SHORT).show() }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) { Toast.makeText(context, "Failed to save video", Toast.LENGTH_SHORT).show() }
                false
            }
        }
    }

    private fun saveVideoToLegacyPath(context: Context, sourceFile: File): Boolean {
        return try {
            val dcim = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DCIM)
            val statusSevaDir = File(dcim, "StatusSeva")
            if (!statusSevaDir.exists()) statusSevaDir.mkdirs()
            
            val destFile = File(statusSevaDir, "StatusSeva_${System.currentTimeMillis()}.mp4")
            sourceFile.inputStream().use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun getFilePathFromUri(context: Context, uri: Uri): String? {
        val projection = arrayOf(MediaStore.MediaColumns.DATA)
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                return cursor.getString(index)
            }
        }
        return null
    }

    suspend fun getWatermarkedBitmap(context: Context, imageUrl: String): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                // 🌟 PREMIUM: Direct download — bypass Coil for original quality
                val original = downloadOriginalBitmap(context, imageUrl) ?: return@withContext null

                // 🌟 UPSCALING FOR TALL/SMALL IMAGES
                val workingBitmap = if (original.width < 1080) {
                    val scale = 1080f / original.width
                    val newH = (original.height * scale).toInt()
                    val scaled = Bitmap.createScaledBitmap(original, 1080, newH, true)
                    if (scaled !== original) original.recycle()
                    scaled
                } else {
                    original
                }

                val watermarked = WatermarkHelper.addWatermark(context, workingBitmap)
                val finalBitmap = BrandingStripHelper.applyBrandingStrip(context, watermarked)
                if (finalBitmap !== watermarked) watermarked.recycle()
                if (workingBitmap !== finalBitmap && workingBitmap !== watermarked) workingBitmap.recycle()

                finalBitmap
            } catch (_: Exception) { null }
        }

    /**
     * 🌟 PREMIUM QUALITY: Download original image at full resolution.
     * Uses HqImageCache for disk caching — bypasses Coil completely.
     * Returns a full-resolution ARGB_8888 Bitmap with zero quality loss.
     */
    private suspend fun downloadOriginalBitmap(context: Context, imageUrl: String): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                // Try HQ cache first, download if not cached
                val cachedFile = HqImageCache.downloadAndCache(context, imageUrl)
                    ?: return@withContext null

                // Decode at FULL resolution — no downsampling
                val options = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = false
                    inSampleSize = 1           // No downsampling
                    inScaled = false           // No density scaling
                    inPreferredConfig = Bitmap.Config.ARGB_8888  // Highest quality config
                }

                android.graphics.BitmapFactory.decodeFile(cachedFile.absolutePath, options)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun downloadVideoToCache(context: Context, videoUrl: String): File? =
        withContext(Dispatchers.IO) {
            try {
                val originalFile = File(context.cacheDir, "wa_original.mp4")

                val downloaded = getVideoFileFromCacheOrDownload(context, videoUrl, originalFile)
                if (!downloaded) return@withContext null

                val mergedFile = File(context.cacheDir, "wa_video_share.mp4")
                val success = appendBrandingClip(context, originalFile, mergedFile)

                if (success && mergedFile.exists() && mergedFile.length() > 0) {
                    originalFile.delete()
                    return@withContext mergedFile
                } else {
                    mergedFile.delete()
                    return@withContext originalFile
                }
            } catch (_: Exception) { null }
        }
}