package com.statusseva.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.messaging.FirebaseMessaging
import kotlin.math.roundToInt
import com.statusseva.app.data.AppDownloadManager
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.FirestoreRepository
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.data.LanguagePreference
import com.statusseva.app.data.ProfileManager
import com.statusseva.app.data.SubscriptionManager
import com.statusseva.app.data.ThemeManager
import com.statusseva.app.data.UserBrandingManager
import com.statusseva.app.notifications.NotificationScheduler
import com.statusseva.app.ui.auth.AuthScreen
import com.statusseva.app.ui.auth.BlockedScreen
import com.statusseva.app.ui.auth.PhoneSetupScreen
import com.statusseva.app.ui.branding.BrandingSetupScreen
import com.statusseva.app.ui.explore.ExploreScreen
import com.statusseva.app.ui.feedback.FeedbackScreen
import com.statusseva.app.ui.home.HomeScreen
import com.statusseva.app.ui.notification.NotificationScreen

import com.statusseva.app.ui.profile.ProfileScreen
import com.statusseva.app.ui.profile.ProfileSettingsScreen
import com.statusseva.app.ui.subscription.SubscriptionScreen
import com.statusseva.app.ui.theme.StatusSevaTheme
import com.google.android.gms.ads.MobileAds
import com.statusseva.app.data.RewardedAdManager
import com.statusseva.app.ui.update.ForceUpdateScreen
import com.statusseva.app.ui.upload.UploadScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import com.statusseva.app.ui.profile.AboutScreen
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private val firestore = FirebaseFirestore.getInstance()

    private fun isAppInDebugMode(): Boolean {
        return (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        if (isAppInDebugMode() && !com.statusseva.app.BuildConfig.DEBUG) {
            android.widget.Toast.makeText(this, "Security Violation Detected! App will close.", android.widget.Toast.LENGTH_LONG).show()
            finish()
            return
        }

        window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_SECURE,
            android.view.WindowManager.LayoutParams.FLAG_SECURE
        )

        firebaseAnalytics = FirebaseAnalytics.getInstance(this)

        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder()
                        .setSizeBytes(50L * 1024L * 1024L)
                        .build()
                )
                .build()
            firestore.firestoreSettings = settings
        } catch (_: Exception) {}

        FirebaseMessaging.getInstance()
            .subscribeToTopic("all")
            .addOnCompleteListener { task ->
                if (task.isSuccessful) Log.d("FCM", "Subscribed: all")
                else Log.w("FCM", "Failed to subscribe: all")
            }

        val savedLang = LanguagePreference.getContentLanguage(this)
        LanguagePreference.updateFCMTopics(savedLang)

        // 🌟 AUTOMATION: Ensure the correct topic is subscribed on startup based on saved language
        FirebaseMessaging.getInstance().subscribeToTopic("topic_$savedLang")

        enableEdgeToEdge()

        AppDownloadManager.init(this)
        ThemeManager.init(this)
        ProfileManager.init(this)
        UserBrandingManager.init(this)
        com.statusseva.app.data.BlockedUserManager.init()
        
        // Initialize AdMob and preload Rewarded Ad
        MobileAds.initialize(this) {}
        RewardedAdManager.loadAd(this)

        NotificationScheduler.scheduleDailyNotification(this)

        FirestoreRepository.fetchPosts {
            Log.d("FIRESTORE_TEST", "Posts loaded")
        }

        handleNotificationIntent(intent)

        setContent {
            StatusSevaTheme {
                StatusSevaApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        UserBrandingManager.onAppForeground()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("fromNotification", false) == true) {
            val postId   = intent.getStringExtra("postId")   ?: ""
            val category = intent.getStringExtra("category") ?: ""
            pendingPostId   = postId
            pendingCategory = category
            Log.d("FCM_REDIRECT", "postId=$postId category=$category")
        }
    }

    companion object {
        var pendingPostId   : String = ""
        var pendingCategory : String = ""
    }
}

// 🌟 NETWORK MONITOR LOGIC
@Composable
fun rememberNetworkConnectivityState(): State<Boolean> {
    val context = LocalContext.current
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    val isConnected = remember {
        mutableStateOf(
            connectivityManager.activeNetwork?.let {
                connectivityManager.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } ?: false
        )
    }

    DisposableEffect(connectivityManager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { isConnected.value = true }
            override fun onLost(network: Network) { isConnected.value = false }
        }
        val request = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        connectivityManager.registerNetworkCallback(request, callback)

        onDispose { connectivityManager.unregisterNetworkCallback(callback) }
    }
    return isConnected
}

@Composable
fun NoInternetOverlay(appLang: String) {
    val title = AppStrings.get("no_internet_title", appLang)
    val desc  = AppStrings.get("no_internet_desc", appLang)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
            .clickable(enabled = false) {}
            .zIndex(100f),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.WifiOff,
                contentDescription = "No Internet",
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(20.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

object SharedScrollState {
    var isScrollingUp by mutableStateOf(true)
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun StatusSevaApp() {

    val context   = LocalContext.current
    val firestore = FirebaseFirestore.getInstance()

    val isConnected by rememberNetworkConnectivityState()

    var isLoggedIn      by remember { mutableStateOf(GoogleAuthHelper.isLoggedIn) }
    var showLangPicker  by remember { mutableStateOf(false) }
    var userBlocked     by remember { mutableStateOf(false) }
    var maintenanceMode by remember { mutableStateOf(false) }
    var maintenanceMsg  by remember { mutableStateOf("App under maintenance") }
    var forceUpdate     by remember { mutableStateOf(false) }
    var apkUrl          by remember { mutableStateOf("") }
    var latestVersion   by remember { mutableStateOf("") }
    var updateMessage   by remember { mutableStateOf("Naya version available hai!") }
    var paywallEnabled  by remember { mutableStateOf(false) }
    var userPlan        by remember { mutableStateOf("free") }
    var paywallLoading  by remember { mutableStateOf(true) }

    var isPhoneCheckLoading by remember { mutableStateOf(isLoggedIn) }
    var showPhoneSetup      by remember { mutableStateOf(false) }

    var appLang by remember {
        mutableStateOf(LanguagePreference.getAppLanguage(context))
    }

    val currentVersionName = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0"
        } catch (_: Exception) { "1.0" }
    }

    var currentTabId   by rememberSaveable { mutableStateOf("home") }
    var activeOverlay  by rememberSaveable { mutableStateOf<String?>(null) }
    var homePostId     by rememberSaveable { mutableStateOf<String?>(null) }
    var homeCategory   by rememberSaveable { mutableStateOf<String?>(null) }

    val showBottomBar = isLoggedIn && !forceUpdate && !showLangPicker && !showPhoneSetup && !isPhoneCheckLoading && activeOverlay == null && SharedScrollState.isScrollingUp

    val activity = context as? android.app.Activity
    LaunchedEffect(isLoggedIn, currentTabId, activeOverlay) {
        val isLoginScreen = !isLoggedIn
        val isExploreScreen = isLoggedIn && currentTabId == "explore" && activeOverlay == null
        val isSettingScreen = isLoggedIn && activeOverlay == "settings"
        
        if (isLoginScreen || isExploreScreen || isSettingScreen) {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity?.window?.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    LaunchedEffect(Unit) {
        firestore.collection("settings").document("appConfig")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot == null) return@addSnapshotListener
                maintenanceMode = snapshot.getBoolean("maintenanceMode") ?: false
                maintenanceMsg  = snapshot.getString("maintenanceMsg")   ?: "App under maintenance"
                apkUrl          = snapshot.getString("apkUrl")           ?: ""
                latestVersion   = snapshot.getString("latestVersion")    ?: ""
                updateMessage   = snapshot.getString("updateMessage")    ?: "Naya version available hai!"
                val minVersion  = snapshot.getString("minVersion") ?: "1.0"
                forceUpdate     = isUpdateRequired(currentVersionName, minVersion) && apkUrl.isNotBlank()
                paywallEnabled  = snapshot.getBoolean("paywallEnabled") ?: false
                paywallLoading  = false
            }
    }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            val uid = GoogleAuthHelper.currentUser?.uid
            if (uid != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val ipAddress = try { URL("https://api.ipify.org").readText() } catch (e: Exception) { "Unknown" }
                        val deviceMake = android.os.Build.BRAND ?: "Unknown"
                        val deviceModel = android.os.Build.MODEL ?: "Unknown"
                        val osLang = Locale.getDefault().displayLanguage ?: "Unknown"

                        val updates = mapOf(
                            "ipAddress" to ipAddress,
                            "deviceMake" to deviceMake,
                            "deviceModel" to deviceModel,
                            "osLanguage" to osLang,
                            "lastLogin" to FieldValue.serverTimestamp(),
                            "lastActive" to FieldValue.serverTimestamp()
                        )
                        firestore.collection("users").document(uid).update(updates).await()
                    } catch (e: Exception) {
                        Log.e("SessionTrack", "Failed to update session details", e)
                    }
                }

                isPhoneCheckLoading = true
                firestore.collection("users").document(uid).get()
                    .addOnSuccessListener { snap ->
                        val phone = snap.getString("phone")
                        if (phone.isNullOrBlank()) {
                            showPhoneSetup = true
                        } else {
                            if (LanguagePreference.isFirstTime(context)) showLangPicker = true
                        }
                        isPhoneCheckLoading = false
                    }
                    .addOnFailureListener {
                        isPhoneCheckLoading = false
                        if (LanguagePreference.isFirstTime(context)) showLangPicker = true
                    }

                firestore.collection("users").document(uid)
                    .addSnapshotListener { snapshot, _ ->
                        userPlan = snapshot?.getString("plan") ?: "free"
                    }
            }
        }
    }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            GoogleAuthHelper.listenForBlockStatus(
                onBlocked   = { userBlocked = true },
                onUnblocked = { userBlocked = false }
            )
        }
    }

    if (forceUpdate && apkUrl.isNotBlank()) {
        BackHandler(enabled = true) {}
        ForceUpdateScreen(apkUrl = apkUrl, latestVersion = latestVersion, updateMessage = updateMessage)
        return
    }

    if (userBlocked) {
        BackHandler(enabled = true) {}
        BlockedScreen()
        return
    }

    if (!isLoggedIn) {
        AuthScreen(
            onLoginSuccess = { isLoggedIn = true },
            onUserBlocked  = { userBlocked = true }
        )
        return
    }

    if (isPhoneCheckLoading) {
        BackHandler(enabled = true) {}
        StatuSevaLoadingAnimation()
        return
    }

    if (showPhoneSetup) {
        BackHandler(enabled = true) {}
        PhoneSetupScreen(onSuccess = {
            showPhoneSetup = false
            if (LanguagePreference.isFirstTime(context)) {
                showLangPicker = true
            }
        })
        return
    }

    if (showLangPicker) {
        BackHandler(enabled = true) {}
        LanguagePickerScreen(
            onLanguageSelected = { lang ->
                LanguagePreference.setContentLanguage(context, lang)
                LanguagePreference.setAppLanguage(context, lang)
                LanguagePreference.setFirstTimeDone(context)
                appLang        = lang
                showLangPicker = false

                // 🌟 AUTOMATION: Update notification topics when language changes
                FirebaseMessaging.getInstance().subscribeToTopic("topic_$lang")
                val otherLang = if (lang == "hi") "mr" else "hi"
                FirebaseMessaging.getInstance().unsubscribeFromTopic("topic_$otherLang")
            }
        )
        return
    }

    LaunchedEffect(Unit) {
        val category = MainActivity.pendingCategory
        val postId   = MainActivity.pendingPostId
        if (category.isNotBlank()) {
            homeCategory = category
            currentTabId = "home"
            MainActivity.pendingCategory = ""
        }
        if (postId.isNotBlank()) {
            homePostId   = postId
            currentTabId = "home"
            MainActivity.pendingPostId = ""
        }
    }

    BackHandler(enabled = activeOverlay != null || currentTabId != "home") {
        if (activeOverlay != null) {
            activeOverlay = null
        } else if (currentTabId != "home") {
            currentTabId = "home"
        }
    }

    fun handleNavigation(route: String) {
        when {
            route == "settings"         -> activeOverlay = "settings"
            route == "notifications"    -> activeOverlay = "notifications"
            route == "feedback"         -> activeOverlay = "feedback"
            route == "subscription"     -> activeOverlay = "subscription"
            route == "branding"         -> activeOverlay = "branding"
            route == "blocked_users"    -> activeOverlay = "blocked_users"
            route == "about"            -> activeOverlay = "about"
            route == "home"             -> { currentTabId = "home"; activeOverlay = null }
            route == "explore"          -> { currentTabId = "explore"; activeOverlay = null }
            route == "upload"           -> { currentTabId = "upload"; activeOverlay = null }
            route == "profile"          -> { currentTabId = "profile"; activeOverlay = null }
            route.startsWith("home?") -> {
                val cat = route.substringAfter("category=", "")
                if (cat.isNotBlank()) homeCategory = cat
                currentTabId = "home"
                activeOverlay = null
            }
        }
    }

    Scaffold(
        modifier            = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding).background(MaterialTheme.colorScheme.background)) {

            val bottomNavItems = remember { listOf(Screen.Home, Screen.Explore, Screen.Upload, Screen.Profile) }
            val pagerState = rememberPagerState(pageCount = { bottomNavItems.size }, initialPage = 0)
            val coroutineScope = rememberCoroutineScope()

            LaunchedEffect(pagerState.currentPage) {
                SharedScrollState.isScrollingUp = true
                val route = bottomNavItems[pagerState.currentPage].route
                if (currentTabId != route) currentTabId = route
            }

            LaunchedEffect(currentTabId) {
                val index = bottomNavItems.indexOfFirst { it.route == currentTabId }
                if (index != -1 && index != pagerState.currentPage && !pagerState.isScrollInProgress) {
                    pagerState.animateScrollToPage(
                        page = index,
                        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing)
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = 3,
                    userScrollEnabled = activeOverlay == null,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    when (page) {
                        0 -> HomeScreen(
                            onNavigate      = ::handleNavigation,
                            selectedPostId  = homePostId,
                            initialCategory = homeCategory,
                            appLang         = appLang,
                            paywallEnabled  = paywallEnabled,
                            userPlan        = userPlan,
                            isVisible       = pagerState.currentPage == 0 && activeOverlay == null && isConnected
                        )
                        1 -> ExploreScreen(onNavigate = ::handleNavigation, appLang = appLang)
                        2 -> UploadScreen(onNavigate = ::handleNavigation, appLang = appLang)
                        3 -> ProfileScreen(
                            onNavigate      = ::handleNavigation,
                            onLogout        = { isLoggedIn = false },
                            appLang         = appLang,
                            onAppLangChange = { newLang ->
                                LanguagePreference.setAppLanguage(context, newLang);
                                appLang = newLang
                                // 🌟 AUTOMATION: Sync topic if user changes language from profile settings
                                FirebaseMessaging.getInstance().subscribeToTopic("topic_$newLang")
                                val otherLang = if (newLang == "hi") "mr" else "hi"
                                FirebaseMessaging.getInstance().unsubscribeFromTopic("topic_$otherLang")
                            },
                            paywallEnabled  = paywallEnabled,
                            userPlan        = userPlan
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible  = activeOverlay != null,
                modifier = Modifier.fillMaxSize().zIndex(10f),
                enter    = fadeIn(animationSpec = tween(300, easing = FastOutSlowInEasing)) +
                        scaleIn(initialScale = 0.96f, animationSpec = tween(300, easing = FastOutSlowInEasing)),
                exit     = fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing)) +
                        scaleOut(targetScale = 0.96f, animationSpec = tween(200, easing = FastOutSlowInEasing))
            ) {
                when (activeOverlay) {
                    "settings" -> ProfileSettingsScreen(
                        onNavigate      = ::handleNavigation,
                        onBack          = { activeOverlay = null },
                        appLang         = appLang,
                        onAppLangChange = { newLang ->
                            LanguagePreference.setAppLanguage(context, newLang);
                            appLang = newLang
                            // 🌟 AUTOMATION: Sync topic here too just in case
                            FirebaseMessaging.getInstance().subscribeToTopic("topic_$newLang")
                            val otherLang = if (newLang == "hi") "mr" else "hi"
                            FirebaseMessaging.getInstance().unsubscribeFromTopic("topic_$otherLang")
                        },
                        onLogout        = { isLoggedIn = false }
                    )
                    "notifications" -> NotificationScreen(
                        onBack  = { activeOverlay = null },
                        appLang = appLang
                    )
                    "feedback" -> FeedbackScreen(
                        onBack = { activeOverlay = null }
                    )
                    "subscription" -> SubscriptionScreen(
                        appLang  = appLang,
                        userPlan = userPlan,
                        onBack   = { activeOverlay = null }
                    )
                    "branding" -> com.statusseva.app.ui.branding.BrandingSetupScreen(
                        onBack = { activeOverlay = null }
                    )
                    "blocked_users" -> com.statusseva.app.ui.settings.BlockedUsersScreen(
                        onBack = { activeOverlay = null }
                    )

                    "about" ->  com.statusseva.app.ui.profile.AboutScreen(
                        appLang = appLang,
                        onBack = { activeOverlay = null }
                    )
                }
            }

            AnimatedVisibility(
                visible  = showBottomBar,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp).zIndex(5f),
                enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400, easing = LinearOutSlowInEasing)) + fadeIn(tween(300)),
                exit     = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300, easing = FastOutLinearInEasing)) + fadeOut(tween(200))
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(72.dp),
                    shape = RoundedCornerShape(percent = 50),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 16.dp
                ) {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                        val density = androidx.compose.ui.platform.LocalDensity.current
                        val tabWidthPx = remember(maxWidth) { with(density) { (maxWidth / bottomNavItems.size).toPx() } }

                        // 🌟 SLIDING INDICATOR
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(maxWidth / bottomNavItems.size)
                                .offset {
                                    val fractionalPage = (pagerState.currentPage + pagerState.currentPageOffsetFraction)
                                        .coerceIn(0f, (bottomNavItems.size - 1).toFloat())
                                    val xOffset = tabWidthPx * fractionalPage
                                    androidx.compose.ui.unit.IntOffset(xOffset.roundToInt(), 0)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(56.dp)
                                        .height(32.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                )
                                Spacer(Modifier.height(4.dp))
                                // Invisible text to match the real tab's vertical layout perfectly
                                Text("A", fontSize = 10.sp, color = Color.Transparent)
                            }
                        }

                        // 🌟 TABS
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            bottomNavItems.forEachIndexed { index, item ->
                                val selected = currentTabId == item.route
                                val label = when (item.route) {
                                    Screen.Home.route    -> AppStrings.get("tab_home",    appLang)
                                    Screen.Explore.route -> AppStrings.get("tab_explore", appLang)
                                    Screen.Upload.route  -> when(appLang) {
                                        "hi" -> "अपलोड"
                                        "mr" -> "अपलोड"
                                        else -> "Upload"
                                    }
                                    Screen.Profile.route -> AppStrings.get("tab_profile", appLang)
                                    else                 -> item.route
                                }
                                val icon = when (item.route) {
                                    Screen.Home.route    -> Icons.Default.Home
                                    Screen.Explore.route -> Icons.Default.Explore
                                    Screen.Upload.route  -> Icons.Default.AddCircle
                                    Screen.Profile.route -> Icons.Default.Person
                                    else                 -> Icons.Default.Home
                                }

                                val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                                val isPressed by interactionSource.collectIsPressedAsState()

                                val scale by animateFloatAsState(
                                    targetValue = if (isPressed) 0.85f else if (selected) 1.1f else 1f,
                                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                    label = "icon_bounce"
                                )

                                val iconColor by animateColorAsState(
                                    targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    animationSpec = tween(150, easing = FastOutSlowInEasing),
                                    label = "icon_color"
                                )

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable(interactionSource = interactionSource, indication = null) {
                                            activeOverlay = null
                                            if (currentTabId != item.route) {
                                                coroutineScope.launch {
                                                    pagerState.animateScrollToPage(
                                                        page = index,
                                                        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing)
                                                    )
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(56.dp)
                                                .height(32.dp)
                                                .clip(RoundedCornerShape(50)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                icon,
                                                contentDescription = label,
                                                tint = iconColor,
                                                modifier = Modifier.size(24.dp).scale(scale)
                                            )
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            label,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                            color = iconColor,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            LaunchedEffect(isLoggedIn) {
                if (isLoggedIn) {
                    GoogleAuthHelper.listenForBlockStatus(
                        onBlocked = {
                            userBlocked = true
                            GoogleAuthHelper.signOut()
                            isLoggedIn = false
                        },
                        onUnblocked = { userBlocked = false }
                    )
                }
            }

            if (maintenanceMode) {
                Surface(modifier = Modifier.fillMaxSize().zIndex(20f), color = MaterialTheme.colorScheme.background) {
                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Under Maintenance", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(20.dp))
                        Text(maintenanceMsg, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            AnimatedVisibility(
                visible = !isConnected,
                enter = fadeIn(animationSpec = tween(300)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.zIndex(100f)
            ) {
                NoInternetOverlay(appLang)
            }
        }
    }
}

@Composable
fun PaywallScreen(
    appLang     : String = "hi",
    onLogout    : () -> Unit,
    onSubscribe : () -> Unit = {}
) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier            = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "👑", fontSize = 64.sp)
            Spacer(Modifier.height(24.dp))
            Text(
                text       = "StatuSeva Pro",
                style      = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color      = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text      = when(appLang) {
                    "hi"  -> "बेहतरीन WhatsApp स्टेटस के लिए\nSubscribe करें"
                    "mr"  -> "सर्वोत्तम WhatsApp स्टेटससाठी\nSubscribe करा"
                    else  -> "Subscribe for the best\nWhatsApp Status experience"
                },
                style     = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color     = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(40.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(16.dp),
                colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text       = when(appLang) {
                            "hi"   -> "₹2 Trial → फिर ₹199/माह"
                            "mr"   -> "₹2 Trial → मग ₹199/महिना"
                            else   -> "₹2 Trial → then ₹199/month"
                        },
                        style      = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color      = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text  = when(appLang) {
                            "hi"  -> "• Unlimited Downloads\n• Unlimited Share\n• New content daily\n• No ads"
                            "mr"  -> "• अमर्यादित Downloads\n• अमर्यादित Share\n• दररोज नवीन content\n• कोणत्याही जाहिराती नाही"
                            else  -> "• Unlimited Downloads\n• Unlimited Share\n• New content daily\n• No ads"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick  = onSubscribe,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape    = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text       = when(appLang) {
                        "hi"   -> "₹2 से शुरू करें"
                        "mr"   -> "₹2 पासून सुरू करा"
                        else   -> "Start with ₹2"
                    },
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onLogout) {
                Text("Logout", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun LanguagePickerScreen(onLanguageSelected: (String) -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize()) {

            // 🌟 1. Background Video Layer
            com.statusseva.app.ui.auth.BackgroundVideoPlayer()

            // 🌟 2. Gradient Overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // 🌟 3. Content
            Column(
                modifier            = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(painter = painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(90.dp))
                Spacer(Modifier.height(24.dp))
                Text(text = "StatusSeva", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(text = "अपनी भाषा चुनें / आपली भाषा निवडा", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(48.dp))
                Button(onClick = { onLanguageSelected("hi") }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp)) {
                    Text("हिंदी", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { onLanguageSelected("mr") }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp)) {
                    Text("मराठी", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

fun isUpdateRequired(currentVersion: String, minVersion: String): Boolean {
    return try {
        val current = currentVersion.trim().split(".").map { it.toIntOrNull() ?: 0 }
        val minimum = minVersion.trim().split(".").map { it.toIntOrNull() ?: 0 }
        val maxLen  = maxOf(current.size, minimum.size)
        val curr    = current + List(maxLen - current.size) { 0 }
        val mini    = minimum + List(maxLen - minimum.size) { 0 }
        for (i in 0 until maxLen) {
            when {
                curr[i] < mini[i] -> return true
                curr[i] > mini[i] -> return false
            }
        }
        false
    } catch (_: Exception) { false }
}

@Composable
fun StatuSevaLoadingAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "loading")

    val logoScale by infiniteTransition.animateFloat(
        initialValue = 0.85f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "logo_pulse"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f, targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "glow_alpha"
    )

    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "ring_rotate"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(140.dp)
                .graphicsLayer {
                    rotationZ = ringRotation
                    alpha = glowAlpha
                }
                .background(
                    brush = Brush.sweepGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            MaterialTheme.colorScheme.tertiary,
                            MaterialTheme.colorScheme.tertiary.copy(alpha = 0.1f),
                            MaterialTheme.colorScheme.primary
                        )
                    ),
                    shape = CircleShape
                )
        )

        Box(
            modifier = Modifier
                .size(120.dp)
                .background(MaterialTheme.colorScheme.background, CircleShape)
        )

        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = null,
            modifier = Modifier
                .size(80.dp)
                .graphicsLayer {
                    scaleX = logoScale
                    scaleY = logoScale
                }
        )
    }
}