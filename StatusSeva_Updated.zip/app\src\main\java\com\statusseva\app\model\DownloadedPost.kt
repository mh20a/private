package com.statusseva.app.model

data class DownloadedPost(
    val id           : String,
    val title        : String,
    val imageUrl     : String,
    val description  : String = "",
    val category     : String = "",
    val type         : String = "image",   // "image" or "video"
    val localUri     : String = "",        // local file URI after download
    val downloadedAt : Long   = System.currentTimeMillis()
)