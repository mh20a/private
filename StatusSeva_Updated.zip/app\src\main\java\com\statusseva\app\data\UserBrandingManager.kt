package com.statusseva.app.data

import android.content.Context
import android.net.Uri
import android.content.res.Configuration
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object UserBrandingManager {

    private const val PREFS_NAME       = "statusseva_branding_prefs"
    private const val KEY_NAME         = "branding_name"
    private const val KEY_PHOTO_URI    = "branding_photo_uri"
    private const val KEY_COLOR        = "branding_color"
    private const val KEY_ENABLED      = "branding_enabled"
    private const val KEY_DESIGN_LEFT  = "branding_design_left"
    private const val KEY_OUTLINE      = "branding_outline_enabled"

    var brandingName      by mutableStateOf("")
        private set
    var brandingPhotoUri  by mutableStateOf<Uri?>(null)
        private set
    var brandingColor     by mutableStateOf(-2) // Default -2 means Tricolour
        private set
    var isBrandingEnabled by mutableStateOf(true)
        private set
    var isLeftDesign      by mutableStateOf(false)
        private set
    var isOutlineEnabled  by mutableStateOf(true)
        private set

    // 🌟 Optimized Colors List with White at Start
    val presetColors = listOf(
        android.graphics.Color.WHITE, // ⚪ Pure White (index 0)
        0xFF000000.toInt(), // Black
        0xFFFF9800.toInt(), // Orange
        0xFFFF0000.toInt(), // Red
        0xFF2196F3.toInt(), // Blue
        0xFFFFEB3B.toInt(), // Yellow
        0xFF4CAF50.toInt(), // Green
        0xFFFF4081.toInt(), // Pink
        0xFF9C27B0.toInt(), // Purple
        0xFF795548.toInt(), // Brown
        0xFF9E9E9E.toInt(), // Grey
        -3,                 // 🌈 Mixed Colorful
        -2                  // 🇮🇳 Tri-color
    )

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
        reload(context.applicationContext)
    }

    private fun reload(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val name = prefs.getString(KEY_NAME, "") ?: ""

            // Initial check: if no color saved, default to -2 (Tricolour)
            var color = prefs.getInt(KEY_COLOR, -2)
            if (color == 0) {
                color = -2 // Migrate old 'smart' default (0) to Tricolour (-2)
            }

            val enabled = prefs.getBoolean(KEY_ENABLED, true)
            val designLeft = prefs.getBoolean(KEY_DESIGN_LEFT, false)
            val outlineOn = prefs.getBoolean(KEY_OUTLINE, true)
            val uriStr = prefs.getString(KEY_PHOTO_URI, null)

            var validUri: Uri? = null
            if (!uriStr.isNullOrBlank()) {
                try {
                    val uri = Uri.parse(uriStr)
                    context.contentResolver.openInputStream(uri)?.close()
                    validUri = uri
                } catch (_: Exception) {}
            }

            withContext(Dispatchers.Main) {
                brandingName = name
                brandingColor = color
                isBrandingEnabled = enabled
                isLeftDesign = designLeft
                isOutlineEnabled = outlineOn
                brandingPhotoUri = validUri
            }
        }
    }

    fun onAppForeground() {
        appContext?.let { reload(it) }
    }

    fun setName(context: Context, name: String) {
        brandingName = name
        CoroutineScope(Dispatchers.IO).launch {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString(KEY_NAME, name).apply()
        }
    }

    fun setPhotoUri(context: Context, uri: Uri?) {
        CoroutineScope(Dispatchers.IO).launch {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            if (uri != null) {
                try {
                    // 🌟 FIX: Copy image to internal storage for reliable loading
                    val destFile = java.io.File(context.filesDir, "branding_photo.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        java.io.FileOutputStream(destFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    val internalUri = Uri.fromFile(destFile)
                    withContext(Dispatchers.Main) {
                        brandingPhotoUri = internalUri
                    }
                    prefs.edit().putString(KEY_PHOTO_URI, internalUri.toString()).apply()
                } catch (_: Exception) {
                    // Fallback: try persistable URI
                    try {
                        context.contentResolver.takePersistableUriPermission(
                            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: Exception) {}
                    withContext(Dispatchers.Main) {
                        brandingPhotoUri = uri
                    }
                    prefs.edit().putString(KEY_PHOTO_URI, uri.toString()).apply()
                }
            } else {
                withContext(Dispatchers.Main) {
                    brandingPhotoUri = null
                }
                prefs.edit().remove(KEY_PHOTO_URI).apply()
                // Clean up stored file
                try { java.io.File(context.filesDir, "branding_photo.jpg").delete() } catch (_: Exception) {}
            }
        }
    }

    fun setColor(context: Context, color: Int) {
        brandingColor = color
        CoroutineScope(Dispatchers.IO).launch {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putInt(KEY_COLOR, color).apply()
        }
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        isBrandingEnabled = enabled
        CoroutineScope(Dispatchers.IO).launch {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply()
        }
    }

    fun setDesignPosition(context: Context, isLeft: Boolean) {
        isLeftDesign = isLeft
        CoroutineScope(Dispatchers.IO).launch {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_DESIGN_LEFT, isLeft).apply()
        }
    }

    fun setOutlineEnabled(context: Context, enabled: Boolean) {
        isOutlineEnabled = enabled
        CoroutineScope(Dispatchers.IO).launch {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_OUTLINE, enabled).apply()
        }
    }
}