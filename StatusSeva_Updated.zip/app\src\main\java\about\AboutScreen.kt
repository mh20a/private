package com.statusseva.app.ui.profile

import android.content.pm.PackageManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.statusseva.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    appLang: String = "hi",
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    // Helper for Multilingual Text
    fun str(hi: String, mr: String, en: String) = when (appLang) {
        "hi" -> hi; "mr" -> mr; else -> en
    }

    // Get App Version
    val appVersion = try {
        val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
        pInfo.versionName
    } catch (e: PackageManager.NameNotFoundException) {
        "1.0.0"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        str("हमारे बारे में", "आमच्याबद्दल", "About Us"),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // 🌟 1. App Logo & Name
            Image(
                painter = painterResource(id = R.drawable.logo), // Ensure your logo name matches
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(24.dp))
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "StatusSeva",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Version $appVersion",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(32.dp))

            // 🌟 2. What is StatusSeva & How it works
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = str("StatusSeva क्या है?", "StatusSeva काय आहे?", "What is StatusSeva?"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = str(
                            "StatusSeva भारत का बेहतरीन प्लेटफॉर्म है जहाँ आप रोज़ाना नए WhatsApp स्टेटस, ट्रेंडिंग वीडियो और इमेजेज हिंदी और मराठी में डाउनलोड और शेयर कर सकते हैं।",
                            "StatusSeva हे भारताचे एक उत्तम प्लॅटफॉर्म आहे जिथे तुम्ही दररोज नवीन WhatsApp स्टेटस, ट्रेंडिंग व्हिडिओ आणि इमेजेस हिंदी आणि मराठीमध्ये डाउनलोड आणि शेअर करू शकता.",
                            "StatusSeva is India's premium platform to download and share the latest daily WhatsApp statuses, trending videos, and images in Hindi and Marathi."
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = str("यह कैसे काम करता है?", "हे कसे काम करते?", "How it works?"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = str(
                            "अपनी पसंद की केटेगरी चुनें, अपना पसंदीदा स्टेटस खोजें और बस एक टैप में उसे हाई क्वालिटी में डाउनलोड करें या सीधे WhatsApp पर शेयर करें!",
                            "तुमची आवडती कॅटेगरी निवडा, तुमचा आवडता स्टेटस शोधा आणि एका टॅपमध्ये उच्च गुणवत्तेत डाउनलोड करा किंवा थेट WhatsApp वर शेअर करा!",
                            "Choose your favorite category, find the best status, and download it in high quality or share it directly to WhatsApp with just one tap!"
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 🌟 3. Connect With Us (Social Media Links)
            Text(
                text = str("हमसे जुड़ें", "आमच्याशी कनेक्ट व्हा", "Connect With Us"),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                textAlign = TextAlign.Start,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column {
                    SocialLinkItem(
                        icon = painterResource(id = R.drawable.ic_instagram),
                        title = "Instagram",
                        handle = "@statusseva",
                        color = Color(0xFFE1306C),
                        onClick = { uriHandler.openUri("https://www.instagram.com/statusseva?igsh=YjViaTRjamRpc3Ry") }
                    )
                    Divider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    SocialLinkItem(
                        icon = painterResource(id = R.drawable.ic_youtube),
                        title = "YouTube",
                        handle = "@statussevapp",
                        color = Color(0xFFFF0000),
                        onClick = { uriHandler.openUri("https://youtube.com/@statussevaapp?si=QD8F6-9NKXP_BJfk") }
                    )
                    Divider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    SocialLinkItem(
                        icon = rememberVectorPainter(Icons.Default.Language),
                        title = "Website",
                        handle = "statusseva.in",
                        color = Color(0xFF2196F3),
                        onClick = { uriHandler.openUri("https://statusseva.in") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 🌟 4. Developers
            Text(
                text = str("डेवलपर्स", "डेव्हलपर्स", "Developed By"),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                textAlign = TextAlign.Start,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Code,
                            contentDescription = "Devs",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Gothwal Studio",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Founders & Creators",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // 🌟 5. Slogan (Made in India)
            Text(
                text = str(
                    "Made in India 🇮🇳 Made for India",
                    "Made in India 🇮🇳 Made for India",
                    "Made in India 🇮🇳 Made for India"
                ),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(80.dp)) // Extra padding for bottom bar
        }
    }
}

@Composable
fun SocialLinkItem(
    icon: Painter,
    title: String,
    handle: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(painter = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(text = handle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
    }
}