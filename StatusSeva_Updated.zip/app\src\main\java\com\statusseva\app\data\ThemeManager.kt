package com.statusseva.app.data

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object ThemeManager {

    private const val PREFS_NAME  = "statusseva_theme_prefs"
    private const val KEY_IS_DARK = "is_dark_mode"
    private const val KEY_IS_AUTO = "is_auto_mode"

    private lateinit var prefs: SharedPreferences

    var isDark by mutableStateOf(false)
        private set

    var isAuto by mutableStateOf(true)
        private set

    fun init(context: Context) {
        prefs = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        isAuto = prefs.getBoolean(KEY_IS_AUTO, true)

        if (isAuto) {
            isDark = isSystemDark(context)
        } else {
            isDark = prefs.getBoolean(KEY_IS_DARK, false)
        }
    }

    private fun isSystemDark(context: Context): Boolean {
        return (context.resources.configuration.uiMode and
                Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun setThemeMode(context: Context, mode: String) {
        when (mode) {
            "system" -> {
                isAuto = true
                prefs.edit().putBoolean(KEY_IS_AUTO, true).apply()
                isDark = isSystemDark(context)
            }
            "light" -> {
                isAuto = false
                prefs.edit().putBoolean(KEY_IS_AUTO, false).apply()
                updateDarkMode(false)
            }
            "dark" -> {
                isAuto = false
                prefs.edit().putBoolean(KEY_IS_AUTO, false).apply()
                updateDarkMode(true)
            }
        }
    }

    private fun updateDarkMode(enabled: Boolean) {
        isDark = enabled
        prefs.edit().putBoolean(KEY_IS_DARK, enabled).apply()
    }
}