package com.statusseva.app.model

data class Post(
    val id               : String        = "",
    val title            : String        = "",
    val description      : String        = "",
    val category         : String        = "",
    val imageUrl         : String        = "",
    val videoUrl         : String        = "",
    val type             : String        = "image",
    val createdAt        : Long          = 0L,
    val isFeatured       : Boolean       = false,
    val language         : String        = "",
    val tags             : List<String>  = emptyList(),
    val position         : Int           = Int.MAX_VALUE,
    val aspectRatio      : Double?       = null,
    val uploadedBy       : String?       = null,
    val originalImageUrl : String        = "",

    // ── Category background image ke liye (Explore screen) ──
    val bgImageUrl       : String        = "",

    // ── Content fields — admin panel se aate hain ──────────
    val caption          : String        = "",
    val captionHi        : String        = "",
    val captionEn        : String        = "",
    val status           : String        = "Published",
    val downloads        : Long          = 0L,
    val reportCount      : Int           = 0,
    val isTrending       : Boolean       = false,
    val isLatestSpecial  : Boolean       = false,
    val featured         : Boolean       = false,
    val premium          : Boolean       = false
)
