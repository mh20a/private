package com.statusseva.app.data

import android.content.Context
import android.content.SharedPreferences

object AppPreferences {

    private const val PREF_NAME = "statusseva_prefs"
    private const val KEY_DARK_MODE = "dark_mode"

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun isDarkMode(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_DARK_MODE, false)
    }

    fun updateDarkMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }
}