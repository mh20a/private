package com.statusseva.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String) {
    object Home            : Screen("home")
    object Explore         : Screen("explore")
    object Profile         : Screen("profile")
    object Upload          : Screen("upload")
    object ProfileSettings : Screen("profile_settings")
    object Notifications   : Screen("notifications")
}

data class BottomNavItem(
    val label  : String,
    val icon   : ImageVector,
    val screen : Screen
)

val bottomNavItems = listOf(
    BottomNavItem("Home",    Icons.Filled.Home,        Screen.Home),
    BottomNavItem("Explore", Icons.Filled.Explore,     Screen.Explore),
    BottomNavItem("Upload",  Icons.Filled.CloudUpload, Screen.Upload),
    BottomNavItem("Profile", Icons.Filled.Person,      Screen.Profile)
)

// Yahan se AppNavHost function poori tarah hata diya gaya hai,
// kyunki ab navigation MainActivity ke absolute overlay se handle hota hai.