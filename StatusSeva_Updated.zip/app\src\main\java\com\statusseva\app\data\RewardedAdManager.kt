package com.statusseva.app.data

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object RewardedAdManager {
    private var rewardedAd: RewardedAd? = null
    private var isAdLoading = false

    // Real Ad Unit ID provided by user, Test ID for debugging
    private val AD_UNIT_ID = if (com.statusseva.app.BuildConfig.DEBUG) {
        "ca-app-pub-3940256099942544/5224354917"
    } else {
        "ca-app-pub-4771807910993508/4519087637"
    }

    fun loadAd(context: Context) {
        if (rewardedAd != null || isAdLoading) {
            return
        }
        
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        
        RewardedAd.load(
            context,
            AD_UNIT_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d("RewardedAdManager", adError.toString())
                    rewardedAd = null
                    isAdLoading = false
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d("RewardedAdManager", "Ad was loaded.")
                    rewardedAd = ad
                    isAdLoading = false
                }
            }
        )
    }

    fun showAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdClosedEarly: () -> Unit,
        onAdFailedToLoad: () -> Unit
    ) {
        if (rewardedAd != null) {
            var rewardEarned = false

            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d("RewardedAdManager", "Ad was dismissed.")
                    // If dismissed without earning reward, it was closed early
                    if (!rewardEarned) {
                        onAdClosedEarly()
                    }
                    rewardedAd = null
                    // Preload the next ad
                    loadAd(activity)
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.d("RewardedAdManager", "Ad failed to show: ${adError.message}")
                    rewardedAd = null
                    onAdFailedToLoad()
                    // Preload the next ad
                    loadAd(activity)
                }
            }

            rewardedAd?.show(activity) { rewardItem ->
                Log.d("RewardedAdManager", "User earned the reward: ${rewardItem.amount}")
                rewardEarned = true
                onRewardEarned()
            }
        } else {
            Log.d("RewardedAdManager", "The rewarded ad wasn't ready yet.")
            onAdFailedToLoad()
            // Try to reload
            loadAd(activity)
        }
    }
}
