package com.statusseva.app.data

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class PaymentEvent {
    object Idle : PaymentEvent()
    object Loading : PaymentEvent()
    object Verifying : PaymentEvent()
    object Success : PaymentEvent()
    data class Error(val message: String) : PaymentEvent()
}

object BillingManager : PurchasesUpdatedListener, BillingClientStateListener {

    private lateinit var billingClient: BillingClient
    val paymentEventFlow = MutableStateFlow<PaymentEvent>(PaymentEvent.Idle)
    private var isConnected = false
    
    // Replace these with your actual Play Console Product IDs
    const val PRO_MONTHLY = "status_seva_pro_monthly"
    const val PRO_YEARLY = "status_seva_pro_yearly"

    val subscriptionProducts = MutableStateFlow<List<ProductDetails>>(emptyList())

    fun initialize(context: Context) {
        billingClient = BillingClient.newBuilder(context)
            .setListener(this)
            .enablePendingPurchases()
            .build()

        connectToGooglePlay()
    }

    private fun connectToGooglePlay() {
        if (!billingClient.isReady) {
            billingClient.startConnection(this)
        }
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
            isConnected = true
            querySubscriptionProducts()
        } else {
            Log.e("BillingManager", "Billing setup failed: ${billingResult.debugMessage}")
        }
    }

    override fun onBillingServiceDisconnected() {
        isConnected = false
        // Try to restart the connection on the next request to
        // Google Play by calling the startConnection() method.
    }

    private fun querySubscriptionProducts() {
        val queryProductDetailsParams = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PRO_MONTHLY)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PRO_YEARLY)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )
            )
            .build()

        billingClient.queryProductDetailsAsync(queryProductDetailsParams) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                subscriptionProducts.value = productDetailsList
            }
        }
    }

    fun launchPurchaseFlow(activity: Activity, productDetails: ProductDetails) {
        if (!billingClient.isReady) {
            paymentEventFlow.value = PaymentEvent.Error("Billing client not ready.")
            connectToGooglePlay()
            return
        }
        
        paymentEventFlow.value = PaymentEvent.Loading

        val offerToken = productDetails.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: ""

        val productDetailsParamsList = listOf(
            BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(productDetails)
                .setOfferToken(offerToken)
                .build()
        )

        val billingFlowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(productDetailsParamsList)
            .build()

        billingClient.launchBillingFlow(activity, billingFlowParams)
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            paymentEventFlow.value = PaymentEvent.Verifying
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            paymentEventFlow.value = PaymentEvent.Error("Payment cancelled by user.")
        } else {
            paymentEventFlow.value = PaymentEvent.Error(billingResult.debugMessage.ifBlank { "Payment failed." })
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged) {
                val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient.acknowledgePurchase(acknowledgePurchaseParams) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        verifySubscriptionOnServer(purchase)
                    } else {
                         paymentEventFlow.value = PaymentEvent.Error("Failed to acknowledge purchase.")
                    }
                }
            } else {
                verifySubscriptionOnServer(purchase)
            }
        }
    }

    private fun verifySubscriptionOnServer(purchase: Purchase) {
        // Here you would typically send the purchaseToken to your Firebase Cloud Function
        // to securely verify it via Google Play Developer API and then update Firestore.
        // For now, simulating client-side success based on previous app logic structure.
        
        val uid = GoogleAuthHelper.currentUser?.uid ?: return
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Updating Firestore user plan directly for demonstration. 
                // Ideal approach is Cloud Functions!
                FirebaseFirestore.getInstance().collection("users").document(uid)
                    .update("plan", "pro")
                    
                withContext(Dispatchers.Main) {
                    paymentEventFlow.value = PaymentEvent.Success
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    paymentEventFlow.value = PaymentEvent.Error("Server verification failed.")
                }
            }
        }
    }
}
