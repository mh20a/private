package com.statusseva.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import com.statusseva.app.R
import com.statusseva.app.R.drawable

object WatermarkHelper {

    private val captions = listOf(
        "\ud83c\udf38 सुंदर स्टेटस के लिए StatusSeva डाउनलोड करें!\nBeautiful status for every mood \u2728\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\ud83d\udcab ऐसे और स्टेटस चाहिए? StatusSeva पर आओ!\nGet more amazing status on StatusSeva \ud83d\ude4f\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\ud83c\udfaf हर मौके के लिए बेस्ट स्टेटस — StatusSeva\nBest status for every occasion \u2764\ufe0f\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\ud83c\udf3a StatusSeva — आपका अपना स्टेटस ऐप\nYour favourite status app is here! \ud83d\udd25\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\u2728 दिल को छूने वाले स्टेटस — StatusSeva पर\nTouch hearts with every status \ud83d\udc96\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\ud83d\ude4f और भी धार्मिक स्टेटस के लिए StatusSeva\nMore religious & festival status on StatusSeva\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app",
        "\ud83d\udca5 फ्री में डाउनलोड करो — StatusSeva App\nDownload FREE — StatusSeva App \ud83c\udf89\n\ud83d\udc49 https://play.google.com/store/apps/details?id=com.statusseva.app"
    )

    fun getRandomCaption(): String = captions.random()

    fun addWatermark(context: Context, originalBitmap: Bitmap, scale: Float = 0.07f): Bitmap {
        val result = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val imgW = result.width.toFloat()
        val imgH = result.height.toFloat()

        // Scale watermark — 2.5x larger than the previous values
        val dynamicScale = when {
            imgW >= 1440 -> 0.15f    // 2K+ images
            imgW >= 1080 -> 0.14f    // Full HD
            imgW >= 720  -> 0.13f    // HD
            else         -> scale * 2.5f    // Default
        }
        val targetW = (imgW * dynamicScale).toInt().coerceAtLeast(1)

        // 🌟 FIX: Decode from input stream to BYPASS Android's density-based scaling.
        // decodeResource() applies screen density scaling even with inScaled=false when
        // the drawable is in a density bucket. openRawResource() gives raw bytes.
        val wmBitmap = try {
            val inputStream = context.resources.openRawResource(drawable.watermark)
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = false
                inSampleSize       = 1
                inScaled           = false
                inPreferredConfig  = Bitmap.Config.ARGB_8888
            }
            val bmp = BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()
            bmp
        } catch (_: Exception) {
            null
        } ?: return result

        // 🌟 PREMIUM: Pre-scale watermark to exact pixel dimensions with bilinear filter
        // This eliminates canvas-level scaling artifacts for 100% crisp output
        val targetH = (wmBitmap.height.toFloat() / wmBitmap.width.toFloat() * targetW).toInt().coerceAtLeast(1)
        val scaledWm = Bitmap.createScaledBitmap(wmBitmap, targetW, targetH, true)
        wmBitmap.recycle()

        val marginLeft = imgW * 0.04f
        val marginTop  = imgH * 0.02f

        // 🌟 PREMIUM: High quality paint with dither for smooth alpha edges
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
            alpha         = 230  // Slightly higher for bolder visibility
            isFilterBitmap = true
            isAntiAlias    = true
            isDither       = true  // Smooth color transitions
        }

        // Draw pre-scaled watermark 1:1 — no canvas scaling needed = zero quality loss
        canvas.drawBitmap(scaledWm, marginLeft, marginTop, paint)
        scaledWm.recycle()

        return result
    }
}