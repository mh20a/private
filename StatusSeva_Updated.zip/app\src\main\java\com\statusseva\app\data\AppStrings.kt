package com.statusseva.app.data

object AppStrings {

    fun get(key: String, lang: String): String =
        strings[lang]?.get(key) ?: strings["hi"]?.get(key) ?: key

    private val strings = mapOf(

        // ── ENGLISH ───────────────────────────────────────────
        "en" to mapOf(
            // Bottom Nav
            "tab_home"       to "Home",
            "tab_explore"    to "Explore",
            "tab_profile"    to "Profile",

            // Home Screen
            "btn_download"   to "Download",
            "btn_share"      to "Share",
            "search_hint"    to "Search posts...",
            "no_posts"       to "No posts found",
            "load_error"     to "Couldn't load posts",

            // Explore Screen
            "explore_title"  to "Explore",
            "explore_hint"   to "Search categories...",
            "no_categories"  to "No categories found",

            // Profile Screen
            "profile_title"         to "Profile",
            "content_language"      to "Content Language",
            "app_language"          to "App Language",
            "lang_hindi"            to "Hindi",
            "lang_marathi"          to "Marathi",
            "lang_english"          to "English",
            "theme"                 to "Theme",
            "theme_dark"            to "Dark Mode",
            "theme_light"           to "Light Mode",
            "dark_mode"             to "Dark Mode",
            "light_mode"            to "Light Mode",
            "logout"                to "Logout",
            "downloads"             to "Downloads",
            "notifications"         to "Notifications",
            "feedback"              to "Feedback",
            "profile_settings"      to "Profile Settings",
            "content_lang_desc"     to "Filter posts by language",
            "app_lang_desc"         to "Change app display language",

            // Help & Support
            "help_support"          to "Help & Support",
            "help_title"            to "How can we help you?",
            "help_phone"            to "Phone Number",
            "help_phone_hint"       to "Enter your phone number",
            "help_email"            to "Email Address",
            "help_email_hint"       to "Enter your email address",
            "help_issue"            to "Describe your issue",
            "help_issue_hint"       to "Describe your issue in detail...",
            "help_submit"           to "Submit",
            "help_submitting"       to "Submitting...",
            "help_success"          to "Your request has been submitted!",
            "help_success_sub"      to "Our team will contact you within 24 hours.",
            "help_error"            to "Submission failed. Please try again.",
            "help_fill_all"         to "Please fill all fields.",

            // Terms & Conditions
            "terms"                 to "Terms & Conditions",
            "terms_last_updated"    to "Last updated: April 2026",
            "terms_content"         to """
By using StatusSeva, you agree to the following terms:

1. Content Usage
All content on StatusSeva (images, videos, quotes) is provided for personal WhatsApp status use only. Commercial use is strictly prohibited.

2. Intellectual Property
All content uploaded by the admin team is protected. You may not copy, redistribute, or sell any content from this app.

3. User Conduct
You agree not to misuse the app, share inappropriate content, or attempt to hack/reverse-engineer the application.

4. Privacy
We collect your Google account information (name, email, photo) for login purposes only. We do not sell your data to third parties.

5. Downloads & Watermarks
Downloaded content may include watermarks. Removing watermarks is not permitted.

6. Termination
We reserve the right to suspend or terminate access to any user violating these terms.

7. Changes
We may update these terms at any time. Continued use of the app constitutes acceptance of the updated terms.

For support, contact us through the Help & Support section.
            """.trimIndent(),

            // Downloads
            "downloads_title"       to "Downloads",
            "no_downloads"          to "No downloads yet",
            "no_downloads_sub"      to "Downloaded posts will appear here",

            // Notifications
            "notif_title"           to "Notifications",
            "no_notifs"             to "No notifications yet",

            // Upload tab
            "upload_tab_upload"      to "Upload",
            "upload_tab_my"          to "My Content",
            "upload_another"         to "+ Upload Another",
            "my_content_empty"       to "No content yet",
            "my_content_empty_sub"   to "Upload your first content",
            "uc_status_pending"      to "⏳ Under Review",
            "uc_status_approved"     to "✅ Live",
            "uc_status_rejected"     to "❌ Rejected",
            "uc_msg_pending"         to "Admin is reviewing. Will go live after approval.",
            "uc_msg_approved"        to "🎉 Your content is live in the app!",
            "uc_msg_rejected"        to "Rejected due to the reason mentioned above.",
            "uc_reject_reason_label" to "Reason for rejection:",
            "uc_cancel_title"        to "Cancel Request?",
            "uc_cancel_body"         to "This upload request will be cancelled and file deleted.",
            "uc_delete_title"        to "Delete Post?",
            "uc_delete_body"         to "This post will be permanently deleted from server.",
            "uc_cancel_btn"          to "Cancel Request",
            "uc_delete_btn"          to "Delete",
            "uc_keep_btn"            to "Keep",

            // Common
            "save"                  to "Save",
            "cancel"                to "Cancel",
            "ok"                    to "OK",
            "close"                 to "Close",
            "just_now"              to "Just now",
            "saved_ok"              to "Saved ✓",
            "download_fail"         to "Download failed",
            "wa_not_installed"      to "WhatsApp not installed",
            "video_preparing"       to "Preparing video...",
            "video_load_fail"       to "Video load failed",

            "cat_all"               to "All",
            "upload_title"          to "Upload Content",
            "upload_media"          to "Select Media",
            "upload_pick"           to "Tap to select image or video",
            "upload_pick_sub"       to "JPG, PNG, MP4 supported",
            "upload_details"        to "Post Details",
            "upload_caption"        to "Caption",
            "upload_caption_hint"   to "Write a caption for your post...",
            "upload_category"       to "Category",
            "upload_category_hint"  to "Select or type category",
            "upload_language"       to "Language",
            "upload_tags"           to "Tags",
            "upload_tags_hint"      to "Type tag and press +",
            "upload_guidelines_title" to "Guidelines",
            "upload_guidelines"     to "• Only original content allowed\n• No adult or violent content\n• Your post will be reviewed by admin before publishing\n• Rejected posts will be notified with reason",
            "upload_submit"         to "Submit for Review",
            "upload_uploading"      to "Uploading...",
            "upload_success"        to "Submitted Successfully!",
            "upload_success_sub"    to "Admin will review your post. You will be notified on approval or rejection.",
            "upload_error"          to "Upload failed. Please try again.",
            "upload_pick_first"     to "Please select an image or video first.",
            "upload_caption_required" to "Please write a caption.",
            "upload_category_required" to "Please select a category.",
            "upload_video_selected" to "Video selected",
            "upload_image_selected" to "Image selected",

            // 🌐 No Internet (English)
            "no_internet_title"     to "No Internet Connection",
            "no_internet_desc"      to "Please turn on your data or Wi-Fi to continue."
        ),

        // ── HINDI ─────────────────────────────────────────────
        "hi" to mapOf(
            // Bottom Nav
            "tab_home"       to "होम",
            "tab_explore"    to "एक्सप्लोर",
            "tab_profile"    to "प्रोफाइल",

            // Home Screen
            "btn_download"   to "डाउनलोड",
            "btn_share"      to "शेयर",
            "search_hint"    to "पोस्ट खोजें...",
            "no_posts"       to "कोई पोस्ट नहीं मिली",
            "load_error"     to "पोस्ट लोड नहीं हो सकी",

            // Explore Screen
            "explore_title"  to "एक्सप्लोर",
            "explore_hint"   to "कैटेगरी खोजें...",
            "no_categories"  to "कोई कैटेगरी नहीं मिली",

            // Profile Screen
            "profile_title"         to "प्रोफाइल",
            "content_language"      to "कंटेंट भाषा",
            "app_language"          to "ऐप भाषा",
            "lang_hindi"            to "हिंदी",
            "lang_marathi"          to "मराठी",
            "lang_english"          to "English",
            "theme"                 to "थीम",
            "theme_dark"            to "डार्क मोड",
            "theme_light"           to "लाइट मोड",
            "dark_mode"             to "डार्क मोड",
            "light_mode"            to "लाइट मोड",
            "logout"                to "लॉगआउट",
            "downloads"             to "डाउनलोड्स",
            "notifications"         to "नोटिफिकेशन",
            "feedback"              to "फीडबैक",
            "profile_settings"      to "प्रोफाइल सेटिंग्स",
            "content_lang_desc"     to "भाषा के अनुसार पोस्ट फिल्टर करें",
            "app_lang_desc"         to "ऐप की डिस्प्ले भाषा बदलें",

            // Help & Support
            "help_support"          to "सहायता और समर्थन",
            "help_title"            to "हम आपकी कैसे मदद कर सकते हैं?",
            "help_phone"            to "फोन नंबर",
            "help_phone_hint"       to "अपना फोन नंबर दर्ज करें",
            "help_email"            to "ईमेल पता",
            "help_email_hint"       to "अपना ईमेल पता दर्ज करें",
            "help_issue"            to "समस्या बताएं",
            "help_issue_hint"       to "अपनी समस्या विस्तार से लिखें...",
            "help_submit"           to "सबमिट करें",
            "help_submitting"       to "सबमिट हो रहा है...",
            "help_success"          to "आपका अनुरोध सबमिट हो गया!",
            "help_success_sub"      to "हमारी टीम 24 घंटे के अंदर आपसे संपर्क करेगी।",
            "help_error"            to "सबमिट नहीं हो सका। कृपया दोबारा कोशिश करें।",
            "help_fill_all"         to "कृपया सभी फ़ील्ड भरें।",

            // Terms & Conditions
            "terms"                 to "नियम और शर्तें",
            "terms_last_updated"    to "अंतिम अपडेट: April 2026",
            "terms_content"         to """
StatusSeva का उपयोग करके, आप निम्नलिखित नियमों से सहमत होते हैं:

1. कंटेंट उपयोग
StatusSeva पर सभी कंटेंट (चित्र, वीडियो, कोट्स) केवल व्यक्तिगत WhatsApp स्टेटस उपयोग के लिए है। व्यावसायिक उपयोग सख्त वर्जित है।

2. बौद्धिक संपदा
एडमिन टीम द्वारा अपलोड किया गया सभी कंटेंट सुरक्षित है। आप इस ऐप से किसी भी कंटेंट को कॉपी, पुनर्वितरित या बेच नहीं सकते।

3. उपयोगकर्ता आचरण
आप ऐप का दुरुपयोग नहीं करेंगे, अनुचित सामग्री साझा नहीं करेंगे, या एप्लिकेशन को हैक/रिवर्स-इंजीनियर करने का प्रयास नहीं करेंगे।

4. गोपनीयता
हम केवल लॉगिन उद्देश्यों के लिए आपकी Google खाता जानकारी (नाम, ईमेल, फोटो) एकत्र करते हैं। हम आपका डेटा तीसरे पक्ष को नहीं बेचते।

5. डाउनलोड और वॉटरमार्क
डाउनलोड किए गए कंटेंट में वॉटरमार्क हो सकते हैं। वॉटरमार्क हटाना अनुमत नहीं है।

6. समाप्ति
हम इन नियमों का उल्लंघन करने वाले किसी भी उपयोगकर्ता की पहुंच को निलंबित या समाप्त करने का अधिकार सुरक्षित रखते हैं।

7. परिवर्तन
हम किसी भी समय इन नियमों को अपडेट कर सकते हैं। ऐप का निरंतर उपयोग अपडेट किए गए नियमों की स्वीकृति माना जाएगा।

सहायता के लिए, Help & Support अनुभाग के माध्यम से हमसे संपर्क करें।
            """.trimIndent(),

            // Downloads
            "downloads_title"       to "डाउनलोड्स",
            "no_downloads"          to "अभी तक कोई डाउनलोड नहीं",
            "no_downloads_sub"      to "डाउनलोड की गई पोस्ट यहाँ दिखेंगी",

            // Notifications
            "notif_title"           to "नोटिफिकेशन",
            "no_notifs"             to "अभी कोई नोटिफिकेशन नहीं",

            // Upload tab
            "upload_tab_upload"      to "अपलोड",
            "upload_tab_my"          to "मेरा कंटेंट",
            "upload_another"         to "+ और अपलोड करें",
            "my_content_empty"       to "अभी तक कोई कंटेंट नहीं",
            "my_content_empty_sub"   to "अपना पहला कंटेंट अपलोड करो",
            "uc_status_pending"      to "⏳ समीक्षा में",
            "uc_status_approved"     to "✅ लाइव",
            "uc_status_rejected"     to "❌ अस्वीकृत",
            "uc_msg_pending"         to "एडमिन समीक्षा कर रहा है। अप्रूव होने पर लाइव होगा।",
            "uc_msg_approved"        to "🎉 आपका कंटेंट अब ऐप में लाइव है!",
            "uc_msg_rejected"        to "ऊपर दिए गए कारण की वजह से अस्वीकृत हुआ।",
            "uc_reject_reason_label" to "अस्वीकृति का कारण:",
            "uc_cancel_title"        to "अनुरोध रद्द करें?",
            "uc_cancel_body"         to "यह अपलोड अनुरोध रद्द हो जाएगा और फ़ाइल डिलीट हो जाएगी।",
            "uc_delete_title"        to "पोस्ट डिलीट करें?",
            "uc_delete_body"         to "यह पोस्ट सर्वर से स्थायी रूप से डिलीट हो जाएगी।",
            "uc_cancel_btn"          to "अनुरोध रद्द करें",
            "uc_delete_btn"          to "डिलीट करें",
            "uc_keep_btn"            to "रखें",

            // Common
            "save"                  to "सेव करें",
            "cancel"                to "रद्द करें",
            "ok"                    to "ठीक है",
            "close"                 to "बंद करें",
            "just_now"              to "अभी",
            "saved_ok"              to "सेव हो गया ✓",
            "download_fail"         to "डाउनलोड फेल हो गया",
            "wa_not_installed"      to "WhatsApp इंस्टॉल नहीं है",
            "video_preparing"       to "वीडियो तैयार हो रहा है...",
            "video_load_fail"       to "वीडियो लोड नहीं हुआ",

            "cat_all"               to "सभी",
            "upload_title"          to "कंटेंट अपलोड करें",
            "upload_media"          to "मीडिया चुनें",
            "upload_pick"           to "इमेज या वीडियो चुनने के लिए टैप करें",
            "upload_pick_sub"       to "JPG, PNG, MP4 सपोर्टेड",
            "upload_details"        to "पोस्ट विवरण",
            "upload_caption"        to "कैप्शन",
            "upload_caption_hint"   to "अपनी पोस्ट के लिए कैप्शन लिखें...",
            "upload_category"       to "कैटेगरी",
            "upload_category_hint"  to "कैटेगरी चुनें या टाइप करें",
            "upload_language"       to "भाषा",
            "upload_tags"           to "टैग्स",
            "upload_tags_hint"      to "टैग टाइप करें और + दबाएं",
            "upload_guidelines_title" to "दिशानिर्देश",
            "upload_guidelines"     to "• केवल मौलिक कंटेंट अपलोड करें\n• अश्लील या हिंसक कंटेंट नहीं\n• आपकी पोस्ट एडमिन द्वारा रिव्यू होने के बाद पब्लिश होगी\n• रिजेक्ट होने पर कारण बताया जाएगा",
            "upload_submit"         to "रिव्यू के लिए सबमिट करें",
            "upload_uploading"      to "अपलोड हो रहा है...",
            "upload_success"        to "सफलतापूर्वक सबमिट हो गया!",
            "upload_success_sub"    to "एडमिन आपकी पोस्ट रिव्यू करेगा। अप्रूव या रिजेक्ट होने पर आपको सूचित किया जाएगा।",
            "upload_error"          to "अपलोड विफल। कृपया दोबारा कोशिश करें।",
            "upload_pick_first"     to "कृपया पहले कोई इमेज या वीडियो चुनें।",
            "upload_caption_required" to "कृपया कैप्शन लिखें।",
            "upload_category_required" to "कृपया कैटेगरी चुनें।",
            "upload_video_selected" to "वीडियो चुना गया",
            "upload_image_selected" to "इमेज चुनी गई",

            // 🇮🇳 No Internet (Hindi)
            "no_internet_title"     to "कोई इंटरनेट कनेक्शन नहीं",
            "no_internet_desc"      to "कृपया अपना मोबाइल डेटा या वाई-फाई (Wi-Fi) चालू करें।"
        ),

        // ── MARATHI ───────────────────────────────────────────
        "mr" to mapOf(
            // Bottom Nav
            "tab_home"       to "होम",
            "tab_explore"    to "एक्सप्लोर",
            "tab_profile"    to "प्रोफाइल",

            // Home Screen
            "btn_download"   to "डाउनलोड",
            "btn_share"      to "शेअर",
            "search_hint"    to "पोस्ट शोधा...",
            "no_posts"       to "कोणतीही पोस्ट सापडली नाही",
            "load_error"     to "पोस्ट लोड होऊ शकल्या नाहीत",

            // Explore Screen
            "explore_title"  to "एक्सप्लोर",
            "explore_hint"   to "श्रेणी शोधा...",
            "no_categories"  to "कोणतीही श्रेणी सापडली नाही",

            // Profile Screen
            "profile_title"         to "प्रोफाइल",
            "content_language"      to "सामग्री भाषा",
            "app_language"          to "ॲप भाषा",
            "lang_hindi"            to "हिंदी",
            "lang_marathi"          to "मराठी",
            "lang_english"          to "English",
            "theme"                 to "थीम",
            "theme_dark"            to "डार्क मोड",
            "theme_light"           to "लाइट मोड",
            "dark_mode"             to "डार्क मोड",
            "light_mode"            to "लाइट मोड",
            "logout"                to "लॉगआउट",
            "downloads"             to "डाउनलोड्स",
            "notifications"         to "सूचना",
            "feedback"              to "अभिप्राय",
            "profile_settings"      to "प्रोफाइल सेटिंग्ज",
            "content_lang_desc"     to "भाषेनुसार पोस्ट फिल्टर करा",
            "app_lang_desc"         to "ॲपची प्रदर्शन भाषा बदला",

            // Help & Support
            "help_support"          to "मदत आणि समर्थन",
            "help_title"            to "आम्ही तुम्हाला कशी मदत करू शकतो?",
            "help_phone"            to "फोन नंबर",
            "help_phone_hint"       to "तुमचा फोन नंबर टाका",
            "help_email"            to "ईमेल पत्ता",
            "help_email_hint"       to "तुमचा ईमेल पत्ता टाका",
            "help_issue"            to "तुमची समस्या सांगा",
            "help_issue_hint"       to "तुमची समस्या तपशीलवार लिहा...",
            "help_submit"           to "सादर करा",
            "help_submitting"       to "सादर होत आहे...",
            "help_success"          to "तुमची विनंती सादर झाली!",
            "help_success_sub"      to "आमची टीम 24 तासांत तुमच्याशी संपर्क करेल।",
            "help_error"            to "सादर करणे अयशस्वी. कृपया पुन्हा प्रयत्न करा.",
            "help_fill_all"         to "कृपया सर्व फील्ड भरा.",

            // Terms & Conditions
            "terms"                 to "नियम आणि अटी",
            "terms_last_updated"    to "शेवटचे अपडेट: April 2026",
            "terms_content"         to """
StatusSeva वापरून, तुम्ही खालील नियमांशी सहमत आहात:

1. सामग्री वापर
StatusSeva वरील सर्व सामग्री (चित्रे, व्हिडिओ, कोट्स) केवळ वैयक्तिक WhatsApp स्टेटस वापरासाठी आहे. व्यावसायिक वापर कठोरपणे प्रतिबंधित आहे.

2. बौद्धिक संपदा
अॅडमिन टीमने अपलोड केलेली सर्व सामग्री संरक्षित आहे. तुम्ही या ॲपमधील कोणतीही सामग्री कॉपी, पुनर्वितरित किंवा विकू शकत नाही.

3. वापरकर्ता आचरण
तुम्ही ॲपचा गैरवापर करणार नाही, अयोग्य सामग्री शेअर करणार नाही किंवा अॅप्लिकेशन हॅक/रिव्हर्स-इंजीनियर करण्याचा प्रयत्न करणार नाही.

4. गोपनीयता
आम्ही केवळ लॉगिन उद्देशांसाठी तुमची Google खाते माहिती (नाव, ईमेल, फोटो) गोळा करतो. आम्ही तुमचा डेटा तृतीय पक्षांना विकत नाही.

5. डाउनलोड आणि वॉटरमार्क
डाउनलोड केलेल्या सामग्रीमध्ये वॉटरमार्क असू शकतात. वॉटरमार्क काढणे परवानगी नाही.

6. समाप्ती
या नियमांचे उल्लंघन करणाऱ्या कोणत्याही वापरकर्त्याचा प्रवेश निलंबित किंवा समाप्त करण्याचा अधिकार आम्ही राखतो.

7. बदल
आम्ही कधीही हे नियम अपडेट करू शकतो. ॲपचा सतत वापर अपडेट केलेल्या नियमांची स्वीकृती मानली जाईल.

मदतीसाठी, Help & Support विभागाद्वारे आमच्याशी संपर्क करा.
            """.trimIndent(),

            // Downloads
            "downloads_title"       to "डाउनलोड्स",
            "no_downloads"          to "अद्याप कोणतेही डाउनलोड नाही",
            "no_downloads_sub"      to "डाउनलोड केलेल्या पोस्ट येथे दिसतील",

            // Notifications
            "notif_title"           to "सूचना",
            "no_notifs"             to "अद्याप कोणतीही सूचना नाही",

            // Upload tab
            "upload_tab_upload"      to "अपलोड",
            "upload_tab_my"          to "माझी सामग्री",
            "upload_another"         to "+ आणखी अपलोड करा",
            "my_content_empty"       to "अद्याप कोणतीही सामग्री नाही",
            "my_content_empty_sub"   to "तुमची पहिली सामग्री अपलोड करा",
            "uc_status_pending"      to "⏳ पुनरावलोकनाधीन",
            "uc_status_approved"     to "✅ लाइव",
            "uc_status_rejected"     to "❌ नाकारले",
            "uc_msg_pending"         to "प्रशासक पुनरावलोकन करत आहे। मंजूर झाल्यावर लाइव होईल.",
            "uc_msg_approved"        to "🎉 तुमची सामग्री आता ॲपमध्ये लाइव आहे!",
            "uc_msg_rejected"        to "वरील कारणामुळे नाकारण्यात आले.",
            "uc_reject_reason_label" to "नकाराचे कारण:",
            "uc_cancel_title"        to "विनंती रद्द करायची?",
            "uc_cancel_body"         to "ही अपलोड विनंती रद्द होईल आणि फाइल हटवली जाईल.",
            "uc_delete_title"        to "पोस्ट हटवायची?",
            "uc_delete_body"         to "ही पोस्ट सर्व्हरवरून कायमची हटवली जाईल.",
            "uc_cancel_btn"          to "विनंती रद्द करा",
            "uc_delete_btn"          to "हटवा",
            "uc_keep_btn"            to "ठेवा",

            // Common
            "save"                  to "जतन करा",
            "cancel"                to "रद्द करा",
            "ok"                    to "ठीक आहे",
            "close"                 to "बंद करा",
            "just_now"              to "आत्ता",
            "saved_ok"              to "जतन झाले ✓",
            "download_fail"         to "डाउनलोड अयशस्वी",
            "wa_not_installed"      to "WhatsApp इंस्टॉल नाही",
            "video_preparing"       to "व्हिडिओ तयार होत आहे...",
            "video_load_fail"       to "व्हिडिओ लोड झाला नाही",

            "cat_all"               to "सर्व",
            "upload_title"          to "सामग्री अपलोड करा",
            "upload_media"          to "मीडिया निवडा",
            "upload_pick"           to "प्रतिमा किंवा व्हिडिओ निवडण्यासाठी टॅप करा",
            "upload_pick_sub"       to "JPG, PNG, MP4 समर्थित",
            "upload_details"        to "पोस्ट तपशील",
            "upload_caption"        to "कॅप्शन",
            "upload_caption_hint"   to "तुमच्या पोस्टसाठी कॅप्शन लिहा...",
            "upload_category"       to "श्रेणी",
            "upload_category_hint"  to "श्रेणी निवडा किंवा टाइप करा",
            "upload_language"       to "भाषा",
            "upload_tags"           to "टॅग्स",
            "upload_tags_hint"      to "टॅग टाइप करा आणि + दाबा",
            "upload_guidelines_title" to "मार्गदर्शक तत्त्वे",
            "upload_guidelines"     to "• फक्त मूळ सामग्री अपलोड करा\n• अश्लील किंवा हिंसक सामग्री नाही\n• तुमची पोस्ट प्रशासकाकडून तपासल्यानंतर प्रकाशित होईल\n• नाकारल्यास कारण सांगितले जाईल",
            "upload_submit"         to "तपासणीसाठी सादर करा",
            "upload_uploading"      to "अपलोड होत आहे...",
            "upload_success"        to "यशस्वीरित्या सादर झाले!",
            "upload_success_sub"    to "प्रशासक तुमची पोस्ट तपासेल. मंजूर किंवा नाकारल्यावर तुम्हाला सूचित केले जाईल.",
            "upload_error"          to "अपलोड अयशस्वी. कृपया पुन्हा प्रयत्न करा.",
            "upload_pick_first"     to "कृपया आधी प्रतिमा किंवा व्हिडिओ निवडा.",
            "upload_caption_required" to "कृपया कॅप्शन लिहा.",
            "upload_category_required" to "कृपया श्रेणी निवडा.",
            "upload_video_selected" to "व्हिडिओ निवडला",
            "upload_image_selected" to "प्रतिमा निवडली",

            // 🟠 No Internet (Marathi)
            "no_internet_title"     to "इंटरनेट कनेक्शन नाही",
            "no_internet_desc"      to "कृपया तुमचा मोबाइल डेटा किंवा वाय-फाय (Wi-Fi) चालू करा."
        )
    )
}