package com.statusseva.app.ui.home

import android.app.Application
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.statusseva.app.data.PostRepository
import com.statusseva.app.data.SearchManager
import com.statusseva.app.model.Post
import androidx.compose.ui.graphics.vector.ImageVector

data class Category(
    val name: String,
    val icon: ImageVector
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    /* ---------------------------------------------------------
       Search Manager
     --------------------------------------------------------- */

    private val searchManager = SearchManager(application)

    /* ---------------------------------------------------------
       Categories with Icons
     --------------------------------------------------------- */

    val categories = listOf(
        Category("All", Icons.Default.Home),
        Category("Motivation", Icons.Default.LocalFireDepartment),
        Category("Love", Icons.Default.Favorite),
        Category("Attitude", Icons.Default.EmojiEmotions),
        Category("Success", Icons.Default.Star),
        Category("Life", Icons.Default.SelfImprovement)
    )

    var selectedCategory by mutableStateOf(categories.first())
        private set

    var filteredPosts by mutableStateOf<List<Post>>(emptyList())
        private set

    /* ---------------------------------------------------------
       Recent Search State
     --------------------------------------------------------- */

    var recentSearches by mutableStateOf<List<String>>(emptyList())
        private set

    init {
        loadPosts()
        loadRecentSearches()
    }

    /* ---------------------------------------------------------
       Category Selection
     --------------------------------------------------------- */

    fun selectCategory(category: Category?) {
        val safeCategory = category ?: categories.first()
        selectedCategory = safeCategory
        loadPosts()
    }

    /* ---------------------------------------------------------
       Load Posts Based on Category
     --------------------------------------------------------- */

    private fun loadPosts() {
        filteredPosts =
            if (selectedCategory.name.equals("All", ignoreCase = true)) {
                PostRepository.getAllPosts()
            } else {
                PostRepository.getPostsByCategory(selectedCategory.name)
            }
    }

    /* ---------------------------------------------------------
       🔍 SEARCH HISTORY FUNCTIONS
     --------------------------------------------------------- */

    fun loadRecentSearches() {
        recentSearches = searchManager.getRecentSearches()
    }

    fun saveSearch(query: String) {
        searchManager.saveSearch(query)
        loadRecentSearches()
    }

    fun clearSearchHistory() {
        searchManager.clearHistory()
        recentSearches = emptyList()
    }
}