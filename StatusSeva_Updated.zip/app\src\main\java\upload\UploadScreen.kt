package com.statusseva.app.ui.upload

import android.Manifest
import android.os.Build
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import com.statusseva.app.R
import com.statusseva.app.data.AppStrings
import com.statusseva.app.data.GoogleAuthHelper
import com.statusseva.app.data.LanguagePreference
import kotlinx.coroutines.launch

data class UserContentItem(
    val id               : String  = "",
    val mediaUrl         : String  = "",
    val storagePath      : String  = "",
    val mediaType        : String  = "image",
    val caption          : String  = "",
    val category         : String  = "",
    val status           : String  = "pending",
    val rejectReason     : String  = "",
    val createdAt        : Long    = 0L,
    val deleteRequested  : Boolean = false   // User ne delete request di hai admin ko
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(
    onNavigate : (String) -> Unit = {},
    appLang    : String = "hi"
) {
    fun str(key: String) = AppStrings.get(key, appLang)
    var selectedTab by remember { mutableStateOf(0) }
    val context = LocalContext.current

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                TopAppBar(
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(painter = painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.height(30.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(str("upload_title"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick  = { selectedTab = 0 },
                        text     = {
                            Text(
                                when (appLang) {
                                    "hi" -> "अपलोड"
                                    "mr" -> "अपलोड"
                                    else -> "Upload"
                                }
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick  = { selectedTab = 1 },
                        text     = {
                            Text(
                                when (appLang) {
                                    "hi" -> "मेरी सामग्री"
                                    "mr" -> "माझी सामग्री"
                                    else -> "My Content"
                                }
                            )
                        }
                    )
                }
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> UploadTab(padding = padding, appLang = appLang)
            1 -> MyContentTab(padding = padding, appLang = appLang)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadTab(
    padding : PaddingValues,
    appLang : String
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    val context        = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val firestore      = remember { FirebaseFirestore.getInstance() }

    // 🌟 FIX: Using dynamic remember for language to ensure it updates if settings change
    val contentLang    = remember(appLang) { LanguagePreference.getContentLanguage(context) }

    val googleUser = GoogleAuthHelper.currentUser
    val userName   = googleUser?.displayName ?: ""
    val userEmail  = googleUser?.email       ?: ""
    val userId     = googleUser?.uid         ?: ""

    var selectedUri    by remember { mutableStateOf<Uri?>(null) }
    var isVideo        by remember { mutableStateOf(false) }
    var caption        by remember { mutableStateOf("") }
    var category       by remember { mutableStateOf("") }
    var tagInput       by remember { mutableStateOf("") }
    var tags           by remember { mutableStateOf<List<String>>(emptyList()) }
    var uploadState    by remember { mutableStateOf<UploadState>(UploadState.Idle) }
    var uploadProgress by remember { mutableStateOf(0f) }
    var videoThumb     by remember { mutableStateOf<Bitmap?>(null) }

    // Fallback to "hi" if empty, but explicitly passing it for DB save
    val language = contentLang.ifBlank { "hi" }

    var firestoreCategories  by remember { mutableStateOf<List<String>>(emptyList()) }
    var showCategoryDropdown by remember { mutableStateOf(false) }

    // 🌟 FIX: Added contentLang to LaunchedEffect key and filtering logic inside snapshot listener
    LaunchedEffect(contentLang) {
        firestore.collection("categories")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    firestoreCategories = snap.documents
                        .filter { doc ->
                            val catLang = doc.getString("language") ?: ""
                            catLang.isBlank() || catLang.equals(contentLang, ignoreCase = true)
                        }
                        .mapNotNull { it.getString("name") }
                        .filter { it.lowercase() != "trending" }
                        .sorted()
                }
            }
    }

    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val mimeType = context.contentResolver.getType(uri) ?: ""
            isVideo     = mimeType.startsWith("video/")
            selectedUri = uri
            videoThumb = if (isVideo) {
                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    val frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    retriever.release()
                    frame
                } catch (_: Exception) { null }
            } else null
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            mediaPicker.launch("*/*")
        } else {
            Toast.makeText(context, "Media permission required", Toast.LENGTH_SHORT).show()
        }
    }

    fun openPicker() {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO
                    )
                )
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                mediaPicker.launch("*/*")
            }
            else -> {
                permissionLauncher.launch(
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                )
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        if (uploadState is UploadState.Success) {
            SuccessCard(
                appLang         = appLang,
                onUploadAnother = {
                    selectedUri    = null
                    videoThumb     = null
                    caption        = ""
                    category       = ""
                    tags           = emptyList()
                    tagInput       = ""
                    uploadState    = UploadState.Idle
                    uploadProgress = 0f
                }
            )
            return@Column
        }

        // ── MEDIA PICKER ──
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(str("upload_media"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                if (selectedUri == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth().height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(2.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .clickable { openPicker() },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(8.dp))
                            Text(str("upload_pick"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text(str("upload_pick_sub"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    Box(
                        modifier         = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.TopEnd
                    ) {
                        if (isVideo) {
                            Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                                if (videoThumb != null) {
                                    Image(
                                        bitmap             = videoThumb!!.asImageBitmap(),
                                        contentDescription = null,
                                        modifier           = Modifier.fillMaxSize(),
                                        contentScale       = ContentScale.Crop
                                    )
                                }
                                Icon(
                                    Icons.Default.PlayCircle, null,
                                    modifier = Modifier.size(56.dp),
                                    tint     = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        } else {
                            AsyncImage(model = selectedUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        IconButton(
                            onClick  = { openPicker() },
                            modifier = Modifier.padding(4.dp).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), RoundedCornerShape(50))
                        ) {
                            Icon(Icons.Default.Edit, null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text  = if (isVideo) "📹 ${str("upload_video_selected")}" else "🖼️ ${str("upload_image_selected")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // ── DETAILS ──
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(str("upload_details"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value         = caption,
                    onValueChange = { caption = it },
                    label         = { Text(str("upload_caption")) },
                    placeholder   = { Text(str("upload_caption_hint")) },
                    modifier      = Modifier.fillMaxWidth(),
                    maxLines      = 3,
                    shape         = RoundedCornerShape(12.dp)
                )

                ExposedDropdownMenuBox(expanded = showCategoryDropdown, onExpandedChange = { showCategoryDropdown = it }) {
                    OutlinedTextField(
                        value         = category,
                        onValueChange = { },
                        readOnly      = true,
                        label         = { Text(str("upload_category")) },
                        placeholder   = { Text(str("upload_category_hint")) },
                        modifier      = Modifier.fillMaxWidth().menuAnchor(),
                        shape         = RoundedCornerShape(12.dp),
                        trailingIcon  = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showCategoryDropdown) }
                    )
                    ExposedDropdownMenu(expanded = showCategoryDropdown, onDismissRequest = { showCategoryDropdown = false }) {
                        firestoreCategories.forEach { cat ->
                            DropdownMenuItem(text = { Text(cat) }, onClick = { category = cat; showCategoryDropdown = false })
                        }
                    }
                }

                Text(str("upload_tags"), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value           = tagInput,
                        onValueChange   = { tagInput = it },
                        placeholder     = { Text(str("upload_tags_hint")) },
                        modifier        = Modifier.weight(1f),
                        singleLine      = true,
                        shape           = RoundedCornerShape(12.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            val t = tagInput.trim().lowercase()
                            if (t.isNotBlank() && !tags.contains(t)) tags = tags + t
                            tagInput = ""
                        })
                    )
                    Button(onClick = {
                        val t = tagInput.trim().lowercase()
                        if (t.isNotBlank() && !tags.contains(t)) tags = tags + t
                        tagInput = ""
                    }, shape = RoundedCornerShape(12.dp)) { Text("＋") }
                }
                if (tags.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(tags) { tag ->
                            InputChip(
                                selected     = false,
                                onClick      = { tags = tags - tag },
                                label        = { Text("#$tag", fontSize = 12.sp) },
                                trailingIcon = { Icon(Icons.Default.Close, null, modifier = Modifier.size(14.dp)) }
                            )
                        }
                    }
                }
            }
        }

        // ── GUIDELINES ──
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(14.dp),
            colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("ℹ️ ${str("upload_guidelines_title")}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(str("upload_guidelines"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
            }
        }

        if (uploadState is UploadState.Uploading) {
            Column {
                LinearProgressIndicator(progress = { uploadProgress }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)), trackColor = MaterialTheme.colorScheme.surfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("${(uploadProgress * 100).toInt()}% — ${str("upload_uploading")}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (uploadState is UploadState.Error) {
            Text((uploadState as UploadState.Error).message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Button(
            onClick = {
                if (selectedUri == null) { Toast.makeText(context, str("upload_pick_first"), Toast.LENGTH_SHORT).show(); return@Button }
                if (caption.isBlank())   { Toast.makeText(context, str("upload_caption_required"), Toast.LENGTH_SHORT).show(); return@Button }
                if (category.isBlank())  { Toast.makeText(context, str("upload_category_required"), Toast.LENGTH_SHORT).show(); return@Button }
                coroutineScope.launch {
                    uploadState    = UploadState.Uploading
                    uploadProgress = 0f
                    try {
                        val uri      = selectedUri!!
                        val mimeType = context.contentResolver.getType(uri) ?: ""
                        val ext      = when {
                            mimeType.startsWith("video/") -> "mp4"
                            mimeType == "image/png"       -> "png"
                            else                          -> "jpg"
                        }
                        val objectKey = "user_content/${userId}_${System.currentTimeMillis()}.$ext"

                        // ── STEP 1: Firebase Function se secure presigned URL lo ──
                        // 🔒 Keys ab APK mein nahi hain — sirf server (Cloud Function) pe hain
                        uploadProgress = 0.1f
                        val functions = FirebaseFunctions.getInstance()
                        val urlResult = withContext(Dispatchers.IO) {
                            functions
                                .getHttpsCallable("getUploadUrl")
                                .call(mapOf(
                                    "objectKey"   to objectKey,
                                    "contentType" to mimeType.ifBlank { "application/octet-stream" }
                                ))
                                .await()
                        }
                        val resultMap = urlResult.data as Map<*, *>
                        val uploadUrl = resultMap["uploadUrl"] as String
                        val mediaUrl  = resultMap["publicUrl"] as String

                        // ── STEP 2: File bytes read karo ──
                        val bytes = withContext(Dispatchers.IO) {
                            context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                        }

                        // ── STEP 3: Presigned URL pe seedha R2 pe upload karo ──
                        withContext(Dispatchers.IO) {
                            val conn = java.net.URL(uploadUrl).openConnection() as java.net.HttpURLConnection
                            conn.requestMethod  = "PUT"
                            conn.doOutput       = true
                            conn.connectTimeout = 30_000
                            conn.readTimeout    = 120_000
                            conn.setRequestProperty("Content-Type", mimeType.ifBlank { "application/octet-stream" })
                            conn.setFixedLengthStreamingMode(bytes.size)
                            conn.outputStream.use { out ->
                                val chunk = 65_536
                                var done  = 0
                                while (done < bytes.size) {
                                    val end = minOf(done + chunk, bytes.size)
                                    out.write(bytes, done, end - done)
                                    out.flush()
                                    done = end
                                    // Progress: 10% URL fetch + 90% actual upload
                                    uploadProgress = 0.1f + (done.toFloat() / bytes.size.toFloat()) * 0.9f
                                }
                            }
                            val code = conn.responseCode
                            conn.disconnect()
                            if (code != 200 && code != 204) {
                                throw Exception("Upload failed: $code")
                            }
                        }

                        // ── STEP 4: Firestore mein save karo ──
                        firestore.collection("user_content").add(mapOf(
                            "userName"    to userName,
                            "userEmail"   to userEmail,
                            "userId"      to userId,
                            "mediaUrl"    to mediaUrl,
                            "storagePath" to objectKey,
                            "mediaType"   to (if (isVideo) "video" else "image"),
                            "caption"     to caption.trim(),
                            "category"    to category.trim(),
                            "language"    to language,
                            "tags"        to tags,
                            "status"      to "pending",
                            "createdAt"   to FieldValue.serverTimestamp()
                        )).await()
                        uploadState = UploadState.Success
                    } catch (e: Exception) {
                        uploadState = UploadState.Error(e.message ?: str("upload_error"))
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape    = RoundedCornerShape(14.dp),
            enabled  = uploadState !is UploadState.Uploading
        ) {
            if (uploadState is UploadState.Uploading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(8.dp))
                Text(str("upload_uploading"))
            } else {
                Icon(Icons.Default.CloudUpload, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(str("upload_submit"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        // Spacer to prevent button from hiding under bottom nav
        Spacer(Modifier.height(120.dp))
    }
}

@Composable
fun MyContentTab(
    padding : PaddingValues,
    appLang : String
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    val firestore    = remember { FirebaseFirestore.getInstance() }
    val userId       = GoogleAuthHelper.currentUser?.uid ?: ""
    val coroutine    = rememberCoroutineScope()
    var items        by remember { mutableStateOf<List<UserContentItem>>(emptyList()) }
    var isLoading    by remember { mutableStateOf(true) }
    var deleteDialog by remember { mutableStateOf<UserContentItem?>(null) }

    DisposableEffect(userId) {
        val listener = firestore.collection("user_content")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snap, error ->
                if (error != null) { isLoading = false; return@addSnapshotListener }
                if (snap != null) {
                    items = snap.documents
                        .mapNotNull { doc ->
                            val ts = doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                            UserContentItem(
                                id              = doc.id,
                                mediaUrl        = doc.getString("mediaUrl")         ?: "",
                                storagePath     = doc.getString("storagePath")      ?: "",
                                mediaType       = doc.getString("mediaType")        ?: "image",
                                caption         = doc.getString("caption")          ?: "",
                                category        = doc.getString("category")         ?: "",
                                status          = doc.getString("status")           ?: "pending",
                                rejectReason    = doc.getString("rejectReason")     ?: "",
                                createdAt       = ts,
                                deleteRequested = doc.getBoolean("deleteRequested") ?: false
                            )
                        }
                        .sortedByDescending { it.createdAt }
                }
                isLoading = false
            }
        onDispose { listener.remove() }
    }

    Box(modifier = Modifier.fillMaxSize().padding(padding)) {
        when {
            isLoading -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
            items.isEmpty() -> {
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CloudUpload, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
                    Spacer(Modifier.height(12.dp))
                    Text(str("my_content_empty"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    Spacer(Modifier.height(4.dp))
                    Text(str("my_content_empty_sub"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
                }
            }
            else -> {
                LazyColumn(
                    modifier            = Modifier.fillMaxSize(),
                    contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(items, key = { it.id }) { item ->
                        UserContentCard(
                            item     = item,
                            appLang  = appLang,
                            onDelete = { deleteDialog = item },
                            onCancel = { deleteDialog = item }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }

    deleteDialog?.let { item ->
        val isPending = item.status == "pending"
        var isSubmitting by remember { mutableStateOf(false) }
        fun str2(key: String) = AppStrings.get(key, appLang)

        if (isPending) {
            // ── Pending item: direct cancel (not published yet) ────────────────────
            AlertDialog(
                onDismissRequest = { if (!isSubmitting) deleteDialog = null },
                title            = { Text(str2("uc_cancel_title"), fontWeight = FontWeight.Bold) },
                text             = { Text(str2("uc_cancel_body")) },
                confirmButton    = {
                    TextButton(
                        enabled = !isSubmitting,
                        onClick = {
                            isSubmitting = true
                            coroutine.launch {
                                try {
                                    // Pending item directly delete karo — admin ne approve nahi kiya
                                    firestore.collection("user_content").document(item.id).delete().await()
                                    // R2 se bhi delete karo agar path hai
                                    if (item.storagePath.isNotBlank()) {
                                        try {
                                            withContext(Dispatchers.IO) {
                                                FirebaseFunctions.getInstance()
                                                    .getHttpsCallable("deleteR2File")
                                                    .call(mapOf("objectKey" to item.storagePath))
                                                    .await()
                                            }
                                        } catch (_: Exception) {}
                                    }
                                } catch (_: Exception) {}
                                isSubmitting = false
                                deleteDialog = null
                            }
                        }
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(str2("uc_cancel_btn"), color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deleteDialog = null }) { Text(str2("uc_keep_btn")) }
                }
            )
        } else {
            // ── Approved/Rejected item: Send "Request to Delete" to admin ─────────
            // User direct delete nahi kar sakta — admin se request jayegi
            AlertDialog(
                onDismissRequest = { if (!isSubmitting) deleteDialog = null },
                title = {
                    Text(
                        when (appLang) {
                            "hi" -> "Delete Request भेजें?"
                            "mr" -> "Delete Request पाठवायची?"
                            else -> "Send Delete Request?"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text(
                            when (appLang) {
                                "hi" -> "Admin को Delete Request भेजी जाएगी। Admin approve करने पर आपका content हटा दिया जाएगा।"
                                "mr" -> "Admin ला Delete Request पाठवली जाईल। Admin approve केल्यावर तुमचा content काढला जाईल."
                                else -> "A delete request will be sent to admin. Your content will be removed once admin approves."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (item.status == "approved") {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                when (appLang) {
                                    "hi" -> "⚠️ यह content app में live है — admin review के बाद हटेगा।"
                                    "mr" -> "⚠️ हे content app मध्ये live आहे — admin review नंतर काढले जाईल."
                                    else -> "⚠️ This content is live in the app — it will be removed after admin review."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        enabled = !isSubmitting,
                        onClick = {
                            isSubmitting = true
                            coroutine.launch {
                                try {
                                    val user = GoogleAuthHelper.currentUser
                                    // delete_requests collection mein request dalo
                                    firestore.collection("delete_requests").add(
                                        mapOf(
                                            "contentId"       to item.id,
                                            "userId"          to (user?.uid ?: ""),
                                            "userName"        to (user?.displayName ?: ""),
                                            "userEmail"       to (user?.email ?: ""),
                                            "contentImageUrl" to item.mediaUrl,
                                            "caption"         to item.caption,
                                            "category"        to item.category,
                                            "contentStatus"   to item.status,
                                            "storagePath"     to item.storagePath,
                                            "reason"          to "User requested deletion",
                                            "requestedAt"     to FieldValue.serverTimestamp()
                                        )
                                    ).await()

                                    // User_content mein status update karo — "delete_requested"
                                    firestore.collection("user_content").document(item.id)
                                        .update(
                                            mapOf(
                                                "deleteRequested" to true,
                                                "deleteRequestedAt" to FieldValue.serverTimestamp()
                                            )
                                        ).await()

                                } catch (e: Exception) {
                                    // Silent fail — user ko toast dikhao
                                }
                                isSubmitting = false
                                deleteDialog = null
                            }
                        }
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            when (appLang) {
                                "hi" -> "Request भेजें"
                                "mr" -> "Request पाठवा"
                                else -> "Send Request"
                            }
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { deleteDialog = null }, enabled = !isSubmitting) {
                        Text(str2("uc_keep_btn"))
                    }
                }
            )
        }
    }
}

@Composable
fun UserContentCard(
    item     : UserContentItem,
    appLang  : String = "hi",
    onDelete : () -> Unit,
    onCancel : () -> Unit
) {
    fun str(key: String) = AppStrings.get(key, appLang)

    val statusConfig = when (item.status) {
        "pending"  -> Triple(str("uc_status_pending"),  MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.tertiaryContainer)
        "approved" -> Triple(str("uc_status_approved"), Color(0xFF16a34a),                  Color(0xFFdcfce7))
        "rejected" -> Triple(str("uc_status_rejected"), MaterialTheme.colorScheme.error,    MaterialTheme.colorScheme.errorContainer)
        else       -> Triple(str("uc_status_pending"),  MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.tertiaryContainer)
    }

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column {
            Box(
                modifier = Modifier.fillMaxWidth().height(180.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
            ) {
                if (item.mediaType == "video") {
                    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayCircle, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    AsyncImage(model = item.mediaUrl, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    shape    = RoundedCornerShape(20.dp),
                    color    = statusConfig.third.copy(alpha = 0.92f)
                ) {
                    Text(statusConfig.first, color = statusConfig.second, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                if (item.caption.isNotBlank()) {
                    Text(item.caption, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                }
                Text("📂 ${item.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                if (item.status == "rejected" && item.rejectReason.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(str("uc_reject_reason_label"), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.height(2.dp))
                            Text(item.rejectReason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    text  = when (item.status) {
                        "pending"  -> str("uc_msg_pending")
                        "approved" -> str("uc_msg_approved")
                        "rejected" -> str("uc_msg_rejected")
                        else       -> str("uc_msg_pending")
                    },
                    style      = MaterialTheme.typography.labelSmall,
                    color      = when (item.status) {
                        "approved" -> Color(0xFF16a34a)
                        "rejected" -> MaterialTheme.colorScheme.error
                        else       -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    fontWeight = if (item.status == "approved") FontWeight.SemiBold else FontWeight.Normal
                )

                Spacer(Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    when (item.status) {
                        "pending" -> {
                            OutlinedButton(
                                onClick = onCancel,
                                shape   = RoundedCornerShape(8.dp),
                                colors  = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Default.Cancel, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(str("uc_cancel_btn"), fontSize = 12.sp)
                            }
                        }
                        "approved", "rejected" -> {
                            if (item.deleteRequested) {
                                // Delete request already sent — pending admin review
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(0.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.HourglassEmpty, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error)
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            when (appLang) {
                                                "hi" -> "Delete Request Sent"
                                                "mr" -> "Delete Request Sent"
                                                else -> "Delete Request Sent"
                                            },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            } else {
                                OutlinedButton(
                                    onClick = onDelete,
                                    shape   = RoundedCornerShape(8.dp),
                                    colors  = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        when (appLang) {
                                            "hi" -> "Delete Request"
                                            "mr" -> "Delete Request"
                                            else -> "Request Delete"
                                        },
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

sealed class UploadState {
    object Idle      : UploadState()
    object Uploading : UploadState()
    object Success   : UploadState()
    data class Error(val message: String) : UploadState()
}

@Composable
fun SuccessCard(
    appLang         : String = "hi",
    onUploadAnother : () -> Unit
) {
    fun str(key: String) = AppStrings.get(key, appLang)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(14.dp),
        colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
    ) {
        Column(
            modifier            = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(60.dp), tint = MaterialTheme.colorScheme.primary)
            Text(str("upload_success"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(str("upload_success_sub"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Button(onClick = onUploadAnother, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(str("upload_another"))
            }
        }
    }
}